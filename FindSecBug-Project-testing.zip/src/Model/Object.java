/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Service.AdminService;
import Service.ChequeService;
import Service.CustomerService;
import Service.DatabseBacup;
import Service.ExpencesIncomeService;
import Service.GrnReturnService;
import Service.GrnService;
import Service.InterfaceServise;
import Service.InvoiceReturnInvoice;
import Service.InvoiceService;
import Service.ItemAjustmentService;
import Service.ItemTransferService;
import Service.MyChequeColorTable;
import Service.NotificationService;
import Service.PaymentVerificationService;
import Service.PastGrn;
import Service.PastInvoice;
import Service.PaymentService;
import Service.ReportService;
import Service.ReportServiceOutlet;
import Service.ReportServiceWarehuse;
import Service.SeedPaddyService;
import Service.StockService;
import Service.SupplierService;

/**
 *
 * @author user
 */
public class Object {
//Modle

    public static Model.MessagePopUps messagePopUps = new MessagePopUps();
    public static Model.Jdbc Jdbc = new Jdbc();
    public static Model.Formated Formated = new Formated();
//Service
    public static Service.ItemMasterService ItemMaster = new Service.ItemMasterService();
    public static Service.SupplierService Supplier = new SupplierService();
    public static Service.GrnService grn = new GrnService();
    public static Service.CustomerService customer = new CustomerService();
    public static Service.InvoiceService invoice = new InvoiceService();
    public static Service.ItemTransferService transfer = new ItemTransferService();
    public static Service.PaymentService payment = new PaymentService();
    public static Service.ChequeService cheque = new ChequeService();
    public static Service.ExpencesIncomeService expenses = new ExpencesIncomeService();
    public static Service.InvoiceReturnInvoice invoiceReturn = new InvoiceReturnInvoice();
    public static Service.GrnReturnService grnReturn = new GrnReturnService();
    public static Service.UserService user = new Service.UserService();
    public static Service.StockService stock = new StockService();
    public static Service.ItemAjustmentService ajust = new ItemAjustmentService();
    public static Service.PaymentVerificationService paymentVeryfication = new PaymentVerificationService();
    public static Service.ReportService report = new ReportService();
    public static Service.PastInvoice PastInvoice = new PastInvoice();
    public static Service.PastGrn PastGrn = new PastGrn();
    public static Service.DatabseBacup Bacup = new DatabseBacup();
    public static Service.AdminService Admin = new AdminService();
    public static Service.InterfaceServise interface_format = new InterfaceServise();
    public static Service.NotificationService notification = new NotificationService();
    public static Service.MyChequeColorTable mychequecolortable = new MyChequeColorTable();
    public static Service.SeedPaddyService seddpaddy = new SeedPaddyService();
    public static Service.ReportServiceOutlet outlet_report = new ReportServiceOutlet();
    public static Service.ReportServiceWarehuse warehouse_report = new ReportServiceWarehuse();

}
