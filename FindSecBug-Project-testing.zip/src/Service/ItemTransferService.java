/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.table.DefaultTableModel;
import View.FrmHome2;
import javax.swing.JButton;

/**
 *
 * @author user
 */
public class ItemTransferService {

    public void code_gen(JLabel lbl_transfer_code) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select max(transfer_code) from item_transfer_code");
            if (rset.next()) {
                lbl_transfer_code.setText("ITC" + (rset.getInt(1) + 1));
            }
        } catch (Exception e) {
            System.out.println("Item Transfer code_gen " + e);
        }

    }

    public void item_code_key_release(JTextField txt_item_code, JList lst_code, JList lst_description) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code like'" + txt_item_code.getText() + "%' and location='" + "WAREHOUSE" + "'");
            Vector v_code = new Vector();
            Vector v_description = new Vector();
            while (rset.next()) {
                v_code.add(rset.getString(1));
                v_description.add(rset.getString(2));
            }
            lst_code.setListData(v_code);
            lst_description.setListData(v_description);

        } catch (Exception e) {
            System.out.println(" item transfer  item_code_key_release " + e);
        }

    }

    public void item_name_key_release(JTextField txt_item_description, JList lst_code, JList lst_description) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_name like'" + txt_item_description.getText() + "%' and location='" + "WAREHOUSE" + "'");
            Vector v_code = new Vector();
            Vector v_description = new Vector();
            while (rset.next()) {
                v_code.add(rset.getString(1));
                v_description.add(rset.getString(2));
            }
            lst_code.setListData(v_code);
            lst_description.setListData(v_description);

        } catch (Exception e) {
            System.out.println(" item transfer  item_name_key_release " + e);
        }

    }

    public void all_item(JList lst_code, JList lst_description) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where location='" + "WAREHOUSE" + "'");
            Vector v_code = new Vector();
            Vector v_description = new Vector();
            while (rset.next()) {
                v_code.add(rset.getString(1));
                v_description.add(rset.getString(2));
            }
            lst_code.setListData(v_code);
            lst_description.setListData(v_description);

        } catch (Exception e) {
            System.out.println(" item transfer  item_name_key_release " + e);
        }

    }

    public void item_code_action(JTextField txt_quantity, JLabel lbl_cost_price, JTextField txt_item_description, JTextField txt_item_code, JList lst_code, JComboBox cbo_from, JLabel lbl_available_qty) {
        try {
            if (txt_item_code.getText().isEmpty()) {
                lst_code.grabFocus();
                lst_code.setSelectedIndex(0);
            } else if (lst_code.getModel().getSize() == 1) {
                ListModel model = lst_code.getModel();
                Object o = model.getElementAt(0);
                ResultSet rset_item_master = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + o.toString() + "'");
                if (rset_item_master.next()) {
                    ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + o.toString() + "' and location='" + cbo_from.getSelectedItem() + "'");
                    if (rset.next()) {
                        if (rset.getDouble(4) < 10) {
                            lbl_available_qty.setForeground(Color.red);
                        } else {
                            lbl_available_qty.setForeground(Color.black);
                        }
                        lbl_available_qty.setText(Model.Object.Formated.getPriceValue(rset.getDouble(4)));
                    } else {
                        lbl_available_qty.setText("0.00");
                    }
                    txt_item_description.setText(rset_item_master.getString(2));
                    txt_item_code.setText(rset_item_master.getString(1));
                    lbl_cost_price.setText(Model.Object.Formated.getPriceValue(rset_item_master.getDouble(5)));
                    cbo_from.grabFocus();
                    lst_code.setSelectedIndex(0);
                } else {
                    Model.Object.messagePopUps.Item_number_dosesnot_match();
                    txt_item_code.grabFocus();
                    txt_item_code.selectAll();
                }
            } else if (lst_code.getModel().getSize() == 0) {
                Model.Object.messagePopUps.Item_number_dosesnot_match();
                txt_item_code.grabFocus();
                txt_item_code.selectAll();
            } else {
                lst_code.setSelectedIndex(0);
                lst_code.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("item transfer item_code_action " + e);
        }
    }

    public void item_list_key_press(JList lst_code, JTextField txt_quantity, KeyEvent evt) {
        try {
            if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                int i = lst_code.getSelectedIndex();
                txt_quantity.grabFocus();
                lst_code.setSelectedIndex(i);
            }
        } catch (Exception e) {
            System.out.println("item transfer  item_list key_press " + e);
        }
    }

    public void quantity_action(JLabel lbl_available_qty, JTextField txt_quantity, JLabel lbl_amount, JTextField txt_discount, JLabel lbl_label_price) {
        try {
            if (txt_quantity.getText() == null || txt_quantity.getText().isEmpty()) {
                Model.Object.messagePopUps.Quantity_Empty();
                txt_quantity.grabFocus();
            } else {
                if (Double.parseDouble(lbl_available_qty.getText()) < Double.parseDouble(txt_quantity.getText())) {
                    Model.Object.messagePopUps.Exceed_Quantity();
                    txt_quantity.grabFocus();
                    lbl_amount.setText(null);
                    txt_quantity.selectAll();
                } else {
                    lbl_amount.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(txt_quantity.getText()) * Double.parseDouble(lbl_label_price.getText())));
                    txt_discount.grabFocus();
                }
            }
        } catch (Exception e) {
            System.out.println("item transfer  quantity_action " + e);
        }
    }

    public void transfer_invoice_add(JLabel lbl_transfer_code, JTextField txt_date, JComboBox cbo_from, JComboBox cbo_to, JTextField txt_item_code, JTextField txt_item_description, JTextField txt_quantity, JLabel lbl_amount, JTextField txt_discount, JLabel lbl_net_amount, JTable tbl_transfer, JLabel lbl_label_price, JLabel lbl_cost_price, JLabel lbl_available_qty) {
        try {
            if (txt_item_code.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_item_code();
                txt_item_code.grabFocus();
            } else if (txt_item_description.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_item_description();
                txt_item_description.grabFocus();
            } else if (txt_quantity.getText().isEmpty()) {
                Model.Object.messagePopUps.Quantity_Empty();
                txt_quantity.grabFocus();
            } else if (cbo_from.getSelectedItem().toString().equals(cbo_to.getSelectedItem().toString())) {
                Model.Object.messagePopUps.same_location();
                cbo_to.grabFocus();
            } else {
                if (Double.parseDouble(lbl_available_qty.getText()) < Double.parseDouble(txt_quantity.getText())) {
                    Model.Object.messagePopUps.Exceed_Quantity();
                    txt_quantity.grabFocus();
                    txt_quantity.selectAll();
                } else {
                    boolean bool = false;
                    for (int i = 0; i < tbl_transfer.getRowCount(); i++) {
                        if (tbl_transfer.getValueAt(i, 0).toString().equals(txt_item_code.getText())) {
                            if (tbl_transfer.getValueAt(i, 3).toString().equals(cbo_to.getSelectedItem().toString())) {
                                bool = true;
                                break;
                            }
                        }
                    }
                    ResultSet rset = Model.Object.Jdbc.getdata("select* from item_transfer where tranfer_code='" + lbl_transfer_code.getText() + "'");
                    if (rset.next()) {
                        Model.Object.messagePopUps.duplicate();
                    } else {
                        if (bool) {
                            Model.Object.messagePopUps.Duplicate_entry();
                            txt_item_code.setText(null);
                            txt_item_description.setText(null);
                            txt_quantity.setText(null);
                            lbl_amount.setText(null);
                            txt_discount.setText(null);
                            lbl_net_amount.setText(null);
                            lbl_available_qty.setText(null);
                            lbl_label_price.setText(null);
                            lbl_cost_price.setText(null);
                            txt_item_code.grabFocus();
                        } else {
                            DefaultTableModel df = (DefaultTableModel) tbl_transfer.getModel();
                            Vector v = new Vector();
                            v.add(txt_item_code.getText());
                            v.add(txt_item_description.getText());
                            v.add(cbo_from.getSelectedItem());
                            v.add(cbo_to.getSelectedItem());
                            v.add(lbl_label_price.getText());
                            v.add(txt_quantity.getText());
                            v.add(lbl_amount.getText());
                            v.add(txt_discount.getText());
                            v.add(lbl_net_amount.getText());
                            df.addRow(v);
                            Model.Object.messagePopUps.Data_Added_Successfully();
                            txt_item_code.setText(null);
                            txt_item_description.setText(null);
                            txt_quantity.setText(null);
                            lbl_amount.setText(null);
                            lbl_available_qty.setText(null);
                            lbl_label_price.setText(null);
                            lbl_cost_price.setText(null);
                            txt_discount.setText(null);
                            lbl_net_amount.setText(null);
                            txt_item_code.grabFocus();
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("item transfer  transfer_invoice_add " + e);
        }
    }

    public void discount_action(JLabel lbl_amount, JTextField txt_discount, JLabel lbl_net_amount, JButton btn_add) {
        try {
            if (txt_discount.getText() == null || txt_discount.getText().isEmpty()) {
                txt_discount.setText("0.00");
            }
            Double discount = (Double.parseDouble(lbl_amount.getText()) * Double.parseDouble(txt_discount.getText())) / 100;
            lbl_net_amount.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(lbl_amount.getText()) - discount));
            btn_add.grabFocus();
        } catch (Exception e) {
            System.out.println("item transfer  discount_action " + e);
        }
    }

    public void item_code_list_value_change(JList lst_description, JLabel lbl_cost_price, JTextField txt_item_code, JTextField txt_item_description, JLabel lbl_available_qty, JList lst_code, JComboBox cbo_from, JLabel lbl_label_price) {
        try {
            lst_description.setSelectedIndex(lst_code.getSelectedIndex());
            int i = lst_code.getSelectedIndex();
            lst_description.ensureIndexIsVisible(lst_code.getSelectedIndex());
            lst_code.ensureIndexIsVisible(lst_description.getSelectedIndex());
            lst_code.setSelectedIndex(i);
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + lst_code.getSelectedValue() + "' and location='" + cbo_from.getSelectedItem() + "'");
            if (rset.next()) {
                if (rset.getDouble(4) < 10) {
                    lbl_available_qty.setForeground(Color.red);
                } else {
                    lbl_available_qty.setForeground(Color.black);
                }
                lbl_available_qty.setText(Model.Object.Formated.getPriceValue(rset.getDouble(4)));
                lbl_cost_price.setText(Model.Object.Formated.getPriceValue(rset.getDouble(3)));
            } else {
                lbl_available_qty.setText("0.00");
                lbl_cost_price.setText("0.00");
            }
            ResultSet rset_item_master = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + lst_code.getSelectedValue() + "'");
            if (rset_item_master.next()) {
                txt_item_code.setText(rset_item_master.getString(1));
                txt_item_description.setText(rset_item_master.getString(2));
                lbl_label_price.setText(Model.Object.Formated.getPriceValue(rset_item_master.getDouble(4)));
            } else {
                txt_item_description.setText(null);
                lbl_label_price.setText("0.00");

            }
        } catch (Exception e) {
            System.out.println("item transfer item_code_enter  " + e);
        }
    }

    public void available_stock(JComboBox cbo_from, JLabel lbl_available_qty, JList lst_code) {
        try {

            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + lst_code.getSelectedValue() + "' and location='" + cbo_from.getSelectedItem() + "'");
            if (rset.next()) {
                lbl_available_qty.setText(rset.getString(4));
                if (rset.getDouble(4) < 10) {
                    lbl_available_qty.setForeground(Color.red);
                } else {
                    lbl_available_qty.setForeground(Color.black);
                }
            } else {
                cbo_from.grabFocus();
                lbl_available_qty.setText("0.00");
            }
        } catch (Exception e) {
            System.out.println("item transfer available_stock " + e);
        }
    }

    public void save_invoice(JLabel lbl_transfer_code, JTextField txt_date, JTable tbl_transfer, JComboBox cbo_from, JComboBox cbo_to) {
        try {
            if (cbo_from.getSelectedItem().toString().equals(cbo_to.getSelectedItem().toString())) {
                Model.Object.messagePopUps.transfer_location_invalid();
                cbo_to.grabFocus();
            } else if (txt_date.getText() == null || txt_date.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_date();
                txt_date.grabFocus();
            } else if (tbl_transfer.getRowCount() < 1) {
                Model.Object.messagePopUps.table_empty();
                txt_date.grabFocus();
            } else {
                DefaultTableModel df = (DefaultTableModel) tbl_transfer.getModel();
                for (int i = 0; i < df.getRowCount(); i++) {
                    ResultSet rset_stock_from = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 2) + "'");
                    if (rset_stock_from.next()) {
                        ResultSet rset_stock_to = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 3) + "'");
                        if (rset_stock_to.next()) {
                            Double old_avg_amount = 0.00;
                            Double add_recent_qty = 0.0;
                            ResultSet rset_add_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 3) + "'");
                            if (rset_add_qty.next()) {
                                add_recent_qty = rset_add_qty.getDouble(4);
                                old_avg_amount = rset_add_qty.getDouble(3) * rset_add_qty.getDouble(4);
                            }
                            Double deduct_recent_qty = 0.0;
                            ResultSet rset_deduct_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 2) + "'");
                            if (rset_deduct_qty.next()) {
                                deduct_recent_qty = rset_deduct_qty.getDouble(4);
                            }
                            Double from_stock = rset_stock_from.getDouble(4) - Double.parseDouble(df.getValueAt(i, 5).toString());
                            Double to_stock = rset_stock_to.getDouble(4) + Double.parseDouble(df.getValueAt(i, 5).toString());
                            Double new_avg_amount = (Double.parseDouble(df.getValueAt(i, 8).toString()) + old_avg_amount) / to_stock;
                            Model.Object.Jdbc.putdata("update item_inventory set stock='" + from_stock + "',last_date_time=NOW(),last_user='" + FrmHome2.user_lbl.getText() + "'where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 2) + "'");
                            Model.Object.Jdbc.putdata("update item_inventory set stock='" + to_stock + "',avarage_price='" + new_avg_amount + "',last_date_time=NOW(),last_user='" + FrmHome2.user_lbl.getText() + "'where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 3) + "'");

                            Model.Object.Jdbc.putdata("insert into item_transfer values('" + lbl_transfer_code.getText() + "','" + txt_date.getText() + "','" + df.getValueAt(i, 0) + "','" + df.getValueAt(i, 1) + "','" + df.getValueAt(i, 2) + "','" + df.getValueAt(i, 3) + "','" + df.getValueAt(i, 4) + "','" + df.getValueAt(i, 5) + "','" + df.getValueAt(i, 6) + "','" + df.getValueAt(i, 7) + "','" + df.getValueAt(i, 8) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");

                            //add
                            Model.Object.Jdbc.putdata("insert into Location_wise_transaction values('" + df.getValueAt(i, 0) + "','" + lbl_transfer_code.getText() + "','" + txt_date.getText() + "','" + add_recent_qty + "','" + df.getValueAt(i, 5) + "','" + "0.0" + "','" + (add_recent_qty + Double.parseDouble(df.getValueAt(i, 5).toString())) + "','" + "Item Transfer" + "','" + df.getValueAt(i, 3) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                            //deduct
                            Model.Object.Jdbc.putdata("insert into Location_wise_transaction values('" + df.getValueAt(i, 0) + "','" + lbl_transfer_code.getText() + "','" + txt_date.getText() + "','" + deduct_recent_qty + "','" + "0.0" + "','" + df.getValueAt(i, 5) + "','" + (deduct_recent_qty - Double.parseDouble(df.getValueAt(i, 5).toString())) + "','" + "Item Transfer" + "','" + df.getValueAt(i, 2) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");

                        }
                    }
                }
                Model.Object.Jdbc.putdata("insert into item_transfer_code values('" + "0" + "')");
                Model.Object.messagePopUps.saveMessage();
                df.setRowCount(0);
                lbl_transfer_code.setText(null);
                code_gen(lbl_transfer_code);
                txt_date.setText(Model.Object.Formated.todayDate());
                cbo_from.setSelectedItem("WAREHOUSE");
                cbo_to.setSelectedItem("OUTLET");
                txt_date.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("item transfer save  " + e);
        }
    }
}
