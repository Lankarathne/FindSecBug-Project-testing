/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.sql.ResultSet;
import javax.swing.JPasswordField;

/**
 *
 * @author user
 */
public class Key_Activator {

    boolean bool = false;
    String date = "0000-00-00";

    public String Activate_key(String Password) {
        String Convert_symbol = String.valueOf(Password.charAt(4));
        System.out.println("CN :-" + Convert_symbol);
        if (Convert_symbol.equals("l")) {

            date = convert_l(Password, 1) + "" + convert_l(Password, 7) + "" + convert_l(Password, 10) + "" + convert_l(Password, 13) + "-" + convert_l(Password, 3) + "" + convert_l(Password, 11) + "-" + convert_l(Password, 5) + "" + convert_l(Password, 9);
            System.out.println("Date :-" + date);
        } else if (Convert_symbol.equals("t")) {

            date = convert_t(Password, 1) + "" + convert_t(Password, 7) + "" + convert_t(Password, 10) + "" + convert_t(Password, 13) + "-" + convert_t(Password, 3) + "" + convert_t(Password, 11) + "-" + convert_t(Password, 5) + "" + convert_t(Password, 9);
            System.out.println("Date:-" + date);
        } else if (Convert_symbol.equals("d")) {

            date = convert_d(Password, 1) + "" + convert_d(Password, 7) + "" + convert_d(Password, 10) + "" + convert_d(Password, 13) + "-" + convert_d(Password, 3) + "" + convert_d(Password, 11) + "-" + convert_d(Password, 5) + "" + convert_d(Password, 9);
            System.out.println("Date :-" + date);
        } else {
            bool = true;
        }
        return date;
    }

    private String convert_l(String password, int location) {

        String Convert_numner = "No";
        try {
            if (String.valueOf(password.charAt(location)).equals("i")) {
                Convert_numner = "5";
            } else if (String.valueOf(password.charAt(location)).equals("n")) {
                Convert_numner = "1";
            } else if (String.valueOf(password.charAt(location)).equals("f")) {
                Convert_numner = "4";
            } else if (String.valueOf(password.charAt(location)).equals("o")) {
                Convert_numner = "3";
            } else if (String.valueOf(password.charAt(location)).equals("c")) {
                Convert_numner = "0";
            } else if (String.valueOf(password.charAt(location)).equals("r")) {
                Convert_numner = "8";
            } else if (String.valueOf(password.charAt(location)).equals("a")) {
                Convert_numner = "9";
            } else if (String.valueOf(password.charAt(location)).equals("p")) {
                Convert_numner = "6";
            } else if (String.valueOf(password.charAt(location)).equals("t")) {
                Convert_numner = "2";
            } else if (String.valueOf(password.charAt(location)).equals("u")) {
                Convert_numner = "7";
            } else {
                bool = true;
            }
        } catch (Exception e) {
        }
        return Convert_numner;
    }

    private String convert_t(String password, int location) {

        String Convert_numner = "No";
        try {
            if (String.valueOf(password.charAt(location)).equals("i")) {
                Convert_numner = "9";
            } else if (String.valueOf(password.charAt(location)).equals("n")) {
                Convert_numner = "0";
            } else if (String.valueOf(password.charAt(location)).equals("f")) {
                Convert_numner = "2";
            } else if (String.valueOf(password.charAt(location)).equals("o")) {
                Convert_numner = "6";
            } else if (String.valueOf(password.charAt(location)).equals("c")) {
                Convert_numner = "4";
            } else if (String.valueOf(password.charAt(location)).equals("r")) {
                Convert_numner = "7";
            } else if (String.valueOf(password.charAt(location)).equals("a")) {
                Convert_numner = "5";
            } else if (String.valueOf(password.charAt(location)).equals("p")) {
                Convert_numner = "8";
            } else if (String.valueOf(password.charAt(location)).equals("t")) {
                Convert_numner = "1";
            } else if (String.valueOf(password.charAt(location)).equals("u")) {
                Convert_numner = "3";
            } else {
                bool = true;
            }
        } catch (Exception e) {
        }
        return Convert_numner;
    }

    private String convert_d(String password, int location) {

        String Convert_numner = "No";
        try {
            if (String.valueOf(password.charAt(location)).equals("i")) {
                Convert_numner = "7";
            } else if (String.valueOf(password.charAt(location)).equals("n")) {
                Convert_numner = "5";
            } else if (String.valueOf(password.charAt(location)).equals("f")) {
                Convert_numner = "2";
            } else if (String.valueOf(password.charAt(location)).equals("o")) {
                Convert_numner = "6";
            } else if (String.valueOf(password.charAt(location)).equals("c")) {
                Convert_numner = "8";
            } else if (String.valueOf(password.charAt(location)).equals("r")) {
                Convert_numner = "1";
            } else if (String.valueOf(password.charAt(location)).equals("a")) {
                Convert_numner = "4";
            } else if (String.valueOf(password.charAt(location)).equals("p")) {
                Convert_numner = "0";
            } else if (String.valueOf(password.charAt(location)).equals("t")) {
                Convert_numner = "9";
            } else if (String.valueOf(password.charAt(location)).equals("u")) {
                Convert_numner = "3";
            } else {
                bool = true;

            }
        } catch (Exception e) {
        }
        return Convert_numner;
    }

    public void srial_check(JPasswordField password) {
        System.out.println("ok");
        if (bool) {
            Model.Object.messagePopUps.errorInSerial();
        } else {
            try {
                ResultSet rset_end = Model.Object.Jdbc.getdata("select* from Activate_date");
                if (rset_end.next()) {
                    System.out.println("next");
                    Model.Object.Jdbc.putdata("update Activate_date set start_date='" + password.getText() + "'");
                    Model.Object.messagePopUps.successSerialKey();
                } else {
                    System.out.println(" no next");
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }

    }

}
