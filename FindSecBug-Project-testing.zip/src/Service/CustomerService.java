/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import View.FrmHome2;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class CustomerService {

    public void save_customer(JTextField txt_customer_code, JTextField txt_customer_name, JTextField txt_address, JTextField txt_mobile, JTextField txt_home_tell, JTable tbl_customer) {
        try {
            if (txt_customer_code.getText().isEmpty()) {
                Model.Object.messagePopUps.customer_code_empty();
                txt_customer_code.grabFocus();
            } else if (txt_customer_name.getText().isEmpty()) {
                Model.Object.messagePopUps.customername_empty();
                txt_customer_name.grabFocus();
            } else if (txt_home_tell.getText().isEmpty()) {
                Model.Object.messagePopUps.please_enter_ounstad_limit();
                txt_home_tell.grabFocus();
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + txt_customer_code.getText() + "'");
                if (rset.next()) {
                    Model.Object.messagePopUps.customer_code_duplicate();
                    txt_customer_code.grabFocus();
                    txt_customer_code.selectAll();
                } else {
                    DefaultTableModel df = (DefaultTableModel) tbl_customer.getModel();
                    Vector v = new Vector();
                    Model.Object.Jdbc.putdata("insert into customer_master values('" + txt_customer_code.getText() + "','" + txt_customer_name.getText() + "','" + txt_address.getText() + "','" + txt_mobile.getText() + "','" + txt_home_tell.getText() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                    v.add(txt_customer_code.getText());
                    v.add(txt_customer_name.getText());
                    v.add(txt_address.getText());
                    v.add(txt_mobile.getText());
                    v.add(txt_home_tell.getText());
                    df.addRow(v);
                    Model.Object.messagePopUps.saveMessage();
                    txt_address.setText(null);
                    txt_customer_code.setText(null);
                    txt_customer_name.setText(null);
                    txt_home_tell.setText(null);
                    txt_mobile.setText(null);
                    txt_customer_code.grabFocus();
                }
            }
        } catch (Exception e) {
            System.out.println("save_customer " + e);
        }
    }

    public void View_ll_customer(JTable tbl_customer) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_customer.getModel();
            df.setRowCount(0);
            ResultSet rset = Model.Object.Jdbc.getdata("select* from customer_master");
            while (rset.next()) {
                Vector v = new Vector();
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                v.add(rset.getString(3));
                v.add(rset.getString(4));
                v.add(rset.getString(5));
                df.addRow(v);
            }
        } catch (Exception e) {
            System.out.println("view all_customer" + e);
        }
    }

    public void View_customer_like(JTable tbl_customer, JTextField txt_search_customer_code) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_customer.getModel();
            df.setRowCount(0);
            ResultSet rset = Model.Object.Jdbc.getdata("select* from customer_master where customer_code like'" + txt_search_customer_code.getText() + "%'");
            while (rset.next()) {
                Vector v = new Vector();
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                v.add(rset.getString(3));
                v.add(rset.getString(4));
                v.add(rset.getString(5));
                df.addRow(v);
            }
        } catch (Exception e) {
            System.out.println(" View_customer_like" + e);
        }
    }

    public void customer_table_click(JButton btn_update, JButton btn_save, JTextField txt_customer_code, JTextField txt_customer_name, JTextField txt_address, JTextField txt_mobile, JTextField txt_home_tell, JTable tbl_customer) {
        try {
            if (Model.Object.messagePopUps.record_update_confirem_msg() == JOptionPane.YES_OPTION) {
                DefaultTableModel df = (DefaultTableModel) tbl_customer.getModel();
                int i = tbl_customer.getSelectedRow();
                txt_customer_code.setText(df.getValueAt(i, 0).toString());
                txt_customer_name.setText(df.getValueAt(i, 1).toString());
                txt_address.setText(df.getValueAt(i, 2).toString());
                txt_mobile.setText(df.getValueAt(i, 3).toString());
                txt_home_tell.setText(df.getValueAt(i, 4).toString());
                df.removeRow(i);
                txt_customer_code.setEnabled(false);
                txt_customer_name.grabFocus();
                btn_save.setEnabled(false);
                btn_update.setEnabled(true);
            }
        } catch (Exception e) {
            System.out.println(" customer_table_click" + e);
        }
    }

    public void customer_clear(JButton btn_update, JButton btn_save, JTextField txt_customer_code, JTextField txt_customer_name, JTextField txt_address, JTextField txt_mobile, JTextField txt_home_tell, JTable tbl_customer) {
        try {
            txt_address.setText(null);
            txt_customer_code.setText(null);
            txt_customer_name.setText(null);
            txt_home_tell.setText(null);
            txt_mobile.setText(null);
            txt_customer_code.setEnabled(true);
            btn_save.setEnabled(true);
            btn_update.setEnabled(false);
            txt_customer_code.grabFocus();
        } catch (Exception e) {
            System.out.println("customer_clear" + e);
        }
    }

    public void customer_update(JButton btn_update, JButton btn_save, JTextField txt_customer_code, JTextField txt_customer_name, JTextField txt_address, JTextField txt_mobile, JTextField txt_home_tell, JTable tbl_customer) {
        try {
            if (txt_customer_code.getText().isEmpty()) {
                Model.Object.messagePopUps.customer_code_empty();
                txt_customer_code.grabFocus();
            } else if (txt_customer_name.getText().isEmpty()) {
                Model.Object.messagePopUps.customername_empty();
                txt_customer_name.grabFocus();
            } else if (txt_home_tell.getText().isEmpty()) {
                 Model.Object.messagePopUps.please_enter_ounstad_limit();
                txt_home_tell.grabFocus();
            } else {
                Model.Object.Jdbc.putdata("update customer_master set name='" + txt_customer_name.getText() + "',address='" + txt_address.getText() + "',mob='" + txt_mobile.getText() + "',limit='" + txt_home_tell.getText() + "',date_time=NOW(),user='" + FrmHome2.user_lbl.getText() + "'");
                Model.Object.messagePopUps.record_updated();
                customer_clear(btn_update, btn_save, txt_customer_code, txt_customer_name, txt_address, txt_mobile, txt_home_tell, tbl_customer);
            }
        } catch (Exception e) {
            System.out.println("customer_update " + e);
        }
    }

    public void customer_delete(JTable tbl_customer) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_customer.getModel();
            if (Model.Object.messagePopUps.do_you_want_delete_record_confirem_msg() == JOptionPane.YES_OPTION) {
                Model.Object.Jdbc.putdata("delete from customer_master where customer_code='" + tbl_customer.getValueAt(tbl_customer.getSelectedRow(), 0) + "'");
                Model.Object.messagePopUps.record_deleted();
                df.removeRow(tbl_customer.getSelectedRow());
            }
        } catch (Exception e) {
            System.out.println("customer_delete  " + e);
        }
    }
}
