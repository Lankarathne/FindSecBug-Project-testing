/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class StockService {

    public void full_stock(JTable stock_tbl) {
        try {
            int i = 0;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory");
            while (rset.next()) {
                DefaultTableModel df = (DefaultTableModel) stock_tbl.getModel();
                Vector v = new Vector();
                if (df.getRowCount() == 0) {
                    v.add(rset.getString("item_code"));
                    v.add(rset.getString("item_name"));
                    ResultSet rset_price = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + rset.getString("item_code") + "'");
                    if (rset_price.next()) {
                        v.add(rset_price.getString("main_item_sell_price"));

                        ResultSet rset_total_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + rset.getString("item_code") + "'");
                        Double total_qty = 0.00;
                        while (rset_total_qty.next()) {
                            total_qty = total_qty + rset_total_qty.getDouble(4);
                        }
                        v.add(String.valueOf(total_qty));
                        v.add(Model.Object.Formated.getPriceValue(rset_price.getDouble("main_item_avarage_cost") * total_qty));
                        df.addRow(v);
                    }
                } else if (df.getValueAt(i, 0).toString().equals(rset.getString(1))) {

                } else {
                    v.add(rset.getString("item_code"));
                    v.add(rset.getString("item_name"));
                    ResultSet rset_total_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + rset.getString("item_code") + "'");
                    Double total_qty = 0.00;
                    while (rset_total_qty.next()) {
                        total_qty = total_qty + rset_total_qty.getDouble(4);
                    }
                    ResultSet rset_price = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + rset.getString("item_code") + "'");
                    if (rset_price.next()) {
                        v.add(rset_price.getString("main_item_sell_price"));
                        v.add(String.valueOf(total_qty));
                        v.add(Model.Object.Formated.getPriceValue(rset_price.getDouble("main_item_avarage_cost") * total_qty));
                    }
                    df.addRow(v);
                    i++;
                }
            }
        } catch (Exception e) {
            System.out.println("stock full_stock  " + e);
        }
    }

    public void location_stock(JTable tbl_stock, String location) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_stock.getModel();
            df.setRowCount(0);
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where location='" + location + "'");
            while (rset.next()) {
                ResultSet rset_price = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + rset.getString("item_code") + "'");
                if (rset_price.next()) {
                    Vector v = new Vector();
                    v.add(rset.getString(1));
                    v.add(rset.getString(2));
                    v.add(rset_price.getString(6));
                    v.add(rset.getString(4));
                    v.add(Model.Object.Formated.getPriceValue(rset_price.getDouble(6) * rset.getDouble(4)));
                    df.addRow(v);
                }
            }
        } catch (Exception e) {
            System.out.println("stock location_stock  " + e);
        }
    }
}
