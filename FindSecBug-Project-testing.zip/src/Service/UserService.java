/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPasswordField;
import javax.swing.JTextField;;
import View.FrmHome2;

/**
 *
 * @author user
 */
public class UserService {

    public void select_user(JPasswordField psw_new_password2, JLabel lbl_user_name1, JList lst_users1, JTextField txt_full_name1, JComboBox cbo_type1) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from users where user_name='" + lst_users1.getSelectedValue() + "'");
            if (rset.next()) {
                txt_full_name1.setText(rset.getString(3));
                lbl_user_name1.setText(rset.getString(1));
                cbo_type1.setSelectedItem(rset.getString(4));
                psw_new_password2.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("user select_user  " + e);
        }
    }

    public void save_new(JTextField txt_full_name, JTextField txt_user_name, JPasswordField psw_new_password, JPasswordField psw_confirem_password, JComboBox cbo_type) {
        try {
            if (txt_user_name.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_user_name();
                txt_user_name.grabFocus();
            } else if (psw_new_password.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_password();
                psw_new_password.grabFocus();
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from users where user_name='" + txt_user_name.getText() + "'");
                if (rset.next()) {
                    Model.Object.messagePopUps.user_name_exists();
                    txt_full_name.setText(null);
                    txt_user_name.setText(null);
                    psw_confirem_password.setText(null);
                    psw_new_password.setText(null);
                    cbo_type.setSelectedItem("Administrator");
                    txt_full_name.grabFocus();
                } else {
                    if (psw_new_password.getText().equals(psw_confirem_password.getText())) {
                        Model.Object.Jdbc.putdata("insert into users values('" + txt_user_name.getText() + "','" + psw_new_password.getText() + "','" + txt_full_name.getText() + "','" + cbo_type.getSelectedItem() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        Model.Object.messagePopUps.saveMessage();
                        txt_full_name.setText(null);
                        txt_user_name.setText(null);
                        psw_confirem_password.setText(null);
                        psw_new_password.setText(null);
                        cbo_type.setSelectedItem("Administrator");
                        txt_full_name.grabFocus();
                    } else {
                        Model.Object.messagePopUps.password_not_in_match();
                        psw_confirem_password.setText(null);
                        psw_confirem_password.grabFocus();
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("user save_new  " + e);
        }
    }

    public void update(JTextField txt_full_name, JLabel lbl_user_name, JPasswordField psw_current_password, JPasswordField psw_new_password, JPasswordField psw_confirem_password) {
        try {
            if (psw_new_password.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_password();
                psw_new_password.grabFocus();
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from user_login where UserName='" + lbl_user_name.getText() + "' and Password='" + psw_current_password.getText() + "'");
                if (rset.next()) {
                    if (psw_current_password.getText().equals(psw_confirem_password.getText())) {
                        Model.Object.messagePopUps.password_not_in_match();
                        psw_new_password.setText(null);
                        psw_confirem_password.setText(null);
                        psw_new_password.grabFocus();
                    } else {
                        Model.Object.Jdbc.putdata("update user_login set Password='" + psw_new_password.getText() + "' where UserName='" + lbl_user_name.getText() + "'");
                        Model.Object.messagePopUps.updateMessage();
                        lbl_user_name.setText(null);
                        psw_current_password.setText(null);
                        psw_confirem_password.setText(null);
                        psw_new_password.setText(null);
                        psw_current_password.grabFocus();
                    }
                } else {
                    Model.Object.messagePopUps.user_password_wrong();
                    psw_current_password.setText(null);
                    psw_confirem_password.setText(null);
                    psw_new_password.setText(null);
                    psw_current_password.grabFocus();
                }
            }
        } catch (Exception e) {
            System.out.println("user update  " + e);
        }
    }

    public void logoutUser() {
        try {
            Model.Object.Jdbc.putdata("insert into log_history values('" + FrmHome2.user_lbl.getText() + "','" + FrmHome2.log_time + "','" + Model.Object.Formated.todayDate() + " " + Model.Object.Formated.nowTime_1() + "','" + Model.Object.Formated.ipAddress() + "')");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
