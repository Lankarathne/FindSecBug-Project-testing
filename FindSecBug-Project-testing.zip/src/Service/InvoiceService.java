/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.table.DefaultTableModel;
import View.FrmHome2;
import View.FrmInvoiceReturn;
import View.FrmPayment;
import View.FrmcahSelector;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class InvoiceService {

    public void invoice_code_gen(JLabel lbl_invoice_number) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select max(invoice_code) from invoice_code");
            if (rset.next()) {
                lbl_invoice_number.setText("INV" + (rset.getInt(1) + 1));
            }
        } catch (Exception e) {
            System.out.println("invoice_code_gen " + e);
        }
    }

    public void invoice_all_customer_load(JComboBox invoice_all_supplier_load) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from customer_master");
            Vector v = new Vector();
            while (rset.next()) {
                v.add(rset.getString(2));
            }
            invoice_all_supplier_load.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println("invoice_all_supplier_load " + e);
        }
    }

    public void customer_item_change(JComboBox cbo_costomer_name, JLabel lbl_customer_code, JLabel lbl_customer_Due, JLabel lbl_customer_limit, JComboBox cbo_sale_type) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from customer_master where name='" + cbo_costomer_name.getSelectedItem() + "'");
            if (rset.next()) {
                Double invoice_amount = 0.00;
                Double payment = 0.00;
                Double due_amount = 0.00;
                lbl_customer_limit.setText(Model.Object.Formated.getPriceValue(rset.getDouble(5)));
                lbl_customer_code.setText(rset.getString(1));
                ResultSet rset_invoice = Model.Object.Jdbc.getdata("select sum(sub_total) from invoice_balance where customer_code='" + rset.getString(1)+ "' and payment_type='" + "Credit" + "'");
                if (rset_invoice.next()) {
                    invoice_amount = rset_invoice.getDouble(1);
                }
                ResultSet rset_payment = Model.Object.Jdbc.getdata("select sum(payment) from payments where customer_supplier_code='" +  rset.getString(1) + "' and invoice_or_grn='" + "invoice" + "'");
                if (rset_payment.next()) {
                    payment = rset_payment.getDouble(1);

                }
                due_amount = invoice_amount - payment;
                lbl_customer_Due.setText(Model.Object.Formated.getPriceValue(due_amount));
                Double limit_avg = (rset.getDouble(5) * 75) / 100;
                System.out.println(limit_avg);
                if (due_amount > limit_avg) {
                    lbl_customer_limit.setForeground(Color.red);
                    lbl_customer_Due.setForeground(Color.red);
                } else {
                    lbl_customer_limit.setForeground(Color.black);
                    lbl_customer_Due.setForeground(Color.black);
                }
            }
            Vector v = new Vector();
            if (cbo_costomer_name.getSelectedItem().toString().equals("Cash") || cbo_costomer_name.getSelectedItem().toString().equals("CASH") || cbo_costomer_name.getSelectedItem().toString().equals("cash") || cbo_costomer_name.getSelectedItem().toString().equals("cASH")) {
                v.add("Cash");
            } else {
                v.add("Cash");
                v.add("Credit");
            }
            cbo_sale_type.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println("customer_select " + e);
        }
    }

    public void item_code_key_release(JTextField txt_item_code, JList lst_item_code, JList lst_description) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code like'" + txt_item_code.getText() + "%' and location='" + "WAREHOUSE" + "'");
            Vector v_code = new Vector();
            Vector v_description = new Vector();
            while (rset.next()) {
                v_code.add(rset.getString(1));
                v_description.add(rset.getString(2));
            }
            lst_item_code.setListData(v_code);
            lst_description.setListData(v_description);

        } catch (Exception e) {
            System.out.println("item_code_key_release " + e);
        }

    }

    public void item_view_all(JTextField txt_item_code, JList lst_item_code, JList lst_description) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where location='" + "WAREHOUSE" + "'");
            Vector v_code = new Vector();
            Vector v_description = new Vector();
            while (rset.next()) {
                v_code.add(rset.getString(1));
                v_description.add(rset.getString(2));
            }
            lst_item_code.setListData(v_code);
            lst_description.setListData(v_description);

        } catch (Exception e) {
            System.out.println("item_code_key_release " + e);
        }

    }

    public void item_name_key_release(JTextField txt_description, JList lst_item_code, JList lst_description) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_name like'" + txt_description.getText() + "%' and location='" + "WAREHOUSE" + "'");
            Vector v_code = new Vector();
            Vector v_description = new Vector();
            while (rset.next()) {
                v_code.add(rset.getString(1));
                v_description.add(rset.getString(2));
            }
            lst_item_code.setListData(v_code);
            lst_description.setListData(v_description);

        } catch (Exception e) {
            System.out.println("item_name_key_release " + e);
        }

    }

    public void item_code_action(JTextField txt_quantity, JTextField lbl_sale_price, JTextField txt_item_description, JTextField txt_item_code, JList lst_item_code, JComboBox cbo_location, JLabel lbl_available_Qty) {
        try {
            if (txt_item_code.getText().isEmpty()) {
                lst_item_code.grabFocus();
                lst_item_code.setSelectedIndex(0);
            } else if (lst_item_code.getModel().getSize() == 1) {
                ListModel model = lst_item_code.getModel();
                Object o = model.getElementAt(0);
                ResultSet rset_item_master = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + o.toString() + "'");
                if (rset_item_master.next()) {
                    ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + o.toString() + "' and location='" + cbo_location.getSelectedItem() + "'");
                    if (rset.next()) {
                        if (rset.getDouble(4) < 10) {
                            lbl_available_Qty.setForeground(Color.red);
                        } else {
                            lbl_available_Qty.setForeground(Color.black);
                        }
                        lbl_available_Qty.setText(Model.Object.Formated.getPriceValue(rset.getDouble(4)));
                    } else {
                        lbl_available_Qty.setText("0.00");
                    }
                    txt_item_description.setText(rset_item_master.getString(2));
                    txt_item_code.setText(rset_item_master.getString(1));
                    lbl_sale_price.setText(Model.Object.Formated.getPriceValue(rset_item_master.getDouble(6)));
                    cbo_location.grabFocus();
                    lst_item_code.setSelectedIndex(0);
                } else {
                    Model.Object.messagePopUps.Item_number_dosesnot_match();
                    txt_item_code.grabFocus();
                    txt_item_code.selectAll();
                }
            } else if (lst_item_code.getModel().getSize() == 0) {
                Model.Object.messagePopUps.Item_number_dosesnot_match();
                txt_item_code.grabFocus();
                txt_item_code.selectAll();
            } else {
                lst_item_code.setSelectedIndex(0);
                lst_item_code.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("invoice item_code_action " + e);
        }
    }

    public void item_code_list_value_change(JList lst_description, JTextField lbl_sale_price, JTextField txt_item_code, JTextField txt_item_description, JLabel lbl_available_Qty, JList lst_item_code, JComboBox cbo_location, JCheckBox chb_wholesale, JLabel lbl_avarge_cost, JLabel lbl_label_price) {
        try {
            lst_description.setSelectedIndex(lst_item_code.getSelectedIndex());
            int i = lst_item_code.getSelectedIndex();
            lst_item_code.setSelectedIndex(i);
            lst_description.ensureIndexIsVisible(lst_item_code.getSelectedIndex());
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + lst_item_code.getSelectedValue() + "' and location='" + cbo_location.getSelectedItem() + "'");
            if (rset.next()) {
                if (rset.getDouble(4) < 10) {
                    lbl_available_Qty.setForeground(Color.red);
                } else {
                    lbl_available_Qty.setForeground(Color.black);
                }
                lbl_available_Qty.setText(Model.Object.Formated.getPriceValue(rset.getDouble(4)));
                lbl_avarge_cost.setText(Model.Object.Formated.getPriceValue(rset.getDouble(3)));
            } else {
                lbl_available_Qty.setText("0.00");
                lbl_avarge_cost.setText("0.00");
            }
            ResultSet rset_item_master = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + lst_item_code.getSelectedValue() + "'");
            if (rset_item_master.next()) {
                txt_item_code.setText(rset_item_master.getString(1));
                txt_item_description.setText(rset_item_master.getString(2));
                if (chb_wholesale.isSelected()) {
                    lbl_sale_price.setText(Model.Object.Formated.getPriceValue(rset_item_master.getDouble(4)));
                } else {
                    lbl_sale_price.setText(Model.Object.Formated.getPriceValue(rset_item_master.getDouble(6)));
                }
                lbl_label_price.setText(Model.Object.Formated.getPriceValue(rset_item_master.getDouble(4)));
            } else {
                lbl_sale_price.setText("0.00");
                txt_item_description.setText(null);
            }
        } catch (Exception e) {
            System.out.println("inoice item_code_enter  " + e);
        }
    }

    public void item_list_key_press(JList lst_item_code, JComboBox cbo_location, JTextField txt_quantity, KeyEvent evt) {
        try {
            if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                int i = lst_item_code.getSelectedIndex();
                txt_quantity.grabFocus();
                lst_item_code.setSelectedIndex(i);
            }
        } catch (Exception e) {
            System.out.println("invoice item_list key_press " + e);
        }
    }

    public void available_stock(JComboBox cbo_location, JLabel lbl_available_Qty, JList lst_item_code) {
        try {

            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + lst_item_code.getSelectedValue() + "' and location='" + cbo_location.getSelectedItem() + "'");
            if (rset.next()) {
                lbl_available_Qty.setText(rset.getString(4));
                if (rset.getDouble(4) < 10) {
                    lbl_available_Qty.setForeground(Color.red);
                } else {
                    lbl_available_Qty.setForeground(Color.black);
                }
            } else {
                cbo_location.grabFocus();
                lbl_available_Qty.setText("0.00");
            }
        } catch (Exception e) {
            System.out.println("invoice available_stock " + e);
        }
    }

    public void quantity_action(JLabel lbl_available_Qty, JTextField txt_quantity, JLabel lbl_item_amount, JTextField txt_item_discount, JTextField lbl_sale_price) {
        try {
            if (txt_quantity.getText().isEmpty()) {
                Model.Object.messagePopUps.Quantity_Empty();
                txt_quantity.grabFocus();
            } else if (lbl_sale_price.getText().isEmpty()) {
                Model.Object.messagePopUps.item_amount_empty_witout_dis();
                txt_quantity.grabFocus();

//            } else if (Double.parseDouble(txt_quantity.getText()) > Double.parseDouble(lbl_available_Qty.getText())) {
//                Model.Object.messagePopUps.Exceed_Quantity();
//                txt_quantity.grabFocus();
//                txt_quantity.selectAll();
//                lbl_item_amount.setText(null);
            } else {
                lbl_item_amount.setText(Model.Object.Formated.getPriceValue((Double.parseDouble(txt_quantity.getText()) * Double.parseDouble(lbl_sale_price.getText()))));
                txt_item_discount.grabFocus();
                txt_item_discount.selectAll();
            }
        } catch (Exception e) {
            System.out.println("invoice quantity_action " + e);
        }
    }

    public void item_discount_action(JTextField txt_quantity, JLabel lbl_item_amount, JTextField txt_item_discount, JLabel lbl_item_net_amount, JButton btn_item_add) {
        try {
            if (txt_item_discount.getText().isEmpty()) {
                txt_item_discount.setText("0.00");
            }
            if (lbl_item_amount.getText().isEmpty() || lbl_item_amount.getText() == null) {
                Model.Object.messagePopUps.item_amount_empty();
                txt_quantity.grabFocus();
            } else {
                txt_item_discount.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(txt_item_discount.getText())));
                Double discount = Double.parseDouble(lbl_item_amount.getText()) * Double.parseDouble(txt_item_discount.getText()) / 100;
                lbl_item_net_amount.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(lbl_item_amount.getText()) - discount));
                btn_item_add.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("invoice item_discount_action " + e);
        }
    }

    public void item_add(JScrollPane jScrollPane4, JLabel lbl_sub_total, JTextField txt_total_discount, JLabel lbl_total_amount, JLabel lbl_available_Qty, JList lst_item_code, JList lst_description, JTextField txt_item_code, JTextField txt_item_description, JComboBox cbo_location, JTextField lbl_sale_price, JTextField txt_quantity, JLabel lbl_item_amount, JTextField txt_item_discount, JLabel lbl_item_net_amount, JTable tbl_invoice, JLabel lbl_avarge_cost, JLabel lbl_label_price, JLabel lbl_total_profit) {
        try {
            if (txt_item_code.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_item_code();
                txt_item_code.grabFocus();
            } else if (txt_item_description.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_item_description();
                txt_item_description.grabFocus();
            } else if (lbl_sale_price.getText().isEmpty()) {
                Model.Object.messagePopUps.item_sell_price_empty();
                txt_item_code.grabFocus();
            } else if (txt_quantity.getText().isEmpty() || txt_quantity.getText().equals("0")) {
                Model.Object.messagePopUps.Quantity_Empty();
                txt_quantity.grabFocus();
            } else if (lbl_item_amount.getText().isEmpty()) {
                Model.Object.messagePopUps.item_amount_empty_witout_dis();
                txt_quantity.grabFocus();
            } else if (txt_item_discount.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_discount();
                txt_item_discount.grabFocus();
            } else if (lbl_item_net_amount.getText().isEmpty()) {
                Model.Object.messagePopUps.net_amount_empty();
                txt_item_discount.grabFocus();
//            }            else if (Double.parseDouble(txt_quantity.getText()) > Double.parseDouble(lbl_available_Qty.getText())) {
//                Model.Object.messagePopUps.Exceed_Quantity();
//                txt_quantity.grabFocus();
//                txt_item_discount.setText(null);
//                lbl_item_amount.setText(null);
//                lbl_item_net_amount.setText(null);
//                txt_quantity.selectAll();
            } else {
                boolean bool = false;
                DefaultTableModel df = (DefaultTableModel) tbl_invoice.getModel();
                for (int i = 0; i < df.getRowCount(); i++) {
                    if (df.getValueAt(i, 0).toString().equals(txt_item_code.getText())) {
                        if (df.getValueAt(i, 6).toString().equals("100")) {
                            bool = true;
                            break;
                        }
                    }
                }
                if (bool) {
                    Model.Object.messagePopUps.Duplicate_entry();
                    txt_item_code.setText(null);
                    txt_item_description.setText(null);
                    //    cbo_location.setSelectedItem("OUTLET");
                    lbl_available_Qty.setText(null);
                    lbl_sale_price.setText(null);
                    txt_quantity.setText(null);
                    lbl_item_amount.setText(null);
                    txt_item_discount.setText(null);
                    lbl_item_net_amount.setText(null);
                    lbl_avarge_cost.setText(null);
                    lbl_label_price.setText(null);
                    item_view_all(txt_item_code, lst_item_code, lst_description);
                    txt_item_description.grabFocus();
                } else {
                    int over = JOptionPane.YES_OPTION;
                    Double pro = (Double.parseDouble(lbl_item_net_amount.getText())) - (Double.parseDouble(lbl_avarge_cost.getText()) * Double.parseDouble(txt_quantity.getText()));
                    if (String.valueOf(String.valueOf(pro).charAt(0)).equals("-")) {
                        over = Model.Object.messagePopUps.Loss();
                    }

                    if (over == JOptionPane.YES_OPTION) {
                        Vector v = new Vector();
                        v.add(txt_item_code.getText());
                        v.add(txt_item_description.getText());
                        v.add(cbo_location.getSelectedItem());
                        v.add(lbl_sale_price.getText());
                        v.add(txt_quantity.getText());
                        v.add(lbl_item_amount.getText());
                        v.add(txt_item_discount.getText());
                        v.add(lbl_item_net_amount.getText());
                        v.add("0.00");
                        v.add(lbl_item_net_amount.getText());
                        Double profit = 0.00;
                        ResultSet rset_profit = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + txt_item_code.getText() + "' and location='" + cbo_location.getSelectedItem() + "'");
                        if (rset_profit.next()) {
                            profit = (Double.parseDouble(lbl_item_net_amount.getText())) - (rset_profit.getDouble(3) * Double.parseDouble(txt_quantity.getText()));
                        }
                        v.add(Model.Object.Formated.getPriceValue(profit));
                        df.addRow(v);
                        Model.Object.messagePopUps.Data_Added_Successfully();
                        Double total_amount = 0.00;
                        Double total_profit = 0.00;
                        DefaultTableModel df_add_after = (DefaultTableModel) tbl_invoice.getModel();
                        for (int i = 0; i < df_add_after.getRowCount(); i++) {
                            total_amount = total_amount + Double.parseDouble(df_add_after.getValueAt(i, 7).toString());
                            total_profit = total_profit + Double.parseDouble(df.getValueAt(i, 10).toString());
                        }
                        lbl_total_profit.setText(Model.Object.Formated.getPriceValue(total_profit));
                        lbl_total_amount.setText(Model.Object.Formated.getPriceValue(total_amount));
                        txt_item_code.setText(null);
                        txt_item_description.setText(null);
                        // cbo_location.setSelectedItem("OUTLET");
                        lbl_available_Qty.setText(null);
                        lbl_sale_price.setText(null);
                        txt_quantity.setText(null);
                        lbl_item_amount.setText(null);
                        txt_item_discount.setText(null);
                        lbl_item_net_amount.setText(null);
                        lbl_sub_total.setText(null);
                        txt_total_discount.setText(null);
                        lbl_avarge_cost.setText(null);
                        lbl_label_price.setText(null);
                        item_view_all(txt_item_code, lst_item_code, lst_description);
                        JScrollBar vertical = jScrollPane4.getVerticalScrollBar();
                        vertical.setValue(vertical.getMaximum());
                        txt_item_description.grabFocus();
                    } else {
                        txt_item_code.setText(null);
                        txt_item_description.setText(null);
                        // cbo_location.setSelectedItem("OUTLET");
                        lbl_available_Qty.setText(null);
                        lbl_sale_price.setText(null);
                        txt_quantity.setText(null);
                        lbl_item_amount.setText(null);
                        txt_item_discount.setText(null);
                        lbl_item_net_amount.setText(null);
                        lbl_sub_total.setText(null);
                        txt_total_discount.setText(null);
                        lbl_avarge_cost.setText(null);
                        lbl_label_price.setText(null);
                        item_view_all(txt_item_code, lst_item_code, lst_description);
                        JScrollBar vertical = jScrollPane4.getVerticalScrollBar();
                        vertical.setValue(vertical.getMaximum());
                        txt_item_description.grabFocus();
                    }

                }
            }
        } catch (Exception e) {
            System.out.println("invoice item_add " + e);
        }
    }

    public void total_dicount_action(JTable tbl_invoice, JLabel lbl_total_net_amount, JTextField txt_item_code, JLabel lbl_total_amount, JTextField txt_total_discount, JLabel lbl_return_amount, JLabel lbl_sub_total, JComboBox cbo_sale_type, JTextField txt_cash_payment) {
        try {
            if (lbl_total_amount.getText().isEmpty()) {
                Model.Object.messagePopUps.total_amount_empty();
                txt_item_code.grabFocus();
            } else {
                if (txt_total_discount.getText().isEmpty()) {
                    txt_total_discount.setText("0.00");
                }
                txt_total_discount.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(txt_total_discount.getText())));
                Double discount = (Double.parseDouble(lbl_total_amount.getText()) * Double.parseDouble(txt_total_discount.getText())) / 100;
                lbl_total_net_amount.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(lbl_total_amount.getText()) - discount));

                Double return_amount = 0.00;
                if (lbl_return_amount.getText() == null || lbl_return_amount.getText().isEmpty()) {
                    return_amount = 0.00;
                    lbl_return_amount.setText("0.00");
                } else {
                    return_amount = Double.parseDouble(lbl_return_amount.getText());
                }
                lbl_sub_total.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(lbl_total_net_amount.getText()) - return_amount));
                DefaultTableModel df = (DefaultTableModel) tbl_invoice.getModel();
                for (int i = 0; i < df.getRowCount(); i++) {
                    Double sub_total = (Double.parseDouble(df.getValueAt(i, 7).toString()) * Double.parseDouble(txt_total_discount.getText())) / 100;
                    df.setValueAt((Model.Object.Formated.getPriceValue((Double.parseDouble(df.getValueAt(i, 7).toString()) - sub_total))), i, 9);

                    Double profit = 0.00;
                    Double total_discount = Double.parseDouble(df.getValueAt(i, 7).toString()) * Double.parseDouble(txt_total_discount.getText()) / 100;
                    Double now_item_amount = Double.parseDouble(df.getValueAt(i, 7).toString()) - total_discount;
                    ResultSet rset = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + df.getValueAt(i, 0) + "'");
                    if (rset.next()) {
                        profit = now_item_amount - (rset.getDouble(5) * Double.parseDouble(df.getValueAt(i, 4).toString()));
                    }
                    df.setValueAt(txt_total_discount.getText(), i, 8);
                    df.setValueAt(Model.Object.Formated.getPriceValue(profit), i, 10);
                }
                if (cbo_sale_type.getItemCount() == 1) {
                    txt_cash_payment.grabFocus();
                    if (cbo_sale_type.getSelectedItem().toString().equals("Cash")) {
                        FrmcahSelector cs = new FrmcahSelector(null, true);
                        cs.setVisible(true);
                        // cs.setLocation(540, 600);
                    }
                } else {
                    cbo_sale_type.grabFocus();
                }

            }
        } catch (Exception e) {
            System.out.println("invoice total_dicount_action " + e);
        }
    }

    public void cash_pay_action(JComboBox cbo_sale_type, JLabel lbl_sub_total, JTextField txt_cash_payment, JLabel lbl_balance, JButton btn_save_print) {
        try {
            if (lbl_sub_total.getText().isEmpty() || lbl_sub_total.getText() == null) {
                Model.Object.messagePopUps.sub_total_empty();
                txt_cash_payment.grabFocus();
            } else {
                if (txt_cash_payment.getText().isEmpty()) {
                    txt_cash_payment.setText("0.00");;
                }
                boolean bool = false;
                if (cbo_sale_type.getSelectedItem().toString().equals("Credit")) {
                    if (Double.parseDouble(lbl_sub_total.getText()) < Double.parseDouble(txt_cash_payment.getText())) {
                        Model.Object.messagePopUps.paymet_High();
                        txt_cash_payment.grabFocus();
                        txt_cash_payment.selectAll();
                        bool = true;
                    } else {
                        bool = false;
                    }
                } else {
                    if (txt_cash_payment.getText().equals("0.00")) {
                        txt_cash_payment.setText(lbl_sub_total.getText());
                    }
                    if (Double.parseDouble(txt_cash_payment.getText()) < Double.parseDouble(lbl_sub_total.getText())) {
                        Model.Object.messagePopUps.paymet_low();
                        txt_cash_payment.grabFocus();
                        txt_cash_payment.selectAll();
                        bool = true;
                    } else {
                        bool = false;
                    }
                }
                if (bool == false) {
                    if (txt_cash_payment.getText().isEmpty() || txt_cash_payment.getText() == null) {
                        txt_cash_payment.setText(lbl_sub_total.getText());
                    }
                    txt_cash_payment.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(txt_cash_payment.getText())));
                    lbl_balance.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(txt_cash_payment.getText()) - Double.parseDouble(lbl_sub_total.getText())));
                    btn_save_print.grabFocus();
                }
            }
        } catch (Exception e) {
            System.out.println("invoice cash_pay_action " + e);
        }
    }

    public void save_print(JTable tbl_invoice, JLabel lbl_customer_code, JLabel lbl_invoice_number, JComboBox cboCustomerName, JTextField txt_invoice_date, JLabel lbl_total_amount, JTextField txt_total_discount, JLabel lbl_total_net_amount, JLabel lbl_return_amount, JLabel lbl_sub_total, JComboBox cbo_sale_type, JTextField txt_cash_payment, JLabel lbl_balance,JLabel lbl_total_profit) {
        try {
            if (lbl_invoice_number.getText().isEmpty()) {
                Model.Object.messagePopUps.invoice_code_empty();
            } else if (lbl_customer_code.getText().isEmpty()) {
                Model.Object.messagePopUps.invoice_select_customer();
                cboCustomerName.grabFocus();
            } else if (txt_invoice_date.getText().isEmpty()) {
                Model.Object.messagePopUps.invoice_date_empty();
                txt_invoice_date.grabFocus();
            } else if (tbl_invoice.getRowCount() == 0) {
                Model.Object.messagePopUps.table_empty();
                txt_invoice_date.grabFocus();
            } else if (lbl_total_amount.getText().isEmpty()) {
                Model.Object.messagePopUps.total_amount_empty();
                txt_invoice_date.grabFocus();
            } else if (txt_total_discount.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_total_discount();
                txt_total_discount.grabFocus();
            } else if (lbl_total_net_amount.getText().isEmpty()) {
                Model.Object.messagePopUps.net_amount_empty();
                txt_total_discount.grabFocus();
            } else if (lbl_sub_total.getText().isEmpty()) {
                Model.Object.messagePopUps.sub_total_empty();
                txt_total_discount.grabFocus();
            } else if (txt_cash_payment.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_cash_payment();
                txt_cash_payment.grabFocus();
            } else if (lbl_balance.getText().isEmpty()) {
                Model.Object.messagePopUps.balance_empty();
                txt_cash_payment.grabFocus();
            } else if (cbo_sale_type.getSelectedItem().toString() == null || cbo_sale_type.getSelectedItem().toString().isEmpty()) {
                Model.Object.messagePopUps.please_select_customer();
                cboCustomerName.grabFocus();
            } else {
                DefaultTableModel df = (DefaultTableModel) tbl_invoice.getModel();
                Double total_profit = 0.00;
                for (int i = 0; i < df.getRowCount(); i++) {
                    Double recent_qty = 0.00;
                    ResultSet rset_all_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "'");
                    while (rset_all_qty.next()) {
                        recent_qty = recent_qty + rset_all_qty.getDouble(4);
                    }
                    Double location_recent_qty = 0.0;
                    ResultSet rset_location_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 2) + "'");
                    if (rset_location_qty.next()) {
                        location_recent_qty = rset_location_qty.getDouble(4);
                    }
                    Double updated_quantity = 0.00;
                    ResultSet rset_stock = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 2) + "'");
                    if (rset_stock.next()) {
                        updated_quantity = rset_stock.getDouble("stock") - Double.parseDouble(df.getValueAt(i, 4).toString());
                        Model.Object.Jdbc.putdata("update item_inventory set stock='" + updated_quantity + "' where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 2) + "'");
                    }
                    total_profit = total_profit + Double.parseDouble(df.getValueAt(i, 10).toString());
                    Model.Object.Jdbc.putdata("insert into invoice_item values('" + lbl_invoice_number.getText() + "','" + df.getValueAt(i, 0) + "','" + df.getValueAt(i, 1) + "','" + df.getValueAt(i, 2) + "','" + df.getValueAt(i, 3) + "','" + "Type" + "','" + df.getValueAt(i, 4) + "','" + df.getValueAt(i, 5) + "','" + "Percentage" + "','" + df.getValueAt(i, 6) + "','" + df.getValueAt(i, 7) + "','" + df.getValueAt(i, 8) + "','" + df.getValueAt(i, 9) + "','" + df.getValueAt(i, 10) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "','" + lbl_customer_code.getText()+ "')");
                    //add transaction 
                    Model.Object.Jdbc.putdata("insert into transaction values('" + df.getValueAt(i, 0) + "','" + lbl_invoice_number.getText() + "','" + txt_invoice_date.getText() + "','" + recent_qty + "','" + "0.0" + "','" + df.getValueAt(i, 4) + "','" + (recent_qty - Double.parseDouble(df.getValueAt(i, 4).toString())) + "','" + "Invoice" + "','" + df.getValueAt(i, 2) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                    Model.Object.Jdbc.putdata("insert into Location_wise_transaction values('" + df.getValueAt(i, 0) + "','" + lbl_invoice_number.getText() + "','" + txt_invoice_date.getText() + "','" + location_recent_qty + "','" + "0.0" + "','" + df.getValueAt(i, 4) + "','" + (location_recent_qty - Double.parseDouble(df.getValueAt(i, 4).toString())) + "','" + "Invoice" + "','" + df.getValueAt(i, 2) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");

                    Model.Object.Jdbc.putdata("update item_master set main_item_sell_price='" + df.getValueAt(i, 3) + "' where item_code='" + df.getValueAt(i, 0) + "'");
                }
                String invoice_status = "0";
                if (cbo_sale_type.getSelectedItem().toString().equals("Credit")) {
                    invoice_status = "0";
                    Model.Object.Jdbc.putdata("insert into payments value('" + "0" + "','" + "invoice" + "','" + lbl_invoice_number.getText() + "','" + lbl_customer_code.getText() + "','" + lbl_sub_total.getText() + "','" + txt_cash_payment.getText() + "','" + Math.abs(Double.parseDouble(lbl_balance.getText())) + "',NOW(),'" + "Cash" + "','" + "0" + "','" + "" + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                } else {
                    invoice_status = "1";
                }
                Model.Object.Jdbc.putdata("insert into invoice_balance values('" + lbl_invoice_number.getText() + "','" + lbl_customer_code.getText() + "','" + txt_invoice_date.getText() + "','" + lbl_total_amount.getText() + "','" + "Percentage" + "','" + txt_total_discount.getText() + "','" + lbl_total_net_amount.getText() + "','" + lbl_return_amount.getText() + "','" + lbl_sub_total.getText() + "','" + cbo_sale_type.getSelectedItem() + "','" + txt_cash_payment.getText() + "','" + Math.abs(Double.parseDouble(lbl_balance.getText())) + "','" + total_profit + "','" + invoice_status + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                Model.Object.Jdbc.putdata("insert into invoice_code values('" + "0" + "')");
                if (cbo_sale_type.getSelectedItem().equals("Credit")) {
                    if (!txt_cash_payment.getText().equals("0.00")) {
                        Model.Object.paymentVeryfication.save_new(lbl_customer_code.getText(), lbl_invoice_number.getText(), cboCustomerName.getSelectedItem().toString(), "From a " + cboCustomerName.getSelectedItem().toString() + " Payment of Rs." + txt_cash_payment.getText() + " by Cash", "Invoice");
                    }
                }
                if (lbl_return_amount.getText() == null || lbl_return_amount.getText().isEmpty() || lbl_return_amount.getText().equals("0.00")) {
                } else {
                    FrmInvoiceReturn.new_invo_code = lbl_invoice_number.getText();
                    FrmInvoiceReturn.return_type = "Invoice";
                    FrmInvoiceReturn.btn_end_return.doClick();
                }
                //print
                int i = Model.Object.messagePopUps.print();
                if (i == JOptionPane.YES_OPTION) {
                    Model.Object.report.poss_invoice(lbl_invoice_number);
                } else {
                    Model.Object.report.empty_poss();
                }
                Model.Object.messagePopUps.saveMessage();
                lbl_balance.setText(null);
                cboCustomerName.setSelectedItem("[ Select ]");
                lbl_customer_code.setText(null);
                lbl_invoice_number.setText(null);
                lbl_return_amount.setText(null);
                lbl_sub_total.setText(null);
                lbl_total_amount.setText(null);
                lbl_total_net_amount.setText(null);
                Vector v = new Vector();
                v.add("");
                lbl_total_profit.setText(null);
                cbo_sale_type.setModel(new DefaultComboBoxModel(v));
                txt_cash_payment.setText(null);
                txt_invoice_date.setText(Model.Object.Formated.todayDate());
                txt_total_discount.setText(null);
                invoice_code_gen(lbl_invoice_number);
                cboCustomerName.grabFocus();
                df.setRowCount(0);

            }
        } catch (Exception e) {
            System.out.println("invoice save_print " + e);
        }
    }
}
