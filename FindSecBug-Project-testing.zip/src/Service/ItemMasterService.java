/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import View.FrmHome2;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class ItemMasterService {

    public void item_code_check(JTextField txt_item_code, JTextField txt_item_desccription) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + txt_item_code.getText() + "'");
            if (rset.next()) {
                Model.Object.messagePopUps.item_code_duplicate();
                txt_item_code.grabFocus();
                txt_item_code.selectAll();
            } else {
                txt_item_desccription.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("Item Code Check " + e);
        }
    }

    public void save_item(JTextField txt_minimum_qty, JTextField txt_item_code, JTextField txt_item_desccription, JComboBox cbo_item_category, JTextField txt_cost_price, JTextField txt_selling_price, JTable tbl_item, JComboBox cbo_measurement) {
        try {
            if (txt_item_code.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_item_code();
                txt_item_code.grabFocus();
            } else if (txt_item_desccription.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_item_description();
                txt_item_desccription.grabFocus();
            } else if (cbo_item_category.getSelectedItem().toString().isEmpty() || cbo_item_category.getSelectedItem().toString() == null) {
                Model.Object.messagePopUps.enter_item_category();
                cbo_item_category.grabFocus();
            } else if (txt_cost_price.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_item_cost();
                txt_cost_price.grabFocus();
            } else if (txt_selling_price.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_item_sall_pricet();
                txt_selling_price.grabFocus();
            } else if (txt_minimum_qty.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_minimun_qty();
                txt_minimum_qty.grabFocus();
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + txt_item_code.getText() + "'");
                if (rset.next()) {
                    Model.Object.messagePopUps.item_code_duplicate();
                    txt_item_code.setText(null);
                    txt_cost_price.setText(null);
                    txt_minimum_qty.setText(null);
                    txt_item_desccription.setText(null);
                    txt_selling_price.setText(null);
                    cbo_item_category.setSelectedItem("Default Type");
                    txt_item_code.grabFocus();
                } else {
                    ResultSet rset1 = Model.Object.Jdbc.getdata("select* from item_master where  item_description='" + txt_item_desccription.getText() + "'");
                    if (rset1.next()) {
                        Model.Object.messagePopUps.item_name_duplicate();
                        txt_item_code.setText(null);
                        txt_cost_price.setText(null);
                        txt_minimum_qty.setText(null);
                        txt_item_desccription.setText(null);
                        txt_selling_price.setText(null);
                        cbo_item_category.setSelectedItem("Default Type");
                        txt_item_code.grabFocus();
                    } else {
                        Model.Object.Jdbc.putdata("insert into item_master values('" + txt_item_code.getText() + "','" + txt_item_desccription.getText() + "','" + cbo_item_category.getSelectedItem() + "','" + txt_cost_price.getText() + "','" + txt_cost_price.getText() + "','" + txt_selling_price.getText() + "','" + cbo_measurement.getSelectedItem() + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "Supplier Number Not Load" + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        Model.Object.Jdbc.putdata("insert into minimum_qty values('" + txt_item_code.getText() + "','" + txt_minimum_qty.getText() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        Model.Object.messagePopUps.saveMessage();
                        DefaultTableModel df = (DefaultTableModel) tbl_item.getModel();
                        Vector v = new Vector();
                        v.add(txt_item_code.getText());
                        v.add(txt_item_desccription.getText());
                        v.add(cbo_item_category.getSelectedItem());
                        v.add(Model.Object.Formated.getPriceValue(Double.parseDouble(txt_cost_price.getText())));
                        v.add(Model.Object.Formated.getPriceValue(Double.parseDouble(txt_selling_price.getText())));
                        df.addRow(v);
                        txt_item_code.setText(null);
                        txt_cost_price.setText(null);
                        txt_item_desccription.setText(null);
                        txt_selling_price.setText(null);
                        txt_minimum_qty.setText(null);
                        Model.Object.ItemMaster.category_load(cbo_item_category);
                        cbo_item_category.setSelectedItem("Default Type");
                        txt_item_code.grabFocus();
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Save Item " + e);
        }
    }

    public void new_mesurement(JComboBox cbo_measurement) {
        try {
            String unit = Model.Object.messagePopUps.enter_mesurment_unit();
            if (unit == null || unit.isEmpty()) {
                Model.Object.messagePopUps.enter_valid_unit();
                cbo_measurement.grabFocus();
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from MeasurmentUnit where unit='" + unit+ "' ");
                if (rset.next()) {
                    Model.Object.messagePopUps.duplicate();
                    cbo_measurement.grabFocus();
                } else {
                    Model.Object.Jdbc.putdata("insert into MeasurmentUnit values('" + unit + "')");
                    Model.Object.messagePopUps.saveMessage();
                    Vector v = new Vector();
                    ResultSet rset_search = Model.Object.Jdbc.getdata("select* from MeasurmentUnit");
                    while (rset_search.next()) {
                        v.add(rset_search.getString(1));
                    }
                    cbo_measurement.setModel(new DefaultComboBoxModel(v));
                    cbo_measurement.grabFocus();
                }
            }
        } catch (Exception e) {
            System.out.println("new_mesurement " + e);
        }
    }

    public void Al_item_serch(JTextField txt_item_search_code, JTable tbl_item) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_item.getModel();
            df.setRowCount(0);
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_master");
            while (rset.next()) {
                Vector v = new Vector();
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                v.add(rset.getString(3));
                v.add(Model.Object.Formated.getPriceValue(rset.getDouble(4)));
                v.add(Model.Object.Formated.getPriceValue(rset.getDouble(6)));
                df.addRow(v);
            }

        } catch (Exception e) {
            System.out.println("Al_item_serch " + e);
        }
    }

    public void like_search(JTextField txt_item_search_code, JTable tbl_item) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_item.getModel();
            df.setRowCount(0);
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_master where item_description like'" + txt_item_search_code.getText() + "%'");
            while (rset.next()) {
                Vector v = new Vector();
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                v.add(rset.getString(3));
                v.add(Model.Object.Formated.getPriceValue(rset.getDouble(4)));
                v.add(Model.Object.Formated.getPriceValue(rset.getDouble(6)));
                df.addRow(v);
            }
        } catch (Exception e) {
            System.out.println("like_searc " + e);
        }
    }

    public void category_load(JComboBox cbo_item_category) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select category from item_master group by category");
            Vector v = new Vector();            
            while (rset.next()) {
                v.add(rset.getString(1));
            }
            cbo_item_category.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println("category_load " + e);
        }
    }
}
