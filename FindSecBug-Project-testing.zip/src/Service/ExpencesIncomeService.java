/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import View.FrmHome2;

/**
 *
 * @author user
 */
public class ExpencesIncomeService {

    public void code_gen(JLabel lbl_InExCode) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select max(ex_code) from expense_code");
            if (rset.next()) {
                lbl_InExCode.setText("INEX" + (rset.getInt(1) + 1));
            } else {
                lbl_InExCode.setText(null);
            }
        } catch (Exception e) {
            System.out.println("expense code_gen  " + e);
        }
    }

    public void add(JLabel lbl_InExCode, JComboBox cbo_expencess_type, JTextField txt_bill_code, JTextField txt_bill_date, JComboBox cbo_category, JTextField txt_amount, JTextArea txtar_description, JTable tbl_expenses, JLabel lbl_total_income, JLabel lbl_total_expences) {
        try {
            if (txt_bill_date.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_date();
                txt_bill_date.grabFocus();
            } else if (txt_amount.getText().isEmpty()) {
                Model.Object.messagePopUps.Amount_Empty();
                txt_amount.grabFocus();
            } else {
                DefaultTableModel df = (DefaultTableModel) tbl_expenses.getModel();
                Vector v = new Vector();
                v.add(cbo_expencess_type.getSelectedItem().toString());
                v.add(txt_bill_code.getText());
                v.add(txt_bill_date.getText());
                v.add(cbo_category.getSelectedItem());
                v.add(txt_amount.getText());
                v.add(txtar_description.getText());
                df.addRow(v);
                Double total_income = 0.00;
                Double total_expense = 0.00;
                for (int i = 0; i < tbl_expenses.getRowCount(); i++) {
                    if (tbl_expenses.getValueAt(i, 0).toString().equals("Expenses")) {
                        total_expense = total_expense + Double.parseDouble(tbl_expenses.getValueAt(i, 4).toString());
                    } else {
                        total_income = total_income + Double.parseDouble(tbl_expenses.getValueAt(i, 4).toString());
                    }
                }
                lbl_total_income.setText(Model.Object.Formated.getPriceValue(total_income));
                lbl_total_expences.setText(Model.Object.Formated.getPriceValue(total_expense));
                Model.Object.messagePopUps.Data_Added_Successfully();
                cbo_expencess_type.setSelectedItem("Expenses");
                txt_amount.setText(null);
                txt_bill_code.setText(null);
                txt_bill_date.setText(null);
                txtar_description.setText(null);
                cbo_category.setSelectedItem("Advertising");
                cbo_expencess_type.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("expense add " + e);
        }
    }

    public void save(JTable tbl_expenses, JLabel lbl_InExCode, JComboBox cbo_expencess_type) {
        try {
            if (tbl_expenses.getRowCount() <= 0) {
                Model.Object.messagePopUps.cannt_find_expense_details();
                cbo_expencess_type.grabFocus();
            } else {
                DefaultTableModel df = (DefaultTableModel) tbl_expenses.getModel();
                for (int i = 0; i < df.getRowCount(); i++) {
                    Model.Object.Jdbc.putdata("insert into expenses_income values('" + lbl_InExCode.getText() + "','" + df.getValueAt(i, 0) + "','" + df.getValueAt(i, 1) + "','" + df.getValueAt(i, 2) + "','" + df.getValueAt(i, 3) + "','" + df.getValueAt(i, 4) + "','" + df.getValueAt(i, 5) + "','"+""+"',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                }
                Model.Object.Jdbc.putdata("insert into expense_code values('"+"0"+"')");
                Model.Object.messagePopUps.saveMessage();
                code_gen(lbl_InExCode);
                df.setRowCount(0);
                cbo_expencess_type.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("expense save " + e);
        }
    }

    public void delete_row(JTable tbl_expenses, JLabel lbl_total_income, JLabel lbl_total_expences) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_expenses.getModel();
            int j = Model.Object.messagePopUps.do_you_want_delete_record_confirem_msg();
            if (j == JOptionPane.YES_OPTION) {
                df.removeRow(tbl_expenses.getSelectedRow());
            }
            Double total_income = 0.00;
            Double total_expense = 0.00;
            for (int i = 0; i < tbl_expenses.getRowCount(); i++) {
                if (tbl_expenses.getValueAt(i, 0).toString().equals("Expenses")) {
                    total_expense = total_expense + Double.parseDouble(tbl_expenses.getValueAt(i, 4).toString());
                } else {
                    total_income = total_income + Double.parseDouble(tbl_expenses.getValueAt(i, 4).toString());
                }
            }
        } catch (Exception e) {
            System.out.println("expense delete row " + e);
        }
    }
}
