/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import View.FrmHome2;
import View.FrmPayment;
import static View.FrmPayment.cbo_customer_code;
import static View.FrmPayment.cbo_pay_type;
import static View.FrmPayment.cbo_type;
import static View.FrmPayment.lbl_balance;
import static View.FrmPayment.lbl_due_amount;
import static View.FrmPayment.lbl_invoice_total;
import static View.FrmPayment.lbl_payed_amount;
import static View.FrmPayment.lst_invoice_code;
import static View.FrmPayment.tbl_invoice_details;
import static View.FrmPayment.tbl_past_payment;
import static View.FrmPayment.txt_paying_amount;

/**
 *
 * @author user
 */
public class PaymentService {

    public void sup_cus_load(JTable tbl_past_payment, JTable tbl_invoice_details, JLabel lbl_invoice_total, JLabel lbl_payed_amount, JLabel lbl_due_amount, JComboBox cbo_type, JComboBox cbo_customer_code, JList lst_invoice_code) {
        try {
            DefaultTableModel df_1 = (DefaultTableModel) tbl_invoice_details.getModel();
            df_1.setRowCount(0);
            DefaultTableModel df_2 = (DefaultTableModel) tbl_past_payment.getModel();
            df_2.setRowCount(0);
            lbl_due_amount.setText("0.00");
            lbl_invoice_total.setText("0.00");
            lbl_payed_amount.setText("0.00");
            Vector v1 = new Vector();
            lst_invoice_code.setListData(v1);
            if (cbo_type.getSelectedItem().equals("Invoice")) {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from customer_master");
                Vector v = new Vector();
                v.add("[ Select ]");
                while (rset.next()) {
                    v.add(rset.getString(1));
                }
                cbo_customer_code.setModel(new DefaultComboBoxModel(v));
            } else if (cbo_type.getSelectedItem().equals("Goods Receipt Note")) {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from supplier_master");
                Vector v = new Vector();
                v.add("[ Select ]");
                while (rset.next()) {
                    v.add(rset.getString(1));
                }
                cbo_customer_code.setModel(new DefaultComboBoxModel(v));
            } else {
                Vector v = new Vector();
                v.add("[ Select ]");
                cbo_customer_code.setModel(new DefaultComboBoxModel(v));
            }
        } catch (Exception e) {
            System.out.println("payment sup_cus_load " + e);
        }
    }

    public void cus_sup_select(JLabel lbl_payed_amount, JTable tbl_invoice_details, JTable tbl_past_payment, JLabel lbl_due_amount, JList lst_invoice_code, JLabel lbl_invoice_total, JComboBox cbo_type, JComboBox cbo_customer_code, JLabel lbl_name) {
        try {
            DefaultTableModel df_1 = (DefaultTableModel) tbl_invoice_details.getModel();
            df_1.setRowCount(0);
            DefaultTableModel df_2 = (DefaultTableModel) tbl_past_payment.getModel();
            df_2.setRowCount(0);
            lbl_due_amount.setText("0.00");
            lbl_invoice_total.setText("0.00");
            lbl_payed_amount.setText("0.00");
            if (cbo_type.getSelectedItem().equals("[ Select ]")) {
                Vector v = new Vector();
                lst_invoice_code.setListData(v);
            } else if (cbo_type.getSelectedItem().equals("Goods Receipt Note")) {
                ResultSet rset1 = Model.Object.Jdbc.getdata("select Admin from user_login where UserGroup='" + FrmHome2.group + "'");
                if (rset1.next()) {                    
                    if (rset1.getString(1).equals("Admin") || (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true && Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true)) {
                        ResultSet rset = Model.Object.Jdbc.getdata("select* from grn_balance where supplier_code='" + cbo_customer_code.getSelectedItem() + "' and grn_status='" + "0" + "'");
                        Vector v = new Vector();
                        while (rset.next()) {
                            v.add(rset.getString(3));
                             System.out.println(rset.getString(3));
                        }                       
                        lst_invoice_code.setListData(v);
                        ResultSet rset_cus = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + cbo_customer_code.getSelectedItem() + "'");
                        if (rset_cus.next()) {
                            lbl_name.setText(rset_cus.getString(2));
                        } else {
                            lbl_name.setText("");
                        }
                        //admin
                    } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                        ResultSet rset = Model.Object.Jdbc.getdata("select* from grn_balance where supplier_code='" + cbo_customer_code.getSelectedItem() + "' and grn_status='" + "0" + "' and location='" + "OUTLET" + "'");
                        Vector v = new Vector();
                        while (rset.next()) {
                            v.add(rset.getString(3));
                        }
                        lst_invoice_code.setListData(v);
                        ResultSet rset_cus = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + cbo_customer_code.getSelectedItem() + "'");
                        if (rset_cus.next()) {
                            lbl_name.setText(rset_cus.getString(2));
                        } else {
                            lbl_name.setText("");
                        }
                        //outlet
                    } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                        ResultSet rset = Model.Object.Jdbc.getdata("select* from grn_balance where supplier_code='" + cbo_customer_code.getSelectedItem() + "' and grn_status='" + "0" + "' and location='" + "WAREHOUSE" + "'");
                        Vector v = new Vector();
                        while (rset.next()) {
                            v.add(rset.getString(3));
                        }
                        lst_invoice_code.setListData(v);
                        ResultSet rset_cus = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + cbo_customer_code.getSelectedItem() + "'");
                        if (rset_cus.next()) {
                            lbl_name.setText(rset_cus.getString(2));
                        } else {
                            lbl_name.setText("");
                        }
                        //wherhouse
                    }
                }

            } else {
                ResultSet rset1 = Model.Object.Jdbc.getdata("select Admin from user_login where UserGroup='" + FrmHome2.group + "'");
                if (rset1.next()) {
                    if (rset1.getString(1).equals("Admin") || (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true && Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true)) {
                        ResultSet rset = Model.Object.Jdbc.getdata("select* from invoice_balance where customer_code='" + cbo_customer_code.getSelectedItem() + "' and invoice_status='" + "0" + "'");
                        Vector v = new Vector();
                        while (rset.next()) {
                            ResultSet rset_it = Model.Object.Jdbc.getdata("select* from invoice_item where invoice_code='" + rset.getString(1) + "' ");
                            if (rset_it.next()) {
                                v.add(rset.getString(1));
                            }
                        }
                        lst_invoice_code.setListData(v);
                        ResultSet rset_cus = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + cbo_customer_code.getSelectedItem() + "'");
                        if (rset_cus.next()) {
                            lbl_name.setText(rset_cus.getString(2));
                        } else {
                            lbl_name.setText("");
                        }
                        //admin
                    } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                        ResultSet rset = Model.Object.Jdbc.getdata("select* from invoice_balance where customer_code='" + cbo_customer_code.getSelectedItem() + "' and invoice_status='" + "0" + "'");
                        Vector v = new Vector();
                        while (rset.next()) {
                            ResultSet rset_it = Model.Object.Jdbc.getdata("select* from invoice_item where invoice_code='" + rset.getString(1) + "' and location='" + "OUTLET" + "'");
                            if (rset_it.next()) {
                                v.add(rset.getString(1));
                            }
                        }
                        lst_invoice_code.setListData(v);
                        ResultSet rset_cus = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + cbo_customer_code.getSelectedItem() + "'");
                        if (rset_cus.next()) {
                            lbl_name.setText(rset_cus.getString(2));
                        } else {
                            lbl_name.setText("");
                        }
                        //outlet

                    } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                        ResultSet rset = Model.Object.Jdbc.getdata("select* from invoice_balance where customer_code='" + cbo_customer_code.getSelectedItem() + "' and invoice_status='" + "0" + "'");
                        Vector v = new Vector();
                        while (rset.next()) {
                            ResultSet rset_it = Model.Object.Jdbc.getdata("select* from invoice_item where invoice_code='" + rset.getString(1) + "' and location='" + "WAREHOUSE" + "'");
                            if (rset_it.next()) {
                                v.add(rset.getString(1));
                            }
                        }
                        lst_invoice_code.setListData(v);
                        ResultSet rset_cus = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + cbo_customer_code.getSelectedItem() + "'");
                        if (rset_cus.next()) {
                            lbl_name.setText(rset_cus.getString(2));
                        } else {
                            lbl_name.setText("");
                        }
                        //wherhouse

                    }
                }

            }
        } catch (Exception e) {
            System.out.println("payment  cus_sup_select " + e);
        }
    }

    public void invoice_numner_list_change(JLabel lbl_return_amount, JComboBox cbo_type, JList lst_invoice_code, JTable tbl_invoice_details, JTable tbl_past_payment, JLabel lbl_invoice_total, JLabel lbl_payed_amount, JLabel lbl_due_amount, JTextField txt_paying_amount) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_invoice_details.getModel();
            df.setRowCount(0);
            DefaultTableModel df_1 = (DefaultTableModel) tbl_past_payment.getModel();
            df_1.setRowCount(0);
            if (cbo_type.getSelectedItem().equals("Invoice")) {
//                ResultSet rset_payment = infoims.Object.Jdbc.getdata("select* from payments where invoice_or_grn='" + "Invoice" + "' and invoice_grn_code='" + lst_invoice_code.getSelectedValue() + "' and payment_status='" + "0" + "'");
//                if (rset_payment.next()) {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from invoice_item where invoice_code='" + lst_invoice_code.getSelectedValue() + "'");
                while (rset.next()) {
                    Vector v = new Vector();
                    v.add(rset.getString(2));
                    v.add(rset.getString(5));
                    v.add(rset.getString(7));
                    v.add(rset.getString(10));
                    v.add(rset.getString(11));
                    v.add(rset.getString(12));
                    v.add(rset.getString(13));
                    df.addRow(v);
                }

                ResultSet rset_1 = Model.Object.Jdbc.getdata("select* from payments where invoice_or_grn='" + "invoice" + "' and invoice_grn_code='" + lst_invoice_code.getSelectedValue() + "'");
                double payed = 0.00;
                while (rset_1.next()) {
                    Vector v = new Vector();
                    v.add(rset_1.getString(6));
                    payed = payed + rset_1.getDouble(6);
                    v.add(rset_1.getString(9));
                    v.add(rset_1.getString(8));
                    if (rset_1.getDouble(6) == 0.0) {
                    } else {
                        df_1.addRow(v);
                    }
                }
                ResultSet rset_return = Model.Object.Jdbc.getdata("select* from payments where invoice_or_grn='" + "Invoice Return" + "' and invoice_grn_code='" + lst_invoice_code.getSelectedValue() + "'");
                double ret = 0.00;
                while (rset_return.next()) {
                    Vector v = new Vector();
                    v.add(rset_return.getString(6));
                    ret = ret + rset_return.getDouble(6);
                    v.add(rset_return.getString(9));
                    v.add(rset_return.getString(8));
                    if (rset_return.getDouble(6) == 0.0) {
                    } else {
                        df_1.addRow(v);
                    }
                }
                lbl_return_amount.setText(Model.Object.Formated.getPriceValue(ret));
                lbl_payed_amount.setText(Model.Object.Formated.getPriceValue(payed));
                ResultSet rset_sub = Model.Object.Jdbc.getdata("select* from invoice_balance where invoice_code='" + lst_invoice_code.getSelectedValue() + "'");
                if (rset_sub.next()) {
                    lbl_invoice_total.setText(Model.Object.Formated.getPriceValue(rset_sub.getDouble(9)));
                    lbl_payed_amount.setText(Model.Object.Formated.getPriceValue(payed));
                    lbl_due_amount.setText(Model.Object.Formated.getPriceValue((Double.parseDouble(lbl_invoice_total.getText()) - (Double.parseDouble(lbl_payed_amount.getText()) + Double.parseDouble(lbl_return_amount.getText())))));
                }
//                } else {
//                    infoims.Object.messagePopUps.payments_completed();
//                }
            } else if (cbo_type.getSelectedItem().equals("Goods Receipt Note")) {
//                ResultSet rset_payment = infoims.Object.Jdbc.getdata("select* from payments where invoice_or_grn='" + "Grn" + "' and invoice_grn_code='" + lst_invoice_code.getSelectedValue() + "' and payment_status='" + "0" + "'");
//                if (rset_payment.next()) {
                String code = "";
                ResultSet rset1 = Model.Object.Jdbc.getdata("select* from grn_balance where supplier_invoice_code='" + lst_invoice_code.getSelectedValue() + "'");
                if (rset1.next()) {
                    code = rset1.getString(1);
                }
                ResultSet rset = Model.Object.Jdbc.getdata("select* from grn_item where grn_code='" + code + "'");
                while (rset.next()) {
                    Vector v = new Vector();
                    v.add(rset.getString(2));
                    v.add(rset.getString(5));
                    v.add(rset.getString(6));
                    v.add(rset.getString(9));
                    v.add(rset.getString(10));
                    v.add(rset.getString(11));
                    v.add(rset.getString(12));
                    df.addRow(v);
                }
                ResultSet rset_1 = Model.Object.Jdbc.getdata("select* from payments where invoice_or_grn='" + "Grn" + "' and invoice_grn_code='" + code + "'");
                double payed = 0.00;
                while (rset_1.next()) {
                    Vector v = new Vector();
                    v.add(rset_1.getString(6));
                    payed = payed + rset_1.getDouble(6);
                    v.add(rset_1.getString(9));
                    v.add(rset_1.getString(8));
                    if (rset_1.getDouble(6) == 0.0) {
                    } else {
                        df_1.addRow(v);
                    }
                }
                ResultSet rset_eturn = Model.Object.Jdbc.getdata("select* from payments where invoice_or_grn='" + "Grn Return" + "' and invoice_grn_code='" + code + "'");
                double ret = 0.00;
                while (rset_eturn.next()) {
                    Vector v = new Vector();
                    v.add(rset_eturn.getString(6));
                    ret = ret + rset_eturn.getDouble(6);
                    v.add(rset_eturn.getString(9));
                    v.add(rset_eturn.getString(8));
                    if (rset_eturn.getDouble(6) == 0.0) {
                    } else {
                        df_1.addRow(v);
                    }
                }
                lbl_return_amount.setText(Model.Object.Formated.getPriceValue(ret));
                lbl_payed_amount.setText(Model.Object.Formated.getPriceValue(payed));
                ResultSet rset_sub = Model.Object.Jdbc.getdata("select* from grn_balance where grn_code='" + code + "'");
                if (rset_sub.next()) {
                    lbl_invoice_total.setText(Model.Object.Formated.getPriceValue(rset_sub.getDouble(12)));
                    lbl_payed_amount.setText(Model.Object.Formated.getPriceValue(payed));
                    lbl_due_amount.setText(Model.Object.Formated.getPriceValue((Double.parseDouble(lbl_invoice_total.getText()) - (Double.parseDouble(lbl_payed_amount.getText()) + Double.parseDouble(lbl_return_amount.getText())))));
                }
//                } else {
//                    infoims.Object.messagePopUps.payments_completed();
//                }
            } else {
                Model.Object.messagePopUps.payments_details_not_found();
            }
        } catch (Exception e) {
            System.out.println("payment  invoice_numner_list_change( " + e);
        }
    }

    public static void save_payment(JLabel lbl_name, JTable tbl_past_payment, JList lst_invoice_code, JTable tbl_invoice_details, JComboBox cbo_type, JComboBox cbo_customer_code, JLabel lbl_invoice_total, JLabel lbl_payed_amountJLabel, JLabel lbl_due_amount, JTextField txt_paying_amount, JLabel lbl_balance, JComboBox cbo_pay_type) {
        try {
            if (cbo_type.getSelectedItem().equals("[ Select ]")) {
                Model.Object.messagePopUps.select_type();
                cbo_type.grabFocus();
            } else if (cbo_customer_code.getSelectedItem().equals("[ Select ]")) {
                Model.Object.messagePopUps.select_cs();
                cbo_customer_code.grabFocus();
            } else if (tbl_invoice_details.getRowCount() == 0) {
                Model.Object.messagePopUps.select_invoice_code();
                lst_invoice_code.grabFocus();
            } else if (txt_paying_amount.getText() == null || txt_paying_amount.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_payment();
                txt_paying_amount.grabFocus();
            } else if (lbl_balance.getText() == null || lbl_balance.getText().isEmpty()) {
                Model.Object.messagePopUps.payment_balance_empty();
                txt_paying_amount.grabFocus();
            } else {
                int list_index = lst_invoice_code.getSelectedIndex();
                String grn_invoice = "";
                int status = 0;
                Double payment = 0.00;
                Double balance = 0.00;
                if (Double.parseDouble(lbl_due_amount.getText()) <= Double.parseDouble(txt_paying_amount.getText())) {
                    status = 1;
                    payment = Double.parseDouble(lbl_due_amount.getText());
                    balance = 0.00;
                } else {
                    status = 0;
                    payment = Double.parseDouble(txt_paying_amount.getText());
                    balance = Double.parseDouble(txt_paying_amount.getText()) - Double.parseDouble(lbl_due_amount.getText());
                }
                if (cbo_type.getSelectedItem().toString().equals("[ Select]")) {

                } else if (cbo_type.getSelectedItem().toString().equals("Invoice")) {
                    grn_invoice = "invoice";
                    if (cbo_pay_type.getSelectedItem().equals("Cheque")) {
                    } else {
                        //invoice
                        Model.Object.paymentVeryfication.save_new(cbo_customer_code.getSelectedItem().toString(), lst_invoice_code.getSelectedValue().toString(), lbl_name.getText(), "From a " + lbl_name.getText() + " Payment of Rs." + txt_paying_amount.getText() + " by Cash", "Invoice");
                        if (Double.parseDouble(lbl_due_amount.getText()) <= Double.parseDouble(txt_paying_amount.getText())) {
                            ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where invoiceno='" + lst_invoice_code.getSelectedValue() + "' and grn_or_invoice='" + "Invoice" + "'");
                            if (rset.next()) {
                                status = 0;
                            } else {
                                status = 1;
                                Model.Object.Jdbc.putdata("update invoice_balance set invoice_status='" + "1" + "' where invoice_code='" + lst_invoice_code.getSelectedValue() + "'");
                            }
                        }
                    }
                } else {
                    grn_invoice = "grn";
                    String grn_code = "";
                    ResultSet rset1 = Model.Object.Jdbc.getdata("select* from grn_balance where supplier_invoice_code='" + lst_invoice_code.getSelectedValue() + "'");
                    if (rset1.next()) {
                        grn_code = rset1.getString(1);
                    }
                    if (cbo_pay_type.getSelectedItem().equals("Cheque")) {
                    } else {
                        //grn
                        Model.Object.paymentVeryfication.save_new(cbo_customer_code.getSelectedItem().toString(), lst_invoice_code.getSelectedValue().toString(), lbl_name.getText(), "From a " + lbl_name.getText() + " Payment of Rs." + txt_paying_amount.getText() + " by Cash", "Good Received");
                        if (Double.parseDouble(lbl_due_amount.getText()) <= Double.parseDouble(txt_paying_amount.getText())) {
                            ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where invoiceno='" + grn_code + "' and grn_or_invoice='" + "Grn" + "'");
                            if (rset.next()) {
                                status = 0;
                            } else {
                                status = 1;
                                Model.Object.Jdbc.putdata("update grn_balance set grn_status='" + "1" + "' where grn_code='" + grn_code + "'");
                            }
                        }
                    }
                }
                String grn_code = "";
                ResultSet rset1 = Model.Object.Jdbc.getdata("select* from grn_balance where supplier_invoice_code='" + lst_invoice_code.getSelectedValue() + "'");
                if (rset1.next()) {
                    grn_code = rset1.getString(1);
                }
                String payment_invoice_no = "";
                if (cbo_type.getSelectedItem().toString().equals("Invoice")) {
                    payment_invoice_no = lst_invoice_code.getSelectedValue().toString();
                } else {
                    payment_invoice_no = grn_code;
                }
                Model.Object.Jdbc.putdata("insert into payments value('" + "0" + "','" + grn_invoice + "','" + payment_invoice_no + "','" + cbo_customer_code.getSelectedItem() + "','" + lbl_due_amount.getText() + "','" + payment + "','" + Math.abs(balance) + "',NOW(),'" + cbo_pay_type.getSelectedItem() + "','" + String.valueOf(status) + "','" + "" + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                if (cbo_type.getSelectedItem().equals("[ Select ]")) {
                } else if (cbo_type.getSelectedItem().equals("Invoice")) {
                    if (status == 1) {
                        ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where invoiceno='" + lst_invoice_code.getSelectedValue() + "' and grn_or_invoice='" + "Invoice" + "'");
                        if (rset.next()) {
                        } else {
                            Model.Object.Jdbc.putdata("update payments set payment_status='" + "1" + "' where invoice_or_grn='" + "invoice" + "' and invoice_grn_code='" + lst_invoice_code.getSelectedValue() + "'");
                        }
                    }
                } else {
                    String grn_code2 = "";
                    ResultSet rset2 = Model.Object.Jdbc.getdata("select* from grn_balance where supplier_invoice_code='" + lst_invoice_code.getSelectedValue() + "'");
                    if (rset2.next()) {
                        grn_code2 = rset2.getString(1);
                    }
                    if (status == 1) {
                        ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where invoiceno='" + grn_code2 + "' and grn_or_invoice='" + "Grn" + "'");
                        if (rset.next()) {
                        } else {
                            Model.Object.Jdbc.putdata("update payments set payment_status='" + "1" + "' where invoice_or_grn='" + "grn" + "' and invoice_grn_code='" + grn_code2 + "'");
                        }
                    }
                }
                Model.Object.messagePopUps.saveMessage();
                DefaultTableModel df1 = (DefaultTableModel) tbl_invoice_details.getModel();
                df1.setRowCount(0);
                DefaultTableModel df2 = (DefaultTableModel) tbl_past_payment.getModel();
                df2.setRowCount(0);
                if (list_index == 0) {
                    Vector v = new Vector();
                    v.add(lst_invoice_code.getSelectedValue());
                    lst_invoice_code.setListData(v);
                }
                // cbo_customer_code.setSelectedItem("[ Select ]");
                cbo_pay_type.setSelectedItem("Cash");
                // cbo_type.setSelectedItem("[ Select ]");
                //lbl_name.setText(null);                
                lbl_due_amount.setText(null);
                lbl_invoice_total.setText(null);
                lbl_payed_amountJLabel.setText(null);
                txt_paying_amount.setText(null);
                lbl_balance.setText(null);
                lst_invoice_code.setSelectedIndex(list_index - 1);
                lst_invoice_code.setSelectedIndex(list_index);
                txt_paying_amount.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("payment  save_payment " + e);
        }
    }
    public static boolean bool = true;

    public void payment_cheque_save(String lbl_cs_name, JLabel lbl_invoice_grn_code, JTextField txt_cheque_number, JLabel lbl_Customer, JComboBox cbo_bank, JTextField txt_date, JLabel lbl_amount, JLabel lbl_type, JLabel lbl_cheque_status) {
        try {
            if (lbl_invoice_grn_code.getText() == null || lbl_invoice_grn_code.getText().isEmpty()) {
                Model.Object.messagePopUps.invoice_grn_code_empty();
            } else if (txt_cheque_number.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_cheque_number();
                txt_cheque_number.grabFocus();
            } else if (cbo_bank.getSelectedItem().toString().isEmpty()) {
                Model.Object.messagePopUps.enter_bank();
                cbo_bank.grabFocus();
            } else if (txt_date.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_cheque_date();
                txt_date.grabFocus();
            } else if (lbl_amount.getText() == null || lbl_amount.getText().isEmpty()) {
                Model.Object.messagePopUps.Amount_Empty();
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where cheque_number='" + txt_cheque_number.getText() + "'");
                if (rset.next()) {
                    Model.Object.messagePopUps.duplicateEntryMessage();
                    txt_cheque_number.grabFocus();
                    txt_cheque_number.selectAll();
                    bool = true;
                } else {
                    Model.Object.Jdbc.putdata("insert into cheque values('" + lbl_invoice_grn_code.getText() + "','" + txt_cheque_number.getText() + "','" + lbl_Customer.getText() + "','" + cbo_bank.getSelectedItem() + "','" + txt_date.getText() + "','" + Double.parseDouble(lbl_amount.getText()) + "','" + lbl_cheque_status.getText() + "','" + "" + "','" + lbl_type.getText() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                    if (lbl_type.getText().equals("Invoice")) {
                        Model.Object.paymentVeryfication.save_new(lbl_Customer.getText(), lbl_invoice_grn_code.getText(), lbl_cs_name, "From a " + lbl_cs_name + " Payment of Rs." + lbl_amount.getText() + " by Cheque", "Invoice");
                    } else {
                        Model.Object.paymentVeryfication.save_new(lbl_Customer.getText(), lbl_invoice_grn_code.getText(), lbl_cs_name, "From a " + lbl_cs_name + " Payment of Rs." + lbl_amount.getText() + " by Cheque", "Good Received");
                    }
                    Model.Object.payment.save_payment(FrmPayment.lbl_name, tbl_past_payment, lst_invoice_code, tbl_invoice_details, cbo_type, cbo_customer_code, lbl_invoice_total, lbl_payed_amount, lbl_due_amount, txt_paying_amount, lbl_balance, cbo_pay_type);
                    bool = false;
                }
            }
        } catch (Exception e) {
            System.out.println("payment_cheque_save " + e);
        }

    }
}
