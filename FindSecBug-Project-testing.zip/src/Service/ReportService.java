/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import View.FrmReportViewer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.print.PrinterJob;
import java.io.InputStream;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.MediaSize;
import javax.print.attribute.standard.MediaSizeName;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperPrintManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRTableModelDataSource;
import net.sf.jasperreports.engine.export.JRPrintServiceExporter;
import net.sf.jasperreports.engine.export.JRPrintServiceExporterParameter;
import net.sf.jasperreports.view.JRViewer;
import net.sf.jasperreports.view.JasperViewer;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

/**
 *
 * @author user
 */
public class ReportService {

    public void date_wise_grn_report(JScrollPane jScrollPane1) {
        try {
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                String company = null;
                String address = null;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset.next()) {
                    company = rset.getString(1);
                    address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
                }
                jScrollPane1.removeAll();
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptDateWiseGrn.jrxml");
                params.put("start_date", start_date);
                params.put("end_date", end_date);

                params.put("company", company);
                params.put("address", address);

                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
                JasperViewer.setDefaultLookAndFeelDecorated(true);
                //JasperViewer.viewReport(jasperPrint,false);

                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
            }

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void empty_poss() {
        try {

            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/Rptemptyposs.jrxml");

            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
            JasperPrintManager.printReport(jasperPrint, false);

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void poss_invoice(JLabel lbl_invoice_number) {
        try {

            Map<String, Object> params = new HashMap<String, Object>();
            params.put("INV_CODE", lbl_invoice_number.getText());
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptInvoicePoss.jrxml");
            JasperReport jasperReport = JasperCompileManager.compileReport(stream);

            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
            PrinterJob job = PrinterJob.getPrinterJob();
            PrintService[] service = PrintServiceLookup.lookupPrintServices(null, null);
            int selectedService = 2;
            job.setPrintService(service[selectedService]);
            System.out.println(service[selectedService]);
            PrintRequestAttributeSet printRequestAttributeSet = new HashPrintRequestAttributeSet();
            MediaSizeName mediaSizeName = MediaSize.findMedia(80, 3276, MediaSize.MM);
            printRequestAttributeSet.add(mediaSizeName);
            printRequestAttributeSet.add(new Copies(1));
            JRExporter exporter = new JRPrintServiceExporter();
            exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
            exporter.setParameter(JRPrintServiceExporterParameter.PRINT_SERVICE_ATTRIBUTE_SET, service[selectedService].getAttributes());
            exporter.setParameter(JRPrintServiceExporterParameter.DISPLAY_PAGE_DIALOG, Boolean.FALSE);
            exporter.setParameter(JRPrintServiceExporterParameter.DISPLAY_PRINT_DIALOG, Boolean.FALSE);
            exporter.exportReport();

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void invoice(JScrollPane jScrollPane1) {
        try {
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                jScrollPane1.removeAll();
                String company = null;
                String address = null;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset.next()) {
                    company = rset.getString(1);
                    address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
                }
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/DateWiseInvoice.jrxml");
                // F:\\UDARA\\Project\\Current project\\IMS_For_Ambalantota\\InfoIMS_Ambalantota\\src\\Report\\DateWiseInvoice.jrxml

                params.put("start_date", start_date);
                params.put("end_date", end_date);
                params.put("company", company);
                params.put("address", address);
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
        }
    }

    public void date_wise_expence(JScrollPane jScrollPane1) {
        try {
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                jScrollPane1.removeAll();
                String company = null;
                String address = null;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset.next()) {
                    company = rset.getString(1);
                    address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
                }
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptDatewiseExpenses.jrxml");
                params.put("start_date", start_date);
                params.put("end_date", end_date);
                params.put("company", company);
                params.put("address", address);
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
        }
    }

    public void date_wise_sale(JScrollPane jScrollPane1) {
        try {
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                jScrollPane1.removeAll();
                String company = null;
                String address = null;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset.next()) {
                    company = rset.getString(1);
                    address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
                }
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptDateWiseSale.jrxml");
                params.put("start_date", start_date);
                params.put("end_date", end_date);
                params.put("company", company);
                params.put("address", address);
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
        }
    }

    public void date_wise_payment(JScrollPane jScrollPane1) {
        try {
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                start_date = start_date + " 00:00:00";
                end_date = end_date + " 23:59:59";
                jScrollPane1.removeAll();
                JTable jt = new JTable(0, 7);
                DefaultTableModel df = (DefaultTableModel) jt.getModel();
                df.setRowCount(0);
                int i = 0;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from payments where  (paymentType='" + "Cash" + "' or paymentType='" + "Cheque" + "') and date_added between '" + start_date + "' and '" + end_date + "'  order by invoice_or_grn DESC");
                while (rset.next()) {
                    Vector v = new Vector();
                    v.add(rset.getString(1));
                    if (rset.getString(2).equals("invoice") || rset.getString(2).equals("Invoice Return")) {
                        v.add("Customer Invoice");
                    } else {
                        v.add("Good Received Note");
                    }

                    v.add(rset.getString(3));
                    if (rset.getString(2).equals("invoice") || rset.getString(2).equals("Invoice Return")) {
                        ResultSet rset_c = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset.getString(4) + "'");
                        if (rset_c.next()) {
                            v.add(rset_c.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                    } else {
                        ResultSet rset_c = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset.getString(4) + "'");
                        if (rset_c.next()) {
                            v.add(rset_c.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                    }
                    v.add(rset.getDouble(6));
                    v.add(rset.getString(8));
                    v.add(rset.getString(9));
                    df.addRow(v);

                    System.out.println(df.getValueAt(i, 0));
                    i++;
                }
                String company = null;
                String address = null;
                ResultSet rset1 = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset1.next()) {
                    company = rset1.getString(1);
                    address = rset1.getString(2) + " " + rset1.getString(3) + " " + rset1.getString(4);
                }
                JRTableModelDataSource data = new JRTableModelDataSource(df);
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("start_date", start_date);
                params.put("end_date", end_date);
                params.put("company", company);
                params.put("address", address);
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/newRptPaymentHistory.jrxml");
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, data);
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void date_wise_customer_allcheque(JScrollPane jScrollPane1) {
        try {
            String grn_or_invoice = "";
            Vector v1 = new Vector();
            v1.add("Customer");
            v1.add("Supplier");
            JComboBox jc = new JComboBox(v1);
            jc.setSize(200, 23);
            jc.setSelectedItem("Customer");
            final JComponent[] inputs = new JComponent[]{
                new JLabel("Select Customer or Supplier"),
                jc
            };
            JOptionPane.showMessageDialog(null, inputs, "Select", JOptionPane.QUESTION_MESSAGE);

            if (jc.getSelectedItem().toString().equals("Customer")) {
                grn_or_invoice = "Invoice";
            } else {
                grn_or_invoice = "Grn";
            }

            System.out.print(jc.getSelectedItem());
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                String start_date1 = start_date + " 00:00:00";
                String end_date1 = end_date + " 23:59:59";
                jScrollPane1.removeAll();
                JTable jt = new JTable(0, 8);
                DefaultTableModel df = (DefaultTableModel) jt.getModel();
                df.setRowCount(0);
                int i = 0;
                String cs = null;
                Double pending_amount = 0.00;
                Double realised_amount = 0.00;
                Double unrealised_amount = 0.00;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where grn_or_invoice='" + grn_or_invoice + "' and date_time between'" + start_date1 + "' and '" + end_date1 + "'");
                while (rset.next()) {
                    Vector v = new Vector();
                    v.add(rset.getString(1));
                    v.add(rset.getString(2));
                    if (grn_or_invoice.equals("Invoice")) {
                        ResultSet rset_c = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset.getString(3) + "'");
                        if (rset_c.next()) {
                            v.add(rset_c.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                        cs = "Customer";
                    } else {
                        ResultSet rset_c = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset.getString(3) + "'");
                        if (rset_c.next()) {
                            v.add(rset_c.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                        cs = "supplier";
                    }
                    v.add(rset.getString(4));
                    v.add(rset.getString(5));
                    v.add(rset.getString(6));
                    v.add(rset.getString(7));
                    v.add(rset.getString(8));
                    df.addRow(v);
                    if (rset.getString(7).equals("Realised")) {
                        realised_amount = realised_amount + rset.getDouble(6);
                    } else if (rset.getString(7).equals("Unrealised")) {
                        unrealised_amount = unrealised_amount + rset.getDouble(6);
                    } else if (rset.getString(7).equals("Pending")) {
                        pending_amount = pending_amount + rset.getDouble(6);
                    }

                    System.out.println(df.getValueAt(i, 0));
                    i++;
                }
                ResultSet rset_unr = Model.Object.Jdbc.getdata("select* from cheque_unrealised where grn_or_invoice='" + grn_or_invoice + "' and date_time between'" + start_date1 + "' and '" + end_date1 + "'");
                while (rset_unr.next()) {
                    Vector v = new Vector();
                    v.add(rset_unr.getString(1));
                    v.add(rset_unr.getString(2));
                    if (grn_or_invoice.equals("Invoice")) {
                        ResultSet rset_c = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset_unr.getString(3) + "'");
                        if (rset_c.next()) {
                            v.add(rset_c.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                        cs = "Customer";
                    } else {
                        ResultSet rset_c = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset_unr.getString(3) + "'");
                        if (rset_c.next()) {
                            v.add(rset_c.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                        cs = "supplier";
                    }
                    v.add(rset_unr.getString(4));
                    v.add(rset_unr.getString(5));
                    v.add(rset_unr.getString(6));
                    v.add(rset_unr.getString(7));
                    v.add(rset_unr.getString(8));
                    df.addRow(v);
                    if (rset_unr.getString(7).equals("Unrealised")) {
                        unrealised_amount = unrealised_amount + rset_unr.getDouble(6);
                    }
                }
                String company = null;
                String address = null;
                ResultSet rset1 = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset1.next()) {
                    company = rset1.getString(1);
                    address = rset1.getString(2) + " " + rset1.getString(3) + " " + rset1.getString(4);
                }
                JRTableModelDataSource data = new JRTableModelDataSource(df);
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("start_date", start_date);
                params.put("end_date", end_date);
                params.put("cus_or_sup", cs);
                params.put("pending", String.valueOf(Model.Object.Formated.getPriceValue(pending_amount)));
                params.put("realised", String.valueOf(Model.Object.Formated.getPriceValue(realised_amount)));
                params.put("unrelised", String.valueOf(Model.Object.Formated.getPriceValue(unrealised_amount)));
                params.put("company", company);
                params.put("address", address);
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptDateWiseAllCheque.jrxml");
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, data);
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void item_wise_day_today_sale(JScrollPane jScrollPane1) {
        try {
            String serch_type = "";
            Vector v1 = new Vector();
            // v1.add("All Item");
            ResultSet rset_item = Model.Object.Jdbc.getdata("select* from item_master");
            while (rset_item.next()) {
                v1.add(rset_item.getString(2));
            }
            final JComboBox jc1 = new JComboBox(v1);
            jc1.setSize(200, 23);
            jc1.setEditable(true);

//////////////
            AutoCompleteDecorator.decorate(jc1);

//////////            
            final JComponent[] inputs = new JComponent[]{
                new JLabel("Select Item"),
                jc1,};

            String jc = "";
            JOptionPane.showMessageDialog(null, inputs, "Select", JOptionPane.QUESTION_MESSAGE);

            ResultSet rset_item1 = Model.Object.Jdbc.getdata("select* from item_master where item_description='" + jc1.getSelectedItem() + "'");
            if (rset_item1.next()) {
                jc = rset_item1.getString(1);
            } else {
                jc = "All";
            }
            if (jc.equals("All")) {
                serch_type = "All";
            } else {
                serch_type = "item_by";
            }
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                String start_date1 = start_date + " 00:00:00";
                String end_date1 = end_date + " 23:59:59";
                jScrollPane1.removeAll();

                JTable jt = new JTable(0, 9);
                DefaultTableModel df = (DefaultTableModel) jt.getModel();
                df.setRowCount(0);

                if (serch_type.equals("All")) {
                    ResultSet rset_master = Model.Object.Jdbc.getdata("select* from item_master");
                    while (rset_master.next()) {
                        ResultSet rset = Model.Object.Jdbc.getdata("select* from invoice_item where item_code='" + rset_master.getString(1) + "' and date_time between '" + start_date1 + "' and '" + end_date1 + "' group by item_code");
                        while (rset.next()) {
                            ResultSet rset_1 = Model.Object.Jdbc.getdata("select sum(quantity) from invoice_item where item_code='" + rset.getString(1) + "' and date_time between'" + start_date1 + "' and '" + end_date1 + "'");
                            if (rset_1.next()) {
                                Vector v = new Vector();
                                v.add(rset.getString(2));
                                v.add(rset.getString(3));
                                v.add(rset.getString(1));
                                v.add(rset.getString(5));
                                v.add(rset.getDouble(7));
                                v.add(rset.getString(10));
                                v.add(rset.getString(12));
                                v.add(rset.getDouble(13));
                                v.add(rset.getDouble(14));
                                df.addRow(v);
                            }
                        }
                    }

                } else {
                    ResultSet rset = Model.Object.Jdbc.getdata("select* from invoice_item where item_code='" + jc + "' and date_time between'" + start_date1 + "' and '" + end_date1 + "'");
                    while (rset.next()) {
                        ResultSet rset_1 = Model.Object.Jdbc.getdata("select sum(quantity) from invoice_item where item_code='" + rset.getString(2) + "' and date_time between'" + start_date1 + "' and '" + end_date1 + "'");
                        if (rset_1.next()) {
                            Vector v = new Vector();
                            v.add(rset.getString(2));
                            v.add(rset.getString(3));
                            v.add(rset.getString(1));
                            v.add(rset.getString(5));
                            v.add(rset.getDouble(7));
                            v.add(rset.getString(10));
                            v.add(rset.getString(12));
                            v.add(rset.getDouble(13));
                            v.add(rset.getDouble(14));
                            df.addRow(v);
                        }
                    }
                }

                String company = null;
                String address = null;
                ResultSet rset1 = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset1.next()) {
                    company = rset1.getString(1);
                    address = rset1.getString(2) + " " + rset1.getString(3) + " " + rset1.getString(4);
                }
                JRTableModelDataSource data = new JRTableModelDataSource(df);
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("start_date", start_date);
                params.put("end_date", end_date);
                params.put("type", jc1.getSelectedItem());
                params.put("company", company);
                params.put("address", address);
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptItemWiseDaytodaySale.jrxml");
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, data);
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void log_history(JScrollPane jScrollPane1) {
        try {
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                jScrollPane1.removeAll();
                String start_date1 = start_date + " 00:00:00";
                String end_date1 = end_date + " 23:59:59";
                String company = null;
                String address = null;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset.next()) {
                    company = rset.getString(1);
                    address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
                }
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptUserLogHistory.jrxml");
                // F:\\UDARA\\Project\\Current project\\IMS_For_Ambalantota\\InfoIMS_Ambalantota\\src\\Report\\DateWiseInvoice.jrxml

                params.put("start_date", start_date1);
                params.put("end_date", end_date1);
                params.put("company", company);
                params.put("address", address);
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
        }
    }

    public void profit_loss_detail(JScrollPane jScrollPane1) {
        try {
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                jScrollPane1.removeAll();
                String start_date1 = start_date + " 00:00:00";
                String end_date1 = end_date + " 23:59:59";
                String company = null;
                String address = null;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset.next()) {
                    company = rset.getString(1);
                    address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
                }
                JTable tbl = new JTable(0, 7);
                DefaultTableModel df = (DefaultTableModel) tbl.getModel();
                Double total_Profit = 0.00;
                Double total_loss = 0.00;
                Double balance = 0.00;
                ResultSet rset_invoice = Model.Object.Jdbc.getdata("select* from invoice_balance where date_time between '" + start_date1 + "' and '" + end_date1 + "'");
                while (rset_invoice.next()) {
                    Vector v = new Vector();
                    v.add("Invoice");
                    v.add("Customer Name");
                    v.add("Profit");
                    v.add(rset_invoice.getString(3));
                    v.add(rset_invoice.getString(1));
                    ResultSet rset_c = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset_invoice.getString(2) + "'");
                    if (rset_c.next()) {
                        v.add(rset_c.getString(2));
                    } else {
                        v.add("Unknown");
                    }
                    v.add(rset_invoice.getDouble("profit"));
                    total_Profit = total_Profit + rset_invoice.getDouble("profit");
                    df.addRow(v);
                }
                ResultSet rset_other_income = Model.Object.Jdbc.getdata("select* from expenses_income where type='" + "Income" + "'");
                while (rset_other_income.next()) {
                    Vector v = new Vector();
                    v.add("Other Income");
                    v.add("Description");
                    v.add("Value");
                    v.add(rset_other_income.getString(4));
                    v.add(rset_other_income.getString(3));
                    v.add(rset_other_income.getString(7));
                    v.add(rset_other_income.getDouble(6));
                    total_Profit = total_Profit + rset_other_income.getDouble(6);
                    df.addRow(v);
                }
                ResultSet rset_invoice_return = Model.Object.Jdbc.getdata("select* from invoice_return_balance where date_time between '" + start_date1 + "' and '" + end_date1 + "'");
                while (rset_invoice_return.next()) {
                    Vector v = new Vector();
                    v.add("Invoice Return");
                    v.add("Customer Name");
                    v.add("Loss");
                    v.add(rset_invoice_return.getString(10));
                    v.add(rset_invoice_return.getString(1));
                    ResultSet rset_c = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset_invoice_return.getString(3) + "'");
                    if (rset_c.next()) {
                        v.add(rset_c.getString(2));
                    } else {
                        v.add("Unknown");
                    }
                    v.add(rset_invoice_return.getDouble(7));
                    total_loss = total_loss + rset_invoice_return.getDouble(7);
                    df.addRow(v);
                }
                ResultSet rset_expencess = Model.Object.Jdbc.getdata("select* from expenses_income where type='" + "Expenses" + "'");
                while (rset_expencess.next()) {
                    Vector v = new Vector();
                    v.add("Expencess");
                    v.add("Description");
                    v.add("Value");
                    v.add(rset_expencess.getString(4));
                    v.add(rset_expencess.getString(3));
                    v.add(rset_expencess.getString(7));
                    v.add(rset_expencess.getDouble(6));
                    total_loss = total_loss + rset_expencess.getDouble(6);
                    df.addRow(v);
                }
                balance = total_Profit - total_loss;
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptrofitLossDetail.jrxml");

                params.put("start_date", start_date1);
                params.put("end_date", end_date1);
                params.put("company", company);
                params.put("address", address);

                params.put("total_Profit", total_Profit);
                params.put("total_loss", total_loss);
                params.put("balance", balance);
                JRTableModelDataSource datasourse = new JRTableModelDataSource(df);
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasourse);
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
        }
    }

    public void profit_loss_chart(JScrollPane jScrollPane1) {
        try {
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                jScrollPane1.removeAll();
                String start_date1 = start_date + " 00:00:00";
                String end_date1 = end_date + " 23:59:59";
                String company = null;
                String address = null;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset.next()) {
                    company = rset.getString(1);
                    address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
                }
                JTable tbl = new JTable(0, 7);
                DefaultTableModel df = (DefaultTableModel) tbl.getModel();
                Double total_Profit = 0.00;
                Double total_loss = 0.00;
                Double balance = 0.00;
                Double income = 0.00;
                ResultSet rset_invoice = Model.Object.Jdbc.getdata("select* from invoice_balance where date_time between '" + start_date1 + "' and '" + end_date1 + "'");
                while (rset_invoice.next()) {
                    Vector v = new Vector();
                    v.add("Invoice");
                    v.add("Customer Name");
                    v.add("Profit");
                    v.add(rset_invoice.getString(3));
                    v.add(rset_invoice.getString(1));
                    ResultSet rset_c = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset_invoice.getString(2) + "'");
                    if (rset_c.next()) {
                        v.add(rset_c.getString(2));
                    } else {
                        v.add("Unknown");
                    }
                    v.add(rset_invoice.getDouble("profit"));
                    income = income + rset_invoice.getDouble("sub_total");
                    total_Profit = total_Profit + rset_invoice.getDouble("profit");
                    df.addRow(v);
                }
                ResultSet rset_other_income = Model.Object.Jdbc.getdata("select* from expenses_income where type='" + "Income" + "' and date_time between '" + start_date1 + "' and '" + end_date1 + "'");
                while (rset_other_income.next()) {
                    Vector v = new Vector();
                    v.add("Other Income");
                    v.add("Description");
                    v.add("Value");
                    v.add(rset_other_income.getString(4));
                    v.add(rset_other_income.getString(3));
                    v.add(rset_other_income.getString(7));
                    v.add(rset_other_income.getDouble(6));
                    total_Profit = total_Profit + rset_other_income.getDouble(6);
                    df.addRow(v);
                }
                ResultSet rset_invoice_return = Model.Object.Jdbc.getdata("select* from invoice_return_balance where date_time between '" + start_date1 + "' and '" + end_date1 + "'");
                while (rset_invoice_return.next()) {
                    Vector v = new Vector();
                    v.add("Invoice Return");
                    v.add("Customer Name");
                    v.add("Loss");
                    v.add(rset_invoice_return.getString(10));
                    v.add(rset_invoice_return.getString(1));
                    ResultSet rset_c = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset_invoice_return.getString(3) + "'");
                    if (rset_c.next()) {
                        v.add(rset_c.getString(2));
                    } else {
                        v.add("Unknown");
                    }
                    v.add(rset_invoice_return.getDouble(7));
                    total_loss = total_loss + rset_invoice_return.getDouble(7);
                    df.addRow(v);
                }
                ResultSet rset_expencess = Model.Object.Jdbc.getdata("select* from expenses_income where type='" + "Expenses" + "' and date_time between '" + start_date1 + "' and '" + end_date1 + "'");
                while (rset_expencess.next()) {
                    Vector v = new Vector();
                    v.add("Expencess");
                    v.add("Description");
                    v.add("Value");
                    v.add(rset_expencess.getString(4));
                    v.add(rset_expencess.getString(3));
                    v.add(rset_expencess.getString(7));
                    v.add(rset_expencess.getDouble(6));
                    total_loss = total_loss + rset_expencess.getDouble(6);
                    df.addRow(v);
                }
                balance = total_Profit - total_loss;

                DefaultPieDataset pieDataset = new DefaultPieDataset();
                pieDataset.setValue("Total Income : " + Model.Object.Formated.getPriceValue(income), Double.parseDouble(Model.Object.Formated.getPriceValue(income)));
                pieDataset.setValue("Total Expense & loss : " + Model.Object.Formated.getPriceValue(total_loss), Double.parseDouble(Model.Object.Formated.getPriceValue(total_loss)));
                pieDataset.setValue("Total Profit & Other income: " + Model.Object.Formated.getPriceValue(total_Profit), Double.parseDouble(Model.Object.Formated.getPriceValue(total_Profit)));
                pieDataset.setValue("Balamce of Profit: " + Model.Object.Formated.getPriceValue(balance), Double.parseDouble(Model.Object.Formated.getPriceValue(balance)));

                JFreeChart jFreeChart = ChartFactory.createPieChart("Profit & Loss", pieDataset, true, true, Locale.ENGLISH);
                JPanel jPanel1 = new JPanel();
                JLabel label = new JLabel("From " + start_date + " To " + end_date);
                label.setOpaque(false);
                label.setForeground(Color.WHITE);
                label.setSize(200, 20);
                jPanel1.add(label);
                label.setLocation(8, 27);

                jPanel1.setLayout(new java.awt.BorderLayout());
                ChartPanel CP = new ChartPanel(jFreeChart);
                jPanel1.add(CP, BorderLayout.CENTER);
                jPanel1.setSize(700, 700);
                jPanel1.validate();
                JPanel jp2 = new JPanel();
                jp2.add(jPanel1, BorderLayout.CENTER);
                jp2.setSize(700, 700);
//                jScrollPane1.add(jp2);
//                jScrollPane1.updateUI();

                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(jp2);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void All_customer_item_sale(JScrollPane jScrollPane1) {
        try {
            String customer = "";
            String serch_type = "";
            Vector v1 = new Vector();
            v1.add("All Customer");
            ResultSet rset_item = Model.Object.Jdbc.getdata("select* from customer_master");
            while (rset_item.next()) {
                v1.add(rset_item.getString(2));
            }
            JComboBox jc1 = new JComboBox(v1);
            jc1.setSize(200, 23);
            jc1.setSelectedItem("All Customer");
            final JComponent[] inputs = new JComponent[]{
                new JLabel("Select Customer"),
                jc1
            };
            JOptionPane.showMessageDialog(null, inputs, "Select", JOptionPane.QUESTION_MESSAGE);
            String jc = "";
            customer = jc1.getSelectedItem().toString();
            ResultSet rset_c = Model.Object.Jdbc.getdata("select* from customer_master where name='" + jc1.getSelectedItem() + "'");
            if (rset_c.next()) {
                jc = rset_c.getString(1);
            }
            if (jc1.getSelectedItem().toString().equals("All Customer")) {
                serch_type = "All Customer";
            } else {
                serch_type = "item_by";
            }
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();

            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                String start_date1 = start_date + " 00:00:00";
                String end_date1 = end_date + " 23:59:59";
                String company = null;
                String address = null;
                ResultSet rset11 = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset11.next()) {
                    company = rset11.getString(1);
                    address = rset11.getString(2) + " " + rset11.getString(3) + " " + rset11.getString(4);
                }
                JTable jt = new JTable(0, 4);
                DefaultTableModel df = (DefaultTableModel) jt.getModel();
                df.setRowCount(0);
                ResultSet rset = null;
                if (serch_type.equals("All Customer")) {
                    rset = Model.Object.Jdbc.getdata("select* from invoice_item where date_time between '" + start_date1 + "' and '" + end_date1 + "'");
                } else {
                    rset = Model.Object.Jdbc.getdata("select* from invoice_item where customer_code='" + jc + "'and date_time between '" + start_date1 + "' and '" + end_date1 + "'");
                }
                while (rset.next()) {
                    boolean bool = false;
                    for (int i = 0; i < df.getRowCount(); i++) {
                        if (df.getValueAt(i, 0).equals(rset.getString(2))) {
                            bool = true;
                            break;
                        }
                    }
                    if (bool == false) {
                        if (serch_type.equals("All Customer")) {
                            ResultSet rset1 = Model.Object.Jdbc.getdata("select item_code,description, sum(quantity),sum(profit)  from invoice_item where item_code='" + rset.getString(2) + "' and date_time between '" + start_date1 + "' and '" + end_date1 + "'");
                            if (rset1.next()) {
                                System.out.println(rset1.getString(1));
                                Vector v = new Vector();
                                v.add(rset1.getString(1));
                                v.add(rset1.getString(2));
                                v.add(rset1.getString(3));
                                v.add(rset1.getString(4));
                                df.addRow(v);

                            }
                        } else {
                            ResultSet rset1 = Model.Object.Jdbc.getdata("select item_code,description, sum(quantity),sum(profit)  from invoice_item where customer_code='" + jc + "'and item_code='" + rset.getString(2) + "' and date_time between '" + start_date1 + "' and '" + end_date1 + "'");
                            if (rset1.next()) {
                                System.out.println(rset1.getString(1));
                                Vector v = new Vector();
                                v.add(rset1.getString(1));
                                v.add(rset1.getString(2));
                                v.add(rset1.getString(3));
                                v.add(rset1.getString(4));
                                df.addRow(v);
                            }
                        }
                    }
                }
                jScrollPane1.removeAll();
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptAllCustomersItemSale.jrxml");
                params.put("start_date", start_date);
                params.put("end_date", end_date);
                params.put("customer", customer);

                params.put("company", company);
                params.put("address", address);
                JRTableModelDataSource datasourse = new JRTableModelDataSource(df);
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasourse);
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void customer_wise_sale_report(JScrollPane jScrollPane1) {
        try {
            Vector v1 = new Vector();
            v1.add("All Customer");
            ResultSet rset_item = Model.Object.Jdbc.getdata("select* from customer_master");
            while (rset_item.next()) {
                v1.add(rset_item.getString(2));
            }
            JComboBox jc1 = new JComboBox(v1);
            jc1.setSize(200, 23);
            jc1.setSelectedItem("All Customer");
            final JComponent[] input = new JComponent[]{
                new JLabel("Select Customer"),
                jc1,};
            JOptionPane.showMessageDialog(null, input, "Select", JOptionPane.QUESTION_MESSAGE);
            String jc = "";
            ResultSet rset_c = Model.Object.Jdbc.getdata("select* from customer_master where name='" + jc1.getSelectedItem() + "'");
            if (rset_c.next()) {
                jc = rset_c.getString(1);
            }
            if (jc1.getSelectedItem().toString().equals("All Customer")) {
                customer_item_sale(jScrollPane1);
            } else {
                String start_date = Model.Object.Formated.StartDate();
                String end_date = Model.Object.Formated.EndDate();
                if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                    Model.Object.messagePopUps.date_format_error();
                } else {
                    String start_date1 = start_date + " 00:00:00";
                    String end_date1 = end_date + " 23:59:59";
                    String company = null;
                    String address = null;
                    ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
                    if (rset.next()) {
                        company = rset.getString(1);
                        address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
                    }
                    JTable tbl = new JTable(0, 12);
                    jScrollPane1.removeAll();
                    Map<String, Object> params = new HashMap<String, Object>();
                    InputStream stream = null;
                    stream = this.getClass().getResourceAsStream("/Report/RptCustomerSale.jrxml");
                    params.put("start_date", start_date1);
                    params.put("end_date", end_date1);
                    params.put("customer", jc);
                    params.put("company", company);
                    params.put("address", address);

                    JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                    JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
                    JasperViewer.setDefaultLookAndFeelDecorated(true);
//                    JRViewer jrv = new JRViewer(jasperPrint);
//                    jrv.setSize(jScrollPane1.getSize());
//                    jScrollPane1.add(jrv);
//                    jScrollPane1.updateUI();
                    JRViewer viewer = new JRViewer(jasperPrint);
                    viewer.setSize(800, 680);
                    JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                    frame.setSize(800, 680);
                    frame.add(viewer);
                    FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
                }
            }
        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void past_invoice(JScrollPane jScrollPane1, String invoice_number) {
        try {

            String company = null;
            String address = null;
            String invoice_code = invoice_number;

            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            JTable tbl = new JTable(0, 12);
            jScrollPane1.removeAll();
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptInvoiceA4.jrxml");
            params.put("invoice_code", invoice_code);
            params.put("company", company);
            params.put("address", address);

            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void customer_outstanding(JScrollPane jScrollPane1) {
        try {

            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            jScrollPane1.removeAll();
            JTable tbl = new JTable(0, 12);
            JTable tbl_peiod = new JTable(0, 5);
            Double total_30 = 0.00;
            Double total_60 = 0.00;
            Double total_90 = 0.00;
            Double total_90_over = 0.00;
            Double Total_due = 0.00;
            DefaultTableModel df_period = (DefaultTableModel) tbl_peiod.getModel();
            DefaultTableModel df = (DefaultTableModel) tbl.getModel();
            ResultSet rset_invoice_balance = Model.Object.Jdbc.getdata("select* from invoice_balance where payment_type='" + "Credit" + "'");
            while (rset_invoice_balance.next()) {
                ResultSet rset_payments1 = Model.Object.Jdbc.getdata("select* from payments where payment_status='" + "0" + "' and invoice_or_grn='" + "invoice" + "' and invoice_grn_code='" + rset_invoice_balance.getString(1) + "'");
                if (rset_payments1.next()) {
                    Vector v_inv = new Vector();
                    ResultSet rset_customer = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset_invoice_balance.getString(2) + "'");
                    if (rset_customer.next()) {
                        v_inv.add(rset_customer.getString(2));
                    }
                    v_inv.add(rset_invoice_balance.getString(3));
                    v_inv.add(rset_invoice_balance.getString(1));
                    v_inv.add(rset_invoice_balance.getString(9));
                    v_inv.add("0.00");
                    v_inv.add(rset_invoice_balance.getString(10) + " Invoice");
                    v_inv.add(rset_invoice_balance.getString(9));
                    //group total
                    v_inv.add("1");
                    v_inv.add("2");
                    v_inv.add("3");
                    v_inv.add("4");
                    v_inv.add("5");
                    df.addRow(v_inv);
                    Double invoice_payment = 0.00;
                    ResultSet rset_payments = Model.Object.Jdbc.getdata("select* from payments where payment_status='" + "0" + "' and (invoice_or_grn='" + "invoice" + "' or invoice_or_grn='" + "Invoice Return" + "') and invoice_grn_code='" + rset_invoice_balance.getString(1) + "' ");
                    while (rset_payments.next()) {
                        Vector v_pay = new Vector();
                        ResultSet rset_customer1 = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset_invoice_balance.getString(2) + "'");
                        if (rset_customer1.next()) {
                            v_pay.add(rset_customer1.getString(2));
                        }
                        v_pay.add("");
                        v_pay.add("");
                        v_pay.add("");
                        v_pay.add(rset_payments.getString(6));
                        v_pay.add(rset_payments.getString(9));
                        v_pay.add(rset_payments.getString(7));
                        //group total
                        v_pay.add("1");
                        v_pay.add("2");
                        v_pay.add("3");
                        v_pay.add("4");
                        v_pay.add("5");
                        invoice_payment = invoice_payment + rset_payments.getDouble(6);
                        if (rset_payments.getDouble(6) == 0.0) {
                        } else {
                            df.addRow(v_pay);
                        }
                    }
                    System.out.println(rset_invoice_balance.getString(1) + "  payed Amount" + invoice_payment + "  " + rset_invoice_balance.getDouble(9));
                    ////
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    Date today = new Date();
                    Date invoiceDate = format.parse(rset_invoice_balance.getString("invoice_date"));
                    Date currentDate = format.parse(format.format(today));
                    long diff = invoiceDate.getTime() - currentDate.getTime();
                    long diffDays = diff / (24 * 60 * 60 * 1000);
                    int daydifference = (int) diffDays;
                    Double due_amount = rset_invoice_balance.getDouble(9) - invoice_payment;
                    System.out.println("  due Amount" + (rset_invoice_balance.getDouble(9) - invoice_payment));

                    Vector v_invoice_payment = new Vector();
                    v_invoice_payment.add(rset_invoice_balance.getString(1));
                    v_invoice_payment.add(rset_invoice_balance.getString(2));
                    v_invoice_payment.add(rset_invoice_balance.getString(3));
                    v_invoice_payment.add(due_amount);
                    v_invoice_payment.add(daydifference);
                    df_period.addRow(v_invoice_payment);
                }
            }

            ResultSet rset_customer_2 = Model.Object.Jdbc.getdata("select* from customer_master");
            while (rset_customer_2.next()) {
                Double p_30 = 0.00;
                Double p_60 = 0.00;
                Double p_90 = 0.00;
                Double p_90_over = 0.00;
                Double cus_due = 0.00;
                for (int i = 0; i < df_period.getRowCount(); i++) {
                    if (df_period.getValueAt(i, 1).toString().equals(rset_customer_2.getString(1))) {
                        if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 30) {
                            p_30 = p_30 + Double.parseDouble(df_period.getValueAt(i, 3).toString());
                            System.out.println("p_30"+df_period.getValueAt(i, 4).toString());
                        } else if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 60 && Double.parseDouble(df_period.getValueAt(i, 4).toString()) >= 31) {
                            p_60 = p_60 + Double.parseDouble(df_period.getValueAt(i, 3).toString());
                            System.out.println("p_60"+df_period.getValueAt(i, 4).toString());
                        } else if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 90 && Double.parseDouble(df_period.getValueAt(i, 4).toString()) >= 61) {
                            p_90 = p_90 + Double.parseDouble(df_period.getValueAt(i, 3).toString());
                            System.out.println("p_90"+df_period.getValueAt(i, 4).toString());
                        } else if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 91) {
                            p_90_over = p_90_over + Double.parseDouble(df_period.getValueAt(i, 3).toString());
                            System.out.println("p_90_over"+df_period.getValueAt(i, 4).toString());
                        }
                    }
                }
                total_30 = total_30 + p_30;
                total_60 = total_60 + p_60;
                total_90 = total_90 + p_90;
                total_90_over = total_90_over + p_90_over;
                cus_due = p_30 + p_60 + p_90 + p_90_over;
                for (int j = 0; j < df.getRowCount(); j++) {
                    if (rset_customer_2.getString(2).equals(df.getValueAt(j, 0).toString())) {
                        df.setValueAt(p_30, j, 7);
                        df.setValueAt(p_60, j, 8);
                        df.setValueAt(p_90, j, 9);
                        df.setValueAt(p_90_over, j, 10);
                        df.setValueAt(cus_due, j, 11);
                    }
                }
                Total_due = total_30 + total_60 + total_90 + total_90_over;

                p_30 = 0.00;
                p_60 = 0.00;
                p_90 = 0.00;
                p_90_over = 0.00;
                cus_due = 0.00;
            }
            JRTableModelDataSource datasourse = new JRTableModelDataSource(df);
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptCusTotalOutstanding.jrxml");
            params.put("company", company);
            params.put("address", address);

            params.put("duration_1", total_30);
            params.put("duration_2", total_60);
            params.put("duration_3", total_90);
            params.put("duration_4", total_90_over);
            params.put("total", Total_due);

            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasourse);
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void customer_wise_outstanding(JScrollPane jScrollPane1, String customer) {
        try {

            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            jScrollPane1.removeAll();
            JTable tbl = new JTable(0, 12);
            JTable tbl_peiod = new JTable(0, 5);
            Double total_30 = 0.00;
            Double total_60 = 0.00;
            Double total_90 = 0.00;
            Double total_90_over = 0.00;
            Double Total_due = 0.00;
            DefaultTableModel df_period = (DefaultTableModel) tbl_peiod.getModel();
            DefaultTableModel df = (DefaultTableModel) tbl.getModel();
            ResultSet rset_invoice_balance = Model.Object.Jdbc.getdata("select* from invoice_balance where payment_type='" + "Credit" + "' and customer_code='" + customer + "'");
            while (rset_invoice_balance.next()) {
                ResultSet rset_payments1 = Model.Object.Jdbc.getdata("select* from payments where payment_status='" + "0" + "' and invoice_or_grn='" + "invoice" + "' and invoice_grn_code='" + rset_invoice_balance.getString(1) + "'");
                if (rset_payments1.next()) {
                    Vector v_inv = new Vector();
                    ResultSet rset_customer = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset_invoice_balance.getString(2) + "'");
                    if (rset_customer.next()) {
                        v_inv.add(rset_customer.getString(2));
                    }
                    v_inv.add(rset_invoice_balance.getString(3));
                    v_inv.add(rset_invoice_balance.getString(1));
                    v_inv.add(rset_invoice_balance.getString(9));
                    v_inv.add("0.00");
                    v_inv.add(rset_invoice_balance.getString(10) + " Invoice");
                    v_inv.add(rset_invoice_balance.getString(9));
                    //group total
                    v_inv.add("1");
                    v_inv.add("2");
                    v_inv.add("3");
                    v_inv.add("4");
                    v_inv.add("5");
                    df.addRow(v_inv);
                    Double invoice_payment = 0.00;
                    ResultSet rset_payments = Model.Object.Jdbc.getdata("select* from payments where payment_status='" + "0" + "' and (invoice_or_grn='" + "invoice" + "' or invoice_or_grn='" + "Invoice Return" + "') and invoice_grn_code='" + rset_invoice_balance.getString(1) + "' ");
                    while (rset_payments.next()) {
                        Vector v_pay = new Vector();
                        ResultSet rset_customer1 = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset_invoice_balance.getString(2) + "'");
                        if (rset_customer1.next()) {
                            v_pay.add(rset_customer1.getString(2));
                        }
                        v_pay.add("");
                        v_pay.add("");
                        v_pay.add("");
                        v_pay.add(rset_payments.getString(6));
                        v_pay.add(rset_payments.getString(9));
                        v_pay.add(rset_payments.getString(7));
                        //group total
                        v_pay.add("1");
                        v_pay.add("2");
                        v_pay.add("3");
                        v_pay.add("4");
                        v_pay.add("5");
                        invoice_payment = invoice_payment + rset_payments.getDouble(6);
                        if (rset_payments.getDouble(6) == 0.0) {
                        } else {
                            df.addRow(v_pay);
                        }
                    }
                    System.out.println(rset_invoice_balance.getString(1) + "  payed Amount" + invoice_payment + "  " + rset_invoice_balance.getDouble(9));
                    ////
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    Date today = new Date();
                    Date invoiceDate = format.parse(rset_invoice_balance.getString("invoice_date"));
                    Date currentDate = format.parse(format.format(today));
                    long diff = invoiceDate.getTime() - currentDate.getTime();
                    long diffDays = diff / (24 * 60 * 60 * 1000);
                    int daydifference = (int) diffDays;
                    Double due_amount = rset_invoice_balance.getDouble(9) - invoice_payment;
                    System.out.println("  due Amount" + (rset_invoice_balance.getDouble(9) - invoice_payment));

                    Vector v_invoice_payment = new Vector();
                    v_invoice_payment.add(rset_invoice_balance.getString(1));
                    v_invoice_payment.add(rset_invoice_balance.getString(2));
                    v_invoice_payment.add(rset_invoice_balance.getString(3));
                    v_invoice_payment.add(due_amount);
                    v_invoice_payment.add(daydifference);
                    df_period.addRow(v_invoice_payment);
                }
            }

            ResultSet rset_customer_2 = Model.Object.Jdbc.getdata("select* from customer_master");
            while (rset_customer_2.next()) {
                Double p_30 = 0.00;
                Double p_60 = 0.00;
                Double p_90 = 0.00;
                Double p_90_over = 0.00;
                Double cus_due = 0.00;
                for (int i = 0; i < df_period.getRowCount(); i++) {
                    if (df_period.getValueAt(i, 1).toString().equals(rset_customer_2.getString(1))) {
                        if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 30) {
                            p_30 = p_30 + Double.parseDouble(df_period.getValueAt(i, 3).toString());

                        } else if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 60 && Double.parseDouble(df_period.getValueAt(i, 4).toString()) >= 31) {
                            p_60 = p_60 + Double.parseDouble(df_period.getValueAt(i, 3).toString());

                        } else if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 90 && Double.parseDouble(df_period.getValueAt(i, 4).toString()) >= 61) {
                            p_90 = p_90 + Double.parseDouble(df_period.getValueAt(i, 3).toString());

                        } else if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 91) {
                            p_90_over = p_90_over + Double.parseDouble(df_period.getValueAt(i, 3).toString());

                        }
                    }
                }
                total_30 = total_30 + p_30;
                total_60 = total_60 + p_60;
                total_90 = total_90 + p_90;
                total_90_over = total_90_over + p_90_over;
                cus_due = p_30 + p_60 + p_90 + p_90_over;
                for (int j = 0; j < df.getRowCount(); j++) {
                    if (rset_customer_2.getString(2).equals(df.getValueAt(j, 0).toString())) {
                        df.setValueAt(p_30, j, 7);
                        df.setValueAt(p_60, j, 8);
                        df.setValueAt(p_90, j, 9);
                        df.setValueAt(p_90_over, j, 10);
                        df.setValueAt(cus_due, j, 11);
                    }
                }
                Total_due = total_30 + total_60 + total_90 + total_90_over;

                p_30 = 0.00;
                p_60 = 0.00;
                p_90 = 0.00;
                p_90_over = 0.00;
                cus_due = 0.00;
            }
            JRTableModelDataSource datasourse = new JRTableModelDataSource(df);
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptCuswiseOutstanding.jrxml");
            params.put("company", company);
            params.put("address", address);

            params.put("duration_1", total_30);
            params.put("duration_2", total_60);
            params.put("duration_3", total_90);
            params.put("duration_4", total_90_over);
            params.put("total", Total_due);

            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasourse);
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void customers(JScrollPane jScrollPane1) {
        try {
            jScrollPane1.removeAll();
            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptlCustomersDetails.jrxml");
            params.put("company", company);
            params.put("address", address);
            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
        } catch (Exception e) {
        }
    }

    public void customer_item_sale(JScrollPane jScrollPane1) {
        try {
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                jScrollPane1.removeAll();
                String company = null;
                String address = null;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset.next()) {
                    company = rset.getString(1);
                    address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
                }
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptCustomersSales.jrxml");
                params.put("company", company);
                params.put("address", address);
                params.put("start_date", start_date);
                params.put("end_date", end_date);
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
        }
    }

    public void supplier_wise_stock(JScrollPane jScrollPane1) {
        try {
            JTable jt = new JTable(0, 6);
            DefaultTableModel df = (DefaultTableModel) jt.getModel();

            Vector v1 = new Vector();
            ResultSet rset_supplier1 = Model.Object.Jdbc.getdata("select* from supplier_master");
            while (rset_supplier1.next()) {
                v1.add(rset_supplier1.getString(2));
            }
            JComboBox jc1 = new JComboBox(v1);
            jc1.setEditable(true);
            AutoCompleteDecorator.decorate(jc1);
            jc1.setSize(200, 23);
            final JComponent[] input = new JComponent[]{
                new JLabel("Select Supplier"),
                jc1,};
            JOptionPane.showMessageDialog(null, input, "Select", JOptionPane.QUESTION_MESSAGE);

            ResultSet rset_supplier = Model.Object.Jdbc.getdata("select* from supplier_master where  name='" + jc1.getSelectedItem() + "'");
            if (rset_supplier.next()) {
                ResultSet rset_grn = Model.Object.Jdbc.getdata("select* from grn_item where supplier_code='" + rset_supplier.getString(1) + "'");
                while (rset_grn.next()) {
                    Double quantity = 0.0;
                    ResultSet rset_stock = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + rset_grn.getString(2) + "' order by item_code");
                    while (rset_stock.next()) {
                        quantity = quantity + rset_stock.getDouble(4);
                    }
                    ResultSet rset_cost = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + rset_grn.getString(2) + "'");
                    if (rset_cost.next()) {
                        boolean bool = false;
                        for (int i = 0; i < jt.getRowCount(); i++) {
                            if (df.getValueAt(i, 0).equals(rset_supplier.getString(2))) {
                                if (df.getValueAt(i, 1).equals(rset_grn.getString(2))) {
                                    bool = true;
                                    break;
                                }
                            } else {
                                bool = false;
                            }
                        }
                        if (bool == false) {
                            Vector v = new Vector();
                            v.add(rset_supplier.getString(2));
                            v.add(rset_grn.getString(2));
                            v.add(rset_grn.getString(3));
                            v.add(rset_cost.getDouble(5));
                            v.add(quantity);
                            v.add(rset_cost.getDouble(5) * quantity);
                            df.addRow(v);
                        }
                    }

                }
            }
            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            jScrollPane1.removeAll();
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptSupplierwiseStock.jrxml");

            params.put("company", company);
            params.put("address", address);
            JRTableModelDataSource datasource = new JRTableModelDataSource(df);
            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasource);
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void date_grn_cost(JScrollPane jScrollPane1) {
        try {
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                String company = null;
                String address = null;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset.next()) {
                    company = rset.getString(1);
                    address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
                }
                jScrollPane1.removeAll();
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptAllSupplierwiseGrnCost.jrxml");
                params.put("start_date", start_date);
                params.put("end_date", end_date);

                params.put("company", company);
                params.put("address", address);

                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void supplier_wise_grn_cost(JScrollPane jScrollPane1, String supplier_code) {
        try {
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                String company = null;
                String address = null;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset.next()) {
                    company = rset.getString(1);
                    address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
                }
                jScrollPane1.removeAll();
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptSupplierwiseGrnCost.jrxml");
                params.put("start_date", start_date);
                params.put("end_date", end_date);
                params.put("supplier", supplier_code);

                params.put("company", company);
                params.put("address", address);

                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void item_total_supplier(JScrollPane jScrollPane1) {
        try {
            JTable jt = new JTable(0, 5);
            DefaultTableModel df = (DefaultTableModel) jt.getModel();

            ResultSet rset_item_master = Model.Object.Jdbc.getdata("select* from item_master order by item_code");
            while (rset_item_master.next()) {
                Vector v = new Vector();
                ResultSet rset_grn_item = Model.Object.Jdbc.getdata("select sum(quantity),sum(sub_total),supplier_code from grn_item where item_code='" + rset_item_master.getString(1) + "' order by supplier_code");
                if (rset_grn_item.next()) {
                    ResultSet rset_supplier = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset_grn_item.getString(3) + "'");
                    if (rset_supplier.next()) {
                        v.add(rset_supplier.getString(1) + " " + rset_supplier.getString(2));
                    } else {
                        v.add("Unknown");
                    }
                    v.add(rset_item_master.getString(1));
                    v.add(rset_item_master.getString(2));
                    v.add(rset_grn_item.getDouble(1));
                    v.add(rset_grn_item.getDouble(2));
                    df.addRow(v);
                }
            }

            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            jScrollPane1.removeAll();
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptAllsupplierItemBy.jrxml");

            params.put("company", company);
            params.put("address", address);
            JRTableModelDataSource datasourse = new JRTableModelDataSource(df);
            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasourse);
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void supplier_total_outstanding(JScrollPane jScrollPane1) {
        try {

            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            jScrollPane1.removeAll();
            JTable tbl = new JTable(0, 12);
            JTable tbl_peiod = new JTable(0, 5);
            Double total_30 = 0.00;
            Double total_60 = 0.00;
            Double total_90 = 0.00;
            Double total_90_over = 0.00;
            Double Total_due = 0.00;
            DefaultTableModel df_period = (DefaultTableModel) tbl_peiod.getModel();
            DefaultTableModel df = (DefaultTableModel) tbl.getModel();
            ResultSet rset_grn_balance = Model.Object.Jdbc.getdata("select grn_code,supplier_code,supplier_invoice_code,supplier_invoice_date,supplier_invoice_due_date,gen_date,amount,discount_type,discount,net_amount,return_grn_amount,sub_total,payment_type,payment,balance,grn_status,location,date_time,user from grn_balance where payment_type='" + "Credit" + "' order by supplier_code,grn_code ASC");
            while (rset_grn_balance.next()) {
                System.out.println(rset_grn_balance.getString(1));
                ResultSet rset_payments1 = Model.Object.Jdbc.getdata("select* from payments where payment_status='" + "0" + "' and invoice_or_grn='" + "grn" + "' and invoice_grn_code='" + rset_grn_balance.getString(1) + "'");
                if (rset_payments1.next()) {
                    Vector v_inv = new Vector();
                    ResultSet rset_supplier = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset_grn_balance.getString(2) + "'");
                    if (rset_supplier.next()) {
                        v_inv.add(rset_supplier.getString(2));
                    } else {
                        v_inv.add("Unknown");
                    }
                    v_inv.add(rset_grn_balance.getString(6));
                    v_inv.add(rset_grn_balance.getString(1));
                    v_inv.add(rset_grn_balance.getString(12));
                    v_inv.add("0.00");
                    v_inv.add(rset_grn_balance.getString(13) + " Grn");
                    v_inv.add(rset_grn_balance.getString(12));
                    //group total
                    v_inv.add("1");
                    v_inv.add("2");
                    v_inv.add("3");
                    v_inv.add("4");
                    v_inv.add("5");
                    df.addRow(v_inv);
                    Double grn_payment = 0.00;
                    ResultSet rset_payments = Model.Object.Jdbc.getdata("select* from payments where payment_status='" + "0" + "' and (invoice_or_grn='" + "grn" + "' or invoice_or_grn='" + "Grn Return" + "') and invoice_grn_code='" + rset_grn_balance.getString(1) + "' ");
                    while (rset_payments.next()) {
                        Vector v_pay = new Vector();
                        ResultSet rset_supplier1 = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset_grn_balance.getString(2) + "'");
                        if (rset_supplier1.next()) {
                            v_pay.add(rset_supplier1.getString(2));
                        }
                        v_pay.add("");
                        v_pay.add("");
                        v_pay.add("");
                        v_pay.add(rset_payments.getString(6));
                        v_pay.add(rset_payments.getString(9));
                        v_pay.add(rset_payments.getString(7));
                        //group total
                        v_pay.add("1");
                        v_pay.add("2");
                        v_pay.add("3");
                        v_pay.add("4");
                        v_pay.add("5");
                        grn_payment = grn_payment + rset_payments.getDouble(6);
                        if (rset_payments.getDouble(6) == 0.0) {
                        } else {
                            df.addRow(v_pay);
                        }
                    }
                    System.out.println(rset_grn_balance.getString(1) + "  payed Amount" + grn_payment + "  " + rset_grn_balance.getDouble(9));
                    ////
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    Date today = new Date();
                    Date invoiceDate = format.parse(rset_grn_balance.getString("gen_date"));
                    Date currentDate = format.parse(format.format(today));
                    long diff = invoiceDate.getTime() - currentDate.getTime();
                    long diffDays = diff / (24 * 60 * 60 * 1000);
                    int daydifference = (int) diffDays;
                    Double due_amount = rset_grn_balance.getDouble(12) - grn_payment;
                    System.out.println("  due Amount" + (rset_grn_balance.getDouble(12) - grn_payment));

                    Vector v_invoice_payment = new Vector();
                    v_invoice_payment.add(rset_grn_balance.getString(1));
                    v_invoice_payment.add(rset_grn_balance.getString(2));
                    v_invoice_payment.add(rset_grn_balance.getString(6));
                    v_invoice_payment.add(due_amount);
                    v_invoice_payment.add(daydifference);
                    df_period.addRow(v_invoice_payment);
                }
            }

            ResultSet rset_supplier_2 = Model.Object.Jdbc.getdata("select* from supplier_master");
            while (rset_supplier_2.next()) {
                Double p_30 = 0.00;
                Double p_60 = 0.00;
                Double p_90 = 0.00;
                Double p_90_over = 0.00;
                Double cus_due = 0.00;
                for (int i = 0; i < df_period.getRowCount(); i++) {
                    if (df_period.getValueAt(i, 1).toString().equals(rset_supplier_2.getString(1))) {
                        if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 30) {
                            p_30 = p_30 + Double.parseDouble(df_period.getValueAt(i, 3).toString());

                        } else if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 60 && Double.parseDouble(df_period.getValueAt(i, 4).toString()) >= 31) {
                            p_60 = p_60 + Double.parseDouble(df_period.getValueAt(i, 3).toString());

                        } else if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 90 && Double.parseDouble(df_period.getValueAt(i, 4).toString()) >= 61) {
                            p_90 = p_90 + Double.parseDouble(df_period.getValueAt(i, 3).toString());

                        } else if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 91) {
                            p_90_over = p_90_over + Double.parseDouble(df_period.getValueAt(i, 3).toString());

                        }
                    }
                }
                total_30 = total_30 + p_30;
                total_60 = total_60 + p_60;
                total_90 = total_90 + p_90;
                total_90_over = total_90_over + p_90_over;
                cus_due = p_30 + p_60 + p_90 + p_90_over;
                for (int j = 0; j < df.getRowCount(); j++) {
                    if (rset_supplier_2.getString(2).equals(df.getValueAt(j, 0).toString())) {
                        df.setValueAt(p_30, j, 7);
                        df.setValueAt(p_60, j, 8);
                        df.setValueAt(p_90, j, 9);
                        df.setValueAt(p_90_over, j, 10);
                        df.setValueAt(cus_due, j, 11);
                    }
                }
                Total_due = total_30 + total_60 + total_90 + total_90_over;

                p_30 = 0.00;
                p_60 = 0.00;
                p_90 = 0.00;
                p_90_over = 0.00;
                cus_due = 0.00;
            }
            JRTableModelDataSource datasourse = new JRTableModelDataSource(df);
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptsupplierTotalOutstanding.jrxml");
            params.put("company", company);
            params.put("address", address);

            params.put("duration_1", total_30);
            params.put("duration_2", total_60);
            params.put("duration_3", total_90);
            params.put("duration_4", total_90_over);
            params.put("total", Total_due);

            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasourse);
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void suplier_wise_outstanding(JScrollPane jScrollPane1, String supplier) {
        try {

            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            jScrollPane1.removeAll();
            JTable tbl = new JTable(0, 12);
            JTable tbl_peiod = new JTable(0, 5);
            Double total_30 = 0.00;
            Double total_60 = 0.00;
            Double total_90 = 0.00;
            Double total_90_over = 0.00;
            Double Total_due = 0.00;
            DefaultTableModel df_period = (DefaultTableModel) tbl_peiod.getModel();
            DefaultTableModel df = (DefaultTableModel) tbl.getModel();
            ResultSet rset_grn_balance = Model.Object.Jdbc.getdata("select* from grn_balance where payment_type='" + "Credit" + "' and supplier_code='" + supplier + "'");
            while (rset_grn_balance.next()) {
                ResultSet rset_payments1 = Model.Object.Jdbc.getdata("select* from payments where payment_status='" + "0" + "' and invoice_or_grn='" + "grn" + "' and invoice_grn_code='" + rset_grn_balance.getString(1) + "'");
                if (rset_payments1.next()) {
                    Vector v_inv = new Vector();
                    ResultSet rset_customer = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset_grn_balance.getString(2) + "'");
                    if (rset_customer.next()) {
                        v_inv.add(rset_customer.getString(2));
                    }
                    v_inv.add(rset_grn_balance.getString(6));
                    v_inv.add(rset_grn_balance.getString(1));
                    v_inv.add(rset_grn_balance.getString(12));
                    v_inv.add("0.00");
                    v_inv.add(rset_grn_balance.getString(13) + " Grn");
                    v_inv.add(rset_grn_balance.getString(12));
                    //group total
                    v_inv.add("1");
                    v_inv.add("2");
                    v_inv.add("3");
                    v_inv.add("4");
                    v_inv.add("5");
                    df.addRow(v_inv);
                    Double invoice_payment = 0.00;
                    ResultSet rset_payments = Model.Object.Jdbc.getdata("select* from payments where payment_status='" + "0" + "' and (invoice_or_grn='" + "grn" + "' or invoice_or_grn='" + "Grn Return" + "') and invoice_grn_code='" + rset_grn_balance.getString(1) + "' ");
                    while (rset_payments.next()) {
                        Vector v_pay = new Vector();
                        ResultSet rset_customer1 = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset_grn_balance.getString(2) + "'");
                        if (rset_customer1.next()) {
                            v_pay.add(rset_customer1.getString(2));
                        }
                        v_pay.add("");
                        v_pay.add("");
                        v_pay.add("");
                        v_pay.add(rset_payments.getString(6));
                        v_pay.add(rset_payments.getString(9));
                        v_pay.add(rset_payments.getString(7));
                        //group total
                        v_pay.add("1");
                        v_pay.add("2");
                        v_pay.add("3");
                        v_pay.add("4");
                        v_pay.add("5");
                        invoice_payment = invoice_payment + rset_payments.getDouble(6);
                        if (rset_payments.getDouble(6) == 0.0) {
                        } else {
                            df.addRow(v_pay);
                        }
                    }
                    System.out.println(rset_grn_balance.getString(1) + "  payed Amount" + invoice_payment + "  " + rset_grn_balance.getDouble(9));
                    ////
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    Date today = new Date();
                    Date invoiceDate = format.parse(rset_grn_balance.getString("gen_date"));
                    Date currentDate = format.parse(format.format(today));
                    long diff = invoiceDate.getTime() - currentDate.getTime();
                    long diffDays = diff / (24 * 60 * 60 * 1000);
                    int daydifference = (int) diffDays;
                    Double due_amount = rset_grn_balance.getDouble(12) - invoice_payment;
                    System.out.println("  due Amount" + (rset_grn_balance.getDouble(12) - invoice_payment));

                    Vector v_invoice_payment = new Vector();
                    v_invoice_payment.add(rset_grn_balance.getString(1));
                    v_invoice_payment.add(rset_grn_balance.getString(2));
                    v_invoice_payment.add(rset_grn_balance.getString(6));
                    v_invoice_payment.add(due_amount);
                    v_invoice_payment.add(daydifference);
                    df_period.addRow(v_invoice_payment);
                }
            }

            ResultSet rset_customer_2 = Model.Object.Jdbc.getdata("select* from supplier_master");
            while (rset_customer_2.next()) {
                Double p_30 = 0.00;
                Double p_60 = 0.00;
                Double p_90 = 0.00;
                Double p_90_over = 0.00;
                Double cus_due = 0.00;
                for (int i = 0; i < df_period.getRowCount(); i++) {
                    if (df_period.getValueAt(i, 1).toString().equals(rset_customer_2.getString(1))) {
                        if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 30) {
                            p_30 = p_30 + Double.parseDouble(df_period.getValueAt(i, 3).toString());

                        } else if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 60 && Double.parseDouble(df_period.getValueAt(i, 4).toString()) >= 31) {
                            p_60 = p_60 + Double.parseDouble(df_period.getValueAt(i, 3).toString());

                        } else if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 90 && Double.parseDouble(df_period.getValueAt(i, 4).toString()) >= 61) {
                            p_90 = p_90 + Double.parseDouble(df_period.getValueAt(i, 3).toString());

                        } else if (Double.parseDouble(df_period.getValueAt(i, 4).toString()) <= 91) {
                            p_90_over = p_90_over + Double.parseDouble(df_period.getValueAt(i, 3).toString());

                        }
                    }
                }
                total_30 = total_30 + p_30;
                total_60 = total_60 + p_60;
                total_90 = total_90 + p_90;
                total_90_over = total_90_over + p_90_over;
                cus_due = p_30 + p_60 + p_90 + p_90_over;
                for (int j = 0; j < df.getRowCount(); j++) {
                    if (rset_customer_2.getString(2).equals(df.getValueAt(j, 0).toString())) {
                        df.setValueAt(p_30, j, 7);
                        df.setValueAt(p_60, j, 8);
                        df.setValueAt(p_90, j, 9);
                        df.setValueAt(p_90_over, j, 10);
                        df.setValueAt(cus_due, j, 11);
                    }
                }
                Total_due = total_30 + total_60 + total_90 + total_90_over;

                p_30 = 0.00;
                p_60 = 0.00;
                p_90 = 0.00;
                p_90_over = 0.00;
                cus_due = 0.00;
            }
            JRTableModelDataSource datasourse = new JRTableModelDataSource(df);
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptsupwiseOutstanding.jrxml");
            params.put("company", company);
            params.put("address", address);

            params.put("duration_1", total_30);
            params.put("duration_2", total_60);
            params.put("duration_3", total_90);
            params.put("duration_4", total_90_over);
            params.put("total", Total_due);

            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasourse);
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void past_grn(JScrollPane jScrollPane1, String grn_number) {
        try {

            String company = null;
            String address = null;
            String grn_code = grn_number;
            ResultSet rsete = Model.Object.Jdbc.getdata("select grn_code from grn_balance where supplier_invoice_code='" + grn_number + "'");
            if (rsete.next()) {
                grn_code = rsete.getString(1);

            }
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            jScrollPane1.removeAll();
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptGrnA4.jrxml");
            params.put("grn_code", grn_code);
            params.put("company", company);
            params.put("address", address);

            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void supplier_wise_item_total(JScrollPane jScrollPane1) {
        try {
            Vector v1 = new Vector();
            v1.add("All Supplier");
            ResultSet rset_item = Model.Object.Jdbc.getdata("select* from supplier_master");
            while (rset_item.next()) {
                v1.add(rset_item.getString(2));
            }
            JComboBox jc1 = new JComboBox(v1);
            jc1.setSize(200, 23);
            jc1.setSelectedItem("All Supplier");
            final JComponent[] input = new JComponent[]{
                new JLabel("Select Supplier"),
                jc1,};
            JOptionPane.showMessageDialog(null, input, "Select", JOptionPane.QUESTION_MESSAGE);
            String jc = "";
            ResultSet rset_c = Model.Object.Jdbc.getdata("select* from Supplier_master where name='" + jc1.getSelectedItem() + "'");
            if (rset_c.next()) {
                jc = rset_c.getString(1);
            }
            if (jc1.getSelectedItem().toString().equals("All Supplier")) {
                item_total_supplier(jScrollPane1);
            } else {
                JTable jt = new JTable(0, 5);
                DefaultTableModel df = (DefaultTableModel) jt.getModel();

                ResultSet rset_item_master = Model.Object.Jdbc.getdata("select* from item_master order by item_code");
                while (rset_item_master.next()) {
                    Vector v = new Vector();
                    ResultSet rset_grn_item = Model.Object.Jdbc.getdata("select sum(quantity),sum(sub_total),supplier_code from grn_item where item_code='" + rset_item_master.getString(1) + "' and supplier_code='" + jc + "' order by supplier_code");
                    if (rset_grn_item.next()) {
                        if (rset_grn_item.getDouble(1) == 0) {
                        } else {
                            ResultSet rset_supplier = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + jc + "'");
                            if (rset_supplier.next()) {
                                v.add(rset_supplier.getString(1) + " " + rset_supplier.getString(2));
                            } else {
                                v.add("Unknown");
                            }
                            v.add(rset_item_master.getString(1));
                            v.add(rset_item_master.getString(2));
                            v.add(rset_grn_item.getDouble(1));
                            v.add(rset_grn_item.getDouble(2));
                            df.addRow(v);
                        }
                    }
                }

                String company = null;
                String address = null;
                ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset.next()) {
                    company = rset.getString(1);
                    address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
                }
                jScrollPane1.removeAll();
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptsupplierWiseItemBy.jrxml");

                params.put("company", company);
                params.put("address", address);
                JRTableModelDataSource datasourse = new JRTableModelDataSource(df);
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasourse);
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

            }
        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void suppliers(JScrollPane jScrollPane1) {
        try {
            jScrollPane1.removeAll();
            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptSuppliuerDetails.jrxml");
            params.put("company", company);
            params.put("address", address);
            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
        }
    }

    public void full_item_bincard(JScrollPane jScrollPane1) {
        try {
            jScrollPane1.removeAll();
            Vector v1 = new Vector();
            ResultSet rset_item = Model.Object.Jdbc.getdata("select* from item_master");
            while (rset_item.next()) {
                v1.add(rset_item.getString(2));
            }
            JComboBox jc1 = new JComboBox(v1);
            jc1.setEditable(true);
            AutoCompleteDecorator.decorate(jc1);
            jc1.setSize(200, 23);
            final JComponent[] input = new JComponent[]{
                new JLabel("Select Item"),
                jc1,};
            JOptionPane.showMessageDialog(null, input, "Select", JOptionPane.QUESTION_MESSAGE);
            String item_code = "";
            ResultSet rset_item1 = Model.Object.Jdbc.getdata("select* from item_master where item_description='" + jc1.getSelectedItem() + "'");
            if (rset_item1.next()) {
                item_code = rset_item1.getString(1);
            }
            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptItemBincard.jrxml");
            params.put("company", company);
            params.put("address", address);
            params.put("item_code", item_code);

            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
        }
    }

    public void location_wise_item_bincard(JScrollPane jScrollPane1) {
        try {
            jScrollPane1.removeAll();
            Vector v1 = new Vector();
            ResultSet rset_item = Model.Object.Jdbc.getdata("select* from item_master");
            while (rset_item.next()) {
                v1.add(rset_item.getString(2));
            }
            JComboBox jc1 = new JComboBox(v1);
            jc1.setSize(200, 23);
            jc1.setEditable(true);
            AutoCompleteDecorator.decorate(jc1);
            final JComponent[] input = new JComponent[]{
                new JLabel("Select Item"),
                jc1,};
            JOptionPane.showMessageDialog(null, input, "Select", JOptionPane.QUESTION_MESSAGE);

            Vector v2 = new Vector();
            v2.add("WAREHOUSE");
            v2.add("OUTLET");

            JComboBox jc2 = new JComboBox(v2);
            jc2.setSize(200, 23);
            final JComponent[] input1 = new JComponent[]{
                new JLabel("Select Location"),
                jc2,};
            JOptionPane.showMessageDialog(null, input1, "Select", JOptionPane.QUESTION_MESSAGE);

            String item_code = "";
            ResultSet rset_item1 = Model.Object.Jdbc.getdata("select* from item_master where item_description='" + jc1.getSelectedItem() + "'");
            if (rset_item1.next()) {
                item_code = rset_item1.getString(1);
            }
            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptItemBincardLocationWise.jrxml");
            params.put("company", company);
            params.put("address", address);
            params.put("item_code", item_code);
            params.put("location", jc2.getSelectedItem().toString());

            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
        }
    }

    public void stock(JScrollPane jScrollPane1) {
        try {
            jScrollPane1.removeAll();
            Vector v = new Vector();
            v.add("Full Stock");
            v.add("Warehouse Stock");
            v.add("Outlet Stock");

            JComboBox jc = new JComboBox(v);
            jc.setSize(200, 23);
            final JComponent[] input = new JComponent[]{
                new JLabel("Select Location"),
                jc,};
            JOptionPane.showMessageDialog(null, input, "Select", JOptionPane.QUESTION_MESSAGE);
            JTable jt = new JTable(0, 6);
            DefaultTableModel df = (DefaultTableModel) jt.getModel();
            df.setRowCount(0);
            if (jc.getSelectedItem().equals("Full Stock")) {
                ResultSet rset_stock1 = Model.Object.Jdbc.getdata("select item_master.item_code,item_master.item_description,item_master.category,item_master.main_item_cost,item_master.main_item_avarage_cost,item_master.main_item_sell_price,item_master.unit_of_measure,item_master.sub_1_cost_price,item_master.sub_1_sall_price,item_master.sub_2_quantity,item_master.sub_2_unit_price,item_master.sub_2_sall_price,item_master.sub_3_quantity,item_master.sub_3_unit_price,item_master.sub_3_sall_price,item_master.sub_4_quantity,item_master.sub_4_cost_price,item_master.sub_4_sall_price,item_master.supplier_code,item_master.add_date_time from item_master order by item_master.item_description asc");
                while (rset_stock1.next()) {
                    Vector vs = new Vector();
                    Double qty = 0.0;
                    ResultSet rset_inventory = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + rset_stock1.getString(1) + "'");
                    while (rset_inventory.next()) {
                        qty = qty + rset_inventory.getDouble(4);
                    }
                    vs.add(rset_stock1.getString(1));
                    vs.add(rset_stock1.getString(2));
                    vs.add(rset_stock1.getDouble(5));
                    vs.add(qty);
                    vs.add(rset_stock1.getDouble(5) * qty);
                    vs.add(rset_stock1.getDouble(6));
                    df.addRow(vs);
                }
            } else if (jc.getSelectedItem().equals("Warehouse Stock")) {
                ResultSet rset_stock1 = Model.Object.Jdbc.getdata("select item_master.item_code,item_master.item_description,item_master.category,item_master.main_item_cost,item_master.main_item_avarage_cost,item_master.main_item_sell_price,item_master.unit_of_measure,item_master.sub_1_cost_price,item_master.sub_1_sall_price,item_master.sub_2_quantity,item_master.sub_2_unit_price,item_master.sub_2_sall_price,item_master.sub_3_quantity,item_master.sub_3_unit_price,item_master.sub_3_sall_price,item_master.sub_4_quantity,item_master.sub_4_cost_price,item_master.sub_4_sall_price,item_master.supplier_code,item_master.add_date_time from item_master order by item_master.item_description asc");
                while (rset_stock1.next()) {
                    Vector vs = new Vector();
                    Double qty = 0.0;
                    Double cost = 0.0;
                    ResultSet rset_inventory = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + rset_stock1.getString(1) + "' and location='" + "WAREHOUSE" + "'");
                    if (rset_inventory.next()) {
                        qty = rset_inventory.getDouble(4);
                        cost = rset_inventory.getDouble(3);
                    }
                    vs.add(rset_stock1.getString(1));
                    vs.add(rset_stock1.getString(2));
                    vs.add(cost);
                    vs.add(qty);
                    vs.add(cost * qty);
                    vs.add(rset_stock1.getDouble(6));
                    df.addRow(vs);
                }
            } else if (jc.getSelectedItem().equals("Outlet Stock")) {
                ResultSet rset_stock1 = Model.Object.Jdbc.getdata("select item_master.item_code,item_master.item_description,item_master.category,item_master.main_item_cost,item_master.main_item_avarage_cost,item_master.main_item_sell_price,item_master.unit_of_measure,item_master.sub_1_cost_price,item_master.sub_1_sall_price,item_master.sub_2_quantity,item_master.sub_2_unit_price,item_master.sub_2_sall_price,item_master.sub_3_quantity,item_master.sub_3_unit_price,item_master.sub_3_sall_price,item_master.sub_4_quantity,item_master.sub_4_cost_price,item_master.sub_4_sall_price,item_master.supplier_code,item_master.add_date_time from item_master  order by item_master.item_description asc");
                while (rset_stock1.next()) {
                    Vector vs = new Vector();
                    Double qty = 0.0;
                    Double cost = 0.0;
                    ResultSet rset_inventory = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + rset_stock1.getString(1) + "' and location='" + "OUTLET" + "'");
                    if (rset_inventory.next()) {
                        qty = rset_inventory.getDouble(4);
                        cost = rset_inventory.getDouble(3);
                    }
                    vs.add(rset_stock1.getString(1));
                    vs.add(rset_stock1.getString(2));
                    vs.add(cost);
                    vs.add(qty);
                    vs.add(cost * qty);
                    vs.add(rset_stock1.getDouble(6));
                    df.addRow(vs);
                }
            } else if (jc.getSelectedItem().equals("Vehicle Stock")) {
                ResultSet rset_stock1 = Model.Object.Jdbc.getdata("select* from item_master");
                while (rset_stock1.next()) {
                    Vector vs = new Vector();
                    Double qty = 0.0;
                    Double cost = 0.0;
                    ResultSet rset_inventory = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + rset_stock1.getString(1) + "' and location='" + "VEHICLE" + "'");
                    if (rset_inventory.next()) {
                        qty = rset_inventory.getDouble(4);
                        cost = rset_inventory.getDouble(3);
                    }
                    vs.add(rset_stock1.getString(1));
                    vs.add(rset_stock1.getString(2));
                    vs.add(cost);
                    vs.add(qty);
                    vs.add(cost * qty);
                    vs.add(rset_stock1.getDouble(6));
                    df.addRow(vs);
                }
            }
            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptStock.jrxml");
            params.put("company", company);
            params.put("address", address);
            params.put("location", jc.getSelectedItem().toString());
            JRTableModelDataSource datasourse = new JRTableModelDataSource(df);
            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasourse);
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void age_analysis_summery(JScrollPane jScrollPane1, String jc) {
        try {
            jScrollPane1.removeAll();
            JTable jt = new JTable(0, 5);
            DefaultTableModel df = (DefaultTableModel) jt.getModel();
            if (jc.equals("Customer")) {
                ResultSet rset_cus = Model.Object.Jdbc.getdata("select* from customer_master");
                while (rset_cus.next()) {
                    ResultSet rset_redit = Model.Object.Jdbc.getdata("select sum(sub_total) from invoice_balance where customer_code='" + rset_cus.getString(1) + "'and payment_type='" + "Credit" + "'");
                    if (rset_redit.next()) {
                        ResultSet rset_paid = Model.Object.Jdbc.getdata("select sum(payment) from payments where (invoice_or_grn='" + "invoice" + "' || invoice_or_grn='" + "Invoice Return" + "') and customer_supplier_code='" + rset_cus.getString(1) + "'");
                        if (rset_paid.next()) {
                            Vector v_sumery = new Vector();
                            v_sumery.add(rset_cus.getString(1));
                            v_sumery.add(rset_cus.getString(2));
                            v_sumery.add(rset_redit.getDouble(1));
                            v_sumery.add(rset_paid.getDouble(1));
                            v_sumery.add(rset_redit.getDouble(1) - rset_paid.getDouble(1));
                            df.addRow(v_sumery);
                        }
                    }
                }
            } else {
                ResultSet rset_cus = Model.Object.Jdbc.getdata("select* from supplier_master");
                while (rset_cus.next()) {
                    ResultSet rset_redit = Model.Object.Jdbc.getdata("select sum(sub_total) from grn_balance where supplier_code='" + rset_cus.getString(1) + "' and payment_type='" + "Credit" + "'");
                    if (rset_redit.next()) {
                        ResultSet rset_paid = Model.Object.Jdbc.getdata("select sum(payment) from payments where (invoice_or_grn='" + "grn" + "' || invoice_or_grn='" + "Grn Return" + "') and customer_supplier_code='" + rset_cus.getString(1) + "'");
                        if (rset_paid.next()) {
                            Vector v_sumery = new Vector();
                            v_sumery.add(rset_cus.getString(1));
                            v_sumery.add(rset_cus.getString(2));
                            v_sumery.add(rset_redit.getDouble(1));
                            v_sumery.add(rset_paid.getDouble(1));
                            v_sumery.add(rset_redit.getDouble(1) - rset_paid.getDouble(1));
                            df.addRow(v_sumery);
                        }
                    }
                }
            }
            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptAgeanalisisSummery.jrxml");
            params.put("company", company);
            params.put("address", address);
            params.put("cus_sup", jc);
            JRTableModelDataSource datasourse = new JRTableModelDataSource(df);
            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasourse);
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void sales_collection(JScrollPane jScrollPane1) {
        try {
            jScrollPane1.removeAll();
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                String start_date1 = start_date + " 00:00:00";
                String start_date2 = start_date;
                String end_date1 = end_date + " 23:59:59";
                String end_date2 = end_date;
                JTable jt = new JTable(0, 4);
                DefaultTableModel df = (DefaultTableModel) jt.getModel();
                df.setRowCount(0);
                ResultSet rset_invoice = Model.Object.Jdbc.getdata("select* from invoice_balance where payment_type='" + "Cash" + "' and invoice_date between '" + start_date2 + "' and '" + end_date2 + "' order by date_time and invoice_code");
                while (rset_invoice.next()) {
                    Vector v = new Vector();
                    v.add("Cash Invoice");
                    v.add(rset_invoice.getString(1));
                    v.add(rset_invoice.getDouble(9));
                    v.add(rset_invoice.getString(15));
                    df.addRow(v);
                }

                ResultSet rset_payment = Model.Object.Jdbc.getdata("select* from payments where invoice_or_grn='" + "invoice" + "' and paymentType='" + "Cash" + "' and date_time between '" + start_date1 + "' and '" + end_date1 + "'order by date_time and invoice_grn_code");
                while (rset_payment.next()) {
                    Vector v = new Vector();
                    v.add("Cash Payment");
                    v.add(rset_payment.getString(3));
                    v.add(rset_payment.getDouble(6));
                    v.add(rset_payment.getString(8));
                    df.addRow(v);
                }

                ResultSet rset_other_income = Model.Object.Jdbc.getdata("select* from expenses_income where type='" + "Income" + "' and date_time between '" + start_date1 + "' and '" + end_date1 + "'order by date_time");
                while (rset_other_income.next()) {
                    Vector v = new Vector();
                    v.add("Other Income");
                    v.add(rset_other_income.getString(3));
                    v.add(rset_other_income.getDouble(6));
                    v.add(rset_other_income.getString(8));
                    df.addRow(v);
                }
                String company = null;
                String address = null;
                ResultSet rset1 = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset1.next()) {
                    company = rset1.getString(1);
                    address = rset1.getString(2) + " " + rset1.getString(3) + " " + rset1.getString(4);
                }
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptSalesCollection.jrxml");
                params.put("company", company);
                params.put("address", address);
                params.put("start_date", start_date);
                params.put("end_date", end_date1);
                JRTableModelDataSource datasourse = new JRTableModelDataSource(df);
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasourse);
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void item_transfer(JScrollPane jScrollPane1) {
        try {
            Vector v = new Vector();
            ResultSet rset1 = Model.Object.Jdbc.getdata("select tranfer_code from item_transfer group by tranfer_code");
            while (rset1.next()) {
                v.add(rset1.getString(1));
            }
            JComboBox jc = new JComboBox(v);
            final JComponent[] input = new JComponent[]{
                new JLabel("Select Transfer Code"),
                jc
            };
            JOptionPane.showMessageDialog(null, input, "Select", JOptionPane.QUESTION_MESSAGE);

            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            jScrollPane1.removeAll();
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptItemTransfer.jrxml");
            params.put("company", company);
            params.put("address", address);
            params.put("invoice_no", jc.getSelectedItem().toString());
            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void invoice_return(JScrollPane jScrollPane1) {
        try {
            Vector v = new Vector();
            ResultSet rset1 = Model.Object.Jdbc.getdata("select return_code from invoice_return_balance order by return_code");
            while (rset1.next()) {
                v.add(rset1.getString(1));
            }
            JComboBox jc = new JComboBox(v);
            final JComponent[] input = new JComponent[]{
                new JLabel("Select Return Code"),
                jc
            };
            JOptionPane.showMessageDialog(null, input, "Select", JOptionPane.QUESTION_MESSAGE);

            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            jScrollPane1.removeAll();
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptInvoiceReturn.jrxml");
            params.put("company", company);
            params.put("address", address);
            params.put("return_code", jc.getSelectedItem().toString());
            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.print(e);
        }
    }

    public void gg(JTextField jt, JComboBox jc) {
        try {
            Vector v = new Vector();
            ResultSet rset = Model.Object.Jdbc.getdata("SELECT grn_return_balance.return_code, grn_return_balance.supplier_name FROM grn_return_balance WHERE grn_return_balance.supplier_name like'" + jt.getText() + "%' order by LPAD(lower(grn_return_balance.return_code), 10,0) ASC ");
            while (rset.next()) {
                v.add(rset.getString(1));
            }
            jc.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void grn_return(JScrollPane jScrollPane1) {
        try {
            Vector v = new Vector();
            ResultSet rset1 = Model.Object.Jdbc.getdata("select return_code from grn_return_balance order by return_code");
            while (rset1.next()) {
                v.add(rset1.getString(1));
            }
            final JComboBox jc = new JComboBox(v);
            final JTextField jt = new JTextField();

            jt.addKeyListener(new KeyAdapter() {
                public void keyReleased(KeyEvent e) {
                    gg(jt, jc);
                }
            });

            final JComponent[] input = new JComponent[]{
                jt,
                new JLabel("Select Return Code"),
                jc
            };
            JOptionPane.showMessageDialog(null, input, "Select", JOptionPane.QUESTION_MESSAGE);

            String company = null;
            String address = null;
            ResultSet rset = Model.Object.Jdbc.getdata("select* from c_info");
            if (rset.next()) {
                company = rset.getString(1);
                address = rset.getString(2) + " " + rset.getString(3) + " " + rset.getString(4);
            }
            jScrollPane1.removeAll();
            Map<String, Object> params = new HashMap<String, Object>();
            InputStream stream = null;
            stream = this.getClass().getResourceAsStream("/Report/RptGrnReturn.jrxml");
            params.put("company", company);
            params.put("address", address);
            params.put("return_code", jc.getSelectedItem().toString());
            JasperReport jasperReport = JasperCompileManager.compileReport(stream);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, Model.Object.Jdbc.getconnection());
            JasperViewer.setDefaultLookAndFeelDecorated(true);
//            JRViewer jrv = new JRViewer(jasperPrint);
//            jrv.setSize(jScrollPane1.getSize());
//            jScrollPane1.add(jrv);
//            jScrollPane1.updateUI();
            JRViewer viewer = new JRViewer(jasperPrint);
            viewer.setSize(800, 680);
            JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
            frame.setSize(800, 680);
            frame.add(viewer);
            FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);

        } catch (Exception e) {
            System.out.print(e);
        }
    }
    
    public void total_sales_amount(JScrollPane jScrollPane1) {
        try {
            jScrollPane1.removeAll();
            String start_date = Model.Object.Formated.StartDate();
            String end_date = Model.Object.Formated.EndDate();
            if (Model.Object.Formated.string_date_fromat(start_date) == true || Model.Object.Formated.string_date_fromat(end_date) == true) {
                Model.Object.messagePopUps.date_format_error();
            } else {
                String start_date1 = start_date + " 00:00:00";
                String start_date2 = start_date;
                String end_date1 = end_date + " 23:59:59";
                String end_date2 = end_date;
                JTable jt = new JTable(0, 4);
                DefaultTableModel df = (DefaultTableModel) jt.getModel();
                df.setRowCount(0);
                ResultSet rset_invoice = Model.Object.Jdbc.getdata("select* from invoice_balance where invoice_date between '" + start_date2 + "' and '" + end_date2 + "' order by date_time");
                while (rset_invoice.next()) {
                        Vector v = new Vector();
                        v.add("Total Sales Amount");
                        v.add(rset_invoice.getString(1));
                        v.add(rset_invoice.getDouble(12));
                        v.add(rset_invoice.getString(14));
                        df.addRow(v);
                }

                String company = null;
                String address = null;
                ResultSet rset1 = Model.Object.Jdbc.getdata("select* from c_info");
                if (rset1.next()) {
                    company = rset1.getString(1);
                    address = rset1.getString(2) + " " + rset1.getString(3) + " " + rset1.getString(4);
                }
                Map<String, Object> params = new HashMap<String, Object>();
                InputStream stream = null;
                stream = this.getClass().getResourceAsStream("/Report/RptTotalSalesAmount.jrxml");
                params.put("company", company);
                params.put("address", address);
                params.put("start_date", start_date);
                params.put("end_date", end_date1);
                JRTableModelDataSource datasourse = new JRTableModelDataSource(df);
                JasperReport jasperReport = JasperCompileManager.compileReport(stream);
                JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, datasourse);
                JasperViewer.setDefaultLookAndFeelDecorated(true);
//                JRViewer jrv = new JRViewer(jasperPrint);
//                jrv.setSize(jScrollPane1.getSize());
//                jScrollPane1.add(jrv);
//                jScrollPane1.updateUI();
                JRViewer viewer = new JRViewer(jasperPrint);
                viewer.setSize(800, 680);
                JInternalFrame frame = new JInternalFrame("Report", true, true, true, true);
                frame.setSize(800, 680);
                frame.add(viewer);
                FrmReportViewer.jDesktopPane1.add(frame).setVisible(true);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
