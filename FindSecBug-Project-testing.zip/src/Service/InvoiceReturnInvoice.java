/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import View.FrmHome2;
import View.FrmInvoiceReturn;

/**
 *
 * @author user
 */
public class InvoiceReturnInvoice {

    public void code_gen(JLabel lbl_return_code) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select max(code) from invoice_return_code");
            if (rset.next()) {
                lbl_return_code.setText("IVRT" + (rset.getInt(1) + 1));
            } else {
                lbl_return_code.setText(null);
            }
        } catch (Exception e) {
            System.out.println("Ivoice Return code_gen  " + e);
        }
    }

    public void invoice_Select(JTextField txt_incoice_code, JLabel lbl_customer_code, JLabel lbl_customer_name, JComboBox cbo_item_code) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from invoice_balance where invoice_code='" + txt_incoice_code.getText() + "'");
            if (rset.next()) {
                lbl_customer_code.setText(rset.getString(2));
                ResultSet rset_customer = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset.getString(2) + "'");
                if (rset_customer.next()) {
                    lbl_customer_name.setText(rset_customer.getString(2));
                }
                ResultSet rset_item = Model.Object.Jdbc.getdata("select* from invoice_item where invoice_code='" + txt_incoice_code.getText() + "'");
                Vector v = new Vector();
                while (rset_item.next()) {
                    v.add(rset_item.getString(2));
                }
                cbo_item_code.setModel(new DefaultComboBoxModel(v));
                cbo_item_code.grabFocus();
            } else {
                Model.Object.messagePopUps.invoice_code_doesnot_match();
                Vector v = new Vector();
                txt_incoice_code.grabFocus();
                lbl_customer_code.setText(null);
                cbo_item_code.setModel(new DefaultComboBoxModel(v));
                lbl_customer_name.setText(null);
            }
        } catch (Exception e) {
            System.out.println("Ivoice Return invoice_Select  " + e);
        }
    }

    public void item_code_action(JTextField txt_incoice_codeField, JComboBox cbo_item_code, JLabel lbl_item_description, JLabel lbl_sale_price, JLabel lbl_sale_qty, JLabel lbl_total_amount, JLabel lbl_item_discount, JLabel lbl_net_amount, JLabel lbl_total_discount, JLabel lbl_sub_total, JLabel lbl_sale_location, JLabel lbl_return_item_unit_price, JComboBox cbo_return_location) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from invoice_item where invoice_code='" + txt_incoice_codeField.getText() + "' and item_code='" + cbo_item_code.getSelectedItem() + "'");
            if (rset.next()) {
                lbl_item_description.setText(rset.getString(3));
                lbl_sale_price.setText(rset.getString(5));
                lbl_sale_qty.setText(rset.getString(7));
                lbl_total_amount.setText(rset.getString(8));
                lbl_item_discount.setText(rset.getString(10));
                lbl_net_amount.setText(rset.getString(11));
                lbl_total_discount.setText(rset.getString(12));
                lbl_sub_total.setText(rset.getString(13));
                lbl_sale_location.setText(rset.getString(4));
                lbl_return_item_unit_price.setText(Model.Object.Formated.getPriceValue((Double.parseDouble(lbl_sub_total.getText()) / Double.parseDouble(lbl_sale_qty.getText()))));
            } else {
                Model.Object.messagePopUps.cannt_find_invoice_item_details();
                cbo_item_code.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("Ivoice Return item_code_action  " + e);
        }
    }

    public void add(JLabel lbl_customer_code, JLabel lbl_customer_name, JTextField txt_invoice_code, JLabel lbl_return_code, JComboBox cbo_item_code, JLabel lbl_item_description, JLabel lbl_sale_price, JLabel lbl_sale_qty, JLabel lbl_total_amount, JLabel lbl_item_discount, JLabel lbl_net_amount, JLabel lbl_total_discount, JLabel lbl_sub_total, JLabel lbl_sale_location, JLabel lbl_return_item_unit_price, JComboBox cbo_return_location, JTextField txt_return_quantity, JLabel lbl_item_return_amount, JTable tbl_return, JLabel lbl_return_total_amount) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from invoice_item where invoice_code='" + txt_invoice_code.getText() + "' and item_code='" + cbo_item_code.getSelectedItem() + "'");
            if (rset.next()) {
                if (Double.parseDouble(lbl_sale_qty.getText()) < Double.parseDouble(txt_return_quantity.getText())) {
                    Model.Object.messagePopUps.Exceed_Quantity();
                    txt_return_quantity.grabFocus();
                    txt_return_quantity.selectAll();
                } else if (lbl_item_return_amount.getText().isEmpty()) {
                    Model.Object.messagePopUps.amount_is_empty();
                    txt_return_quantity.grabFocus();
                } else {
                    boolean duplicate = false;
                    ResultSet rset_duplicate = Model.Object.Jdbc.getdata("select* from invoice_return_item where item_code='" + cbo_item_code.getSelectedItem() + "' and invoice_code='" + txt_invoice_code.getText() + "'");
                    if (rset_duplicate.next()) {
                        Model.Object.messagePopUps.duplicateEntryMessage();
                        duplicate = true;
                    } else {
                        for (int i = 0; i < tbl_return.getRowCount(); i++) {
                            if (tbl_return.getValueAt(i, 0).equals(cbo_item_code.getSelectedItem().toString())) {
                                duplicate = true;
                                Model.Object.messagePopUps.Duplicate_entry();
                                break;
                            }
                        }

                    }
                    if (duplicate) {
                        cbo_item_code.setSelectedItem("[ Select ]");
                        lbl_item_description.setText(null);
                        lbl_sale_price.setText(null);
                        lbl_sale_qty.setText(null);
                        lbl_total_amount.setText(null);
                        lbl_item_discount.setText(null);
                        lbl_net_amount.setText(null);
                        lbl_total_discount.setText(null);
                        lbl_sub_total.setText(null);
                        lbl_sale_location.setText(null);
                        lbl_return_item_unit_price.setText(null);
                        cbo_return_location.setSelectedItem("WAREHOUSE");
                        txt_return_quantity.setText(null);
                        lbl_item_return_amount.setText(null);
                        if (tbl_return.getRowCount() == 0) {
                            txt_invoice_code.setText(null);
                            lbl_customer_code.setText(null);
                            lbl_customer_name.setText(null);
                            txt_invoice_code.setEditable(true);
                            txt_invoice_code.grabFocus();
                        } else {
                            cbo_item_code.grabFocus();
                        }
                    } else {
                        DefaultTableModel df = (DefaultTableModel) tbl_return.getModel();
                        Vector v = new Vector();
                        v.add(cbo_item_code.getSelectedItem());
                        v.add(lbl_item_description.getText());
                        v.add(lbl_return_item_unit_price.getText());
                        v.add(txt_return_quantity.getText());
                        v.add(lbl_item_return_amount.getText());
                        v.add(rset.getString(14));
                        v.add(cbo_return_location.getSelectedItem());
                        df.addRow(v);
                        Model.Object.messagePopUps.Data_Added_Successfully();
                        DefaultTableModel df_1 = (DefaultTableModel) tbl_return.getModel();
                        Double return_amount = 0.00;
                        for (int i = 0; i < df_1.getRowCount(); i++) {
                            return_amount = return_amount + Double.parseDouble(df_1.getValueAt(i, 4).toString());
                        }
                        lbl_return_total_amount.setText(Model.Object.Formated.getPriceValue(return_amount));
                        cbo_item_code.setSelectedItem("[ Select ]");
                        lbl_item_description.setText(null);
                        lbl_sale_price.setText(null);
                        lbl_sale_qty.setText(null);
                        lbl_total_amount.setText(null);
                        lbl_item_discount.setText(null);
                        lbl_net_amount.setText(null);
                        lbl_total_discount.setText(null);
                        lbl_sub_total.setText(null);
                        lbl_sale_location.setText(null);
                        lbl_return_item_unit_price.setText(null);
                        cbo_return_location.setSelectedItem("WAREHOUSE");
                        txt_return_quantity.setText(null);
                        lbl_item_return_amount.setText(null);
                        txt_invoice_code.setEnabled(false);
                        cbo_item_code.grabFocus();
                    }
                }
            } else {
                Model.Object.messagePopUps.invoice_code_doesnot_match();
                txt_invoice_code.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("Ivoice Return add  " + e);
        }
    }

    public void end_return(JTable tbl_return, JLabel lbl_return_code, JTextField txt_invoice_code, JLabel lbl_customer_code, JLabel lbl_customer_name, JLabel lbl_return_total_amount) {
        try {
            if (tbl_return.getRowCount() >= 1) {
                DefaultTableModel df = (DefaultTableModel) tbl_return.getModel();
                Double item_count = 0.00;
                Double loss = 0.00;
                for (int i = 0; i < df.getRowCount(); i++) {
                    Double recent_qty = 0.00;
                    ResultSet rset_all_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "'");
                    while (rset_all_qty.next()) {
                        recent_qty = recent_qty + rset_all_qty.getDouble(4);
                    }

                    Double location_recent_qty = 0.00;
                    ResultSet rset_location_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 6) + "'");
                    if (rset_location_qty.next()) {
                        location_recent_qty = rset_location_qty.getDouble(4);
                    }
                    Model.Object.Jdbc.putdata("insert into invoice_return_item values('" + lbl_return_code.getText() + "','" + txt_invoice_code.getText() + "','" + df.getValueAt(i, 0) + "','" + df.getValueAt(i, 1) + "','" + df.getValueAt(i, 2) + "','" + "Type" + "','" + df.getValueAt(i, 3) + "','" + df.getValueAt(i, 4) + "','" + df.getValueAt(i, 5) + "','" + df.getValueAt(i, 6) + "',NOW(),'" + View.FrmHome2.user_lbl.getText() + "')");
                    Model.Object.Jdbc.putdata("insert into invoice_return_code values('" + "0" + "')");
                    Double quanntity = 0.00;
                    ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 6) + "'");
                    if (rset.next()) {
                        quanntity = rset.getDouble(4) + Double.parseDouble(df.getValueAt(i, 3).toString());
                        Model.Object.Jdbc.putdata("update item_inventory set stock='" + quanntity + "',last_date_time=NOW(),last_user='" + View.FrmHome2.user_lbl.getText() + "' where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 6) + "'");
                    }
                    item_count = item_count + Double.parseDouble(df.getValueAt(i, 3).toString());
                    loss = loss + Double.parseDouble(df.getValueAt(i, 5).toString());

                    Model.Object.Jdbc.putdata("insert into transaction values('" + df.getValueAt(i, 0) + "','" + lbl_return_code.getText() + "',NOW(),'" + recent_qty + "','" + df.getValueAt(i, 3) + "','" + "0.0" + "','" + (recent_qty + Double.parseDouble(df.getValueAt(i, 3).toString())) + "','" + "Invoice Return" + "','" + df.getValueAt(i, 6) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                    Model.Object.Jdbc.putdata("insert into Location_wise_transaction values('" + df.getValueAt(i, 0) + "','" + lbl_return_code.getText() + "',NOW(),'" + location_recent_qty + "','" + df.getValueAt(i, 3) + "','" + "0.0" + "','" + (location_recent_qty + Double.parseDouble(df.getValueAt(i, 3).toString())) + "','" + "Invoice Return" + "','" + df.getValueAt(i, 6) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");

                }
                Model.Object.Jdbc.putdata("insert into invoice_return_balance values('" + lbl_return_code.getText() + "','" + txt_invoice_code.getText() + "','" + lbl_customer_code.getText() + "','" + lbl_customer_name.getText() + "','" + item_count + "','" + lbl_return_total_amount.getText() + "','" + loss + "','" + FrmInvoiceReturn.return_type + "','" + FrmInvoiceReturn.new_invo_code + "',NOW(),'" + View.FrmHome2.user_lbl.getText() + "')");
                ResultSet rset_payment = Model.Object.Jdbc.getdata("select* from payments where (invoice_or_grn='" + "invoice" + "' or invoice_or_grn='" + "Invoice Return" + "') and invoice_grn_code='" + txt_invoice_code.getText() + "'");
                Double payment = 0.00;
                boolean next = false;
                int pay_status = 0;
                while (rset_payment.next()) {
                    payment = payment + rset_payment.getDouble(6);
                    pay_status = rset_payment.getInt(10);
                    next = true;
                }
                if (next == true) {
                    ResultSet rset_invoice = Model.Object.Jdbc.getdata("select* from invoice_balance where invoice_code='" + txt_invoice_code.getText() + "' and payment_type='" + "credit" + "'");
                    if (rset_invoice.next()) {
                        Double due_payment = payment;
                        due_payment = due_payment + Double.parseDouble(lbl_return_total_amount.getText());
                        due_payment = rset_invoice.getDouble(9) - due_payment;
                        Double sub_total = rset_invoice.getDouble(9) - payment;
                        if (pay_status == 1) {
                            Model.Object.messagePopUps.return_invoice_payment(" Your Balance is Rs." + due_payment);
                        } else {
                            Model.Object.Jdbc.putdata("insert into payments values('" + "0" + "','" + "Invoice Return" + "','" + txt_invoice_code.getText() + "','" + lbl_customer_code.getText() + "','" + sub_total + "','" + lbl_return_total_amount.getText() + "','" + due_payment + "',NOW(),'" + "Return" + "','" + "0" + "','" + "" + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        }
                    }
                }

                Model.Object.messagePopUps.saveMessage();
                txt_invoice_code.setEnabled(true);
                txt_invoice_code.setText("INV");
                txt_invoice_code.grabFocus();
                lbl_customer_code.setText(null);
                lbl_customer_name.setText(null);
                df.setRowCount(0);
                FrmInvoiceReturn.return_type = "Without Invoice";
                FrmInvoiceReturn.new_invo_code = "Without Invoice";
                code_gen(lbl_return_code);
                lbl_return_total_amount.setText(null);
            } else {
                Model.Object.messagePopUps.table_empty();
                txt_invoice_code.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("Ivoice Return end_return  " + e);
        }
    }

    public void row_delete(JTable tbl_return, JLabel lbl_return_total_amount) {
        try {
            int u = Model.Object.messagePopUps.do_you_want_delete_record_confirem_msg();
            DefaultTableModel df = (DefaultTableModel) tbl_return.getModel();
            if (u == JOptionPane.YES_OPTION) {
                df.removeRow(tbl_return.getSelectedRow());
                Double amount = 0.00;
                for (int i = 0; i < tbl_return.getRowCount(); i++) {
                    amount = amount + Double.parseDouble(tbl_return.getValueAt(i, 4).toString());
                }
                lbl_return_total_amount.setText(Model.Object.Formated.getPriceValue(amount));
            }
        } catch (Exception e) {
            System.out.println("Ivoice Return row_delete  " + e);
        }
    }
}
