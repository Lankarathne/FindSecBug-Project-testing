/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Service.Key_Activator;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.IOException;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.KeySpec;
import java.sql.ResultSet;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import Model.Object.*;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.net.URI;
import javax.swing.ImageIcon;

/**
 *
 * @author Pasindu
 */
public class FrmLogin extends javax.swing.JFrame {

    /**
     * Creates new form Login
     */
    public FrmLogin() {

        initComponents();
        try {
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            setBounds(0, 0, screenSize.width, screenSize.height);
            this.setIconImage(ImageIO.read(this.getClass().getResource("/images/title_icon.png")));

        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public String decrypt(String str) {
        Cipher dcipher = null;
        try {
            byte[] salt = {(byte) 0xA9, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, (byte) 0x56, (byte) 0x34, (byte) 0xE3, (byte) 0x03};
            int iterationCount = 19;
            try {
                String passPhrase = "";
                KeySpec keySpec = new PBEKeySpec(passPhrase.toCharArray(), salt, iterationCount);
                SecretKey key = SecretKeyFactory.getInstance("PBEWithMD5AndDES").generateSecret(keySpec);
                dcipher = Cipher.getInstance(key.getAlgorithm());
                // Prepare the parameters to the cipthers  
                AlgorithmParameterSpec paramSpec = new PBEParameterSpec(salt, iterationCount);
                dcipher.init(Cipher.DECRYPT_MODE, key, paramSpec);
            } catch (Exception e) {
                Model.Object.messagePopUps.errorInSerial();
            }
            // Decode base64 to get bytes  
            byte[] dec = new sun.misc.BASE64Decoder().decodeBuffer(str);
            // Decrypt  
            byte[] utf8 = dcipher.doFinal(dec);
            // Decode using utf-8  
            return new String(utf8, "UTF8");
        } catch (Exception e) {
            Model.Object.messagePopUps.errorInSerial();
        }

        return null;
    }

    private void logintosystem() {
        try {
            boolean bool = true;
            boolean bool_1 = true;

            ResultSet rset_start = Model.Object.Jdbc.getdata("select* from Activate_date");
            if (rset_start.next()) {
                String firstdate = Model.Object.Formated.todayDate();
                String password = rset_start.getString(1);

                // encrypted = encrypter.encrypt("stdnlthc$fnc%i^");
                String decrypted = decrypt(password);
                Key_Activator ka = new Key_Activator();
                String activate_date = ka.Activate_key(decrypted);
                // Formatter
                DateTimeFormatter dateStringFormat = DateTimeFormat.forPattern("yyyy-MM-dd");
                DateTime firstTime = dateStringFormat.parseDateTime(firstdate);
                DateTime secondTime = dateStringFormat.parseDateTime(activate_date);
                int days = Days.daysBetween(new LocalDate(firstTime), new LocalDate(secondTime)).getDays();

                if (days < 0) {
                    Model.Object.messagePopUps.Sytem_expire();
                    bool = true;
                } else if (days > 0) {
                    int remening_datys = days;
                    MsgWarning.msg_warning("<html>Info-Ims License Key Will Be Expired<br>With In " + remening_datys + " Days...</html> ");
                    new MsgWarning(this, true).setVisible(true);
                    // JOptionPane.showMessageDialog(null, "Info-Ims License Key Will Be Expired With In " + remening_datys + " Days...", "Warning !", JOptionPane.WARNING_MESSAGE);
                    bool = false;
                } else {
                    bool = false;
                }
                ResultSet rset_log_date = Model.Object.Jdbc.getdata("select max(Log_date) from Log_date");
                if (rset_log_date.next()) {
                    String formatedToday = Model.Object.Formated.todayDate();
                    String maxLogDate = rset_log_date.getString(1) == null ? "" : rset_log_date.getString(1);
                    if (maxLogDate.equals(formatedToday)) {
                        bool_1 = false;
                    } else {
                        String firstdate_1 = rset_log_date.getString(1);
                        String seconddate_1 = Model.Object.Formated.todayDate();
                        DateTimeFormatter dateStringFormat_1 = DateTimeFormat.forPattern("yyyy-MM-dd");
                        DateTime firstTime_1 = dateStringFormat_1.parseDateTime(firstdate_1);
                        DateTime secondTime_1 = dateStringFormat.parseDateTime(seconddate_1);
                        int days_1 = Days.daysBetween(new LocalDate(firstTime_1), new LocalDate(secondTime_1)).getDays();
                        System.out.println(days_1);
                        String d = String.valueOf(days_1);
                        if (String.valueOf(d.charAt(0)).equals("-")) {
                            Model.Object.messagePopUps.Sytem_date_wrong();
                            bool_1 = true;
                        } else {
                            bool_1 = false;
                            Model.Object.Jdbc.putdata("insert into Log_date values('" + Model.Object.Formated.todayDate() + "')");
                        }
                    }
                }
                if (bool) {
                } else {
                    if (bool_1) {
                    } else {
                        ResultSet rset = Model.Object.Jdbc.getdata("select* from user_login where UserName='" + txt_user.getText() + "' and Password='" + pswd_password.getText() + "'");
                        if (rset.next()) {
                            new FrmHome2().setVisible(true);
                            FrmHome2.log_time = Model.Object.Formated.todayDate() + " " + Model.Object.Formated.nowTime_1();
                            FrmHome2.user_lbl.setText(txt_user.getText());
                            FrmHome2.user_full_name = rset.getString(1);
                            FrmHome2.user_name = rset.getString(2);
                            FrmHome2.group = rset.getString(3);                            
                            FrmHome2.Admin = rset.getString(5);
                            this.dispose();
                        } else {
                            Model.Object.messagePopUps.errorInLogin();
                            txt_user.setText(null);
                            pswd_password.setText(null);
                            txt_user.grabFocus();
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel(){
            ImageIcon icon = new ImageIcon(this.getClass().getResource("/images/background1.jpg"));
            Image img =icon.getImage();
            @Override
            public void paintComponent(Graphics g)
            {
                g.drawImage(img, 0, 0,jPanel2.getWidth(),jPanel2.getHeight(), null);
            }
        };
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        pswd_password = new javax.swing.JPasswordField();
        jLabel3 = new javax.swing.JLabel();
        txt_user = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        minimize_label = new javax.swing.JLabel();
        close_label = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("InfoIMS Login");
        setBackground(new java.awt.Color(51, 51, 51));
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                formKeyReleased(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setOpaque(false);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Login");
        jLabel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        jLabel5.setOpaque(true);
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        jLabel5.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jLabel5FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jLabel5FocusLost(evt);
            }
        });
        jLabel5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jLabel5KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jLabel5KeyReleased(evt);
            }
        });
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 140, 130, 30));

        pswd_password.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        pswd_password.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        pswd_password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pswd_passwordActionPerformed(evt);
            }
        });
        jPanel1.add(pswd_password, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 90, 210, 30));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Password");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, -1, 20));

        txt_user.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txt_user.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        txt_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_userActionPerformed(evt);
            }
        });
        txt_user.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_userKeyReleased(evt);
            }
        });
        jPanel1.add(txt_user, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 30, 210, 30));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Username");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, -1, 20));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/user.png"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 180));

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, 430, -1));

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/white_clarity_shutdown_icon_preview.png"))); // NOI18N
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 580, 50, 50));

        jPanel3.setOpaque(false);
        jPanel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel3MouseClicked(evt);
            }
        });
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Copyright © 2015 Infocraft Ltd");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 20));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("www.infocraft.lk");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 110, 20));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 600, 480, 20));

        minimize_label.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        minimize_label.setForeground(new java.awt.Color(255, 255, 255));
        minimize_label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        minimize_label.setText("_");
        minimize_label.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        minimize_label.setIconTextGap(0);
        minimize_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimize_labelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                minimize_labelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                minimize_labelMouseExited(evt);
            }
        });
        jPanel2.add(minimize_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(928, 0, 20, 18));

        close_label.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        close_label.setForeground(new java.awt.Color(255, 255, 255));
        close_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/close.png"))); // NOI18N
        close_label.setText(" ");
        close_label.setIconTextGap(2);
        close_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                close_labelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                close_labelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                close_labelMouseExited(evt);
            }
        });
        jPanel2.add(close_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(948, 0, 40, 18));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 992, -1));

        setSize(new java.awt.Dimension(992, 631));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void pswd_passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pswd_passwordActionPerformed

        if (txt_user.getText().equals("key activator") && pswd_password.getText().equals("infoims123")) {
            new FrmActivator().setVisible(true);
            pswd_password.setText(null);
            txt_user.setText(null);
            txt_user.grabFocus();
        } else {
            logintosystem();

        }
    }//GEN-LAST:event_pswd_passwordActionPerformed

    private void txt_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_userActionPerformed
        pswd_password.requestFocus();

    }//GEN-LAST:event_txt_userActionPerformed

    private void formKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyReleased
        // TODO add your handling code here:

    }//GEN-LAST:event_formKeyReleased

    private void txt_userKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_userKeyReleased
        // TODO add your handling code here:
        try {

        } catch (Exception e) {
        }
    }//GEN-LAST:event_txt_userKeyReleased

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        // TODO add your handling code here:
        if (evt.getButton() == 1) {
            jLabel5.setBackground(new Color(148, 148, 148));
            logintosystem();
            jLabel5.setBackground(new Color(240, 240, 240));
        }
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        // TODO add your handling code here:
        int i = Model.Object.messagePopUps.exit();
        if (i == JOptionPane.YES_OPTION) {
            System.exit(1);
        }
    }//GEN-LAST:event_jLabel6MouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
        int x = (this.getWidth() / 2) - (jPanel1.getWidth() / 2);
        int y = (this.getHeight() / 2) - (jPanel1.getHeight() / 2);
        jPanel1.setLocation(x, y - 40);
        jPanel2.setSize(this.getWidth(), this.getHeight());
        jLabel6.setLocation(20, this.getHeight() - 70);
        jPanel3.setLocation(70, this.getHeight() - 40);

        minimize_label.setLocation(this.getWidth() - 64, 0);
        close_label.setLocation(this.getWidth() - 44, 0);


    }//GEN-LAST:event_formWindowOpened

    private void jPanel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel3MouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_jPanel3MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        // TODO add your handling code here:
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().browse(new URI("http://www.infocraft.lk"));
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_jLabel7MouseClicked

    private void minimize_labelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimize_labelMouseClicked
        // TODO add your handling code here:
        this.setState(Frame.ICONIFIED);
    }//GEN-LAST:event_minimize_labelMouseClicked

    private void minimize_labelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimize_labelMouseEntered
        // TODO add your handling code here:
        Model.Object.interface_format.minimize_label_focus(minimize_label);
    }//GEN-LAST:event_minimize_labelMouseEntered

    private void minimize_labelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimize_labelMouseExited
        // TODO add your handling code here:
        Model.Object.interface_format.minimize_label_focus_out(minimize_label);
    }//GEN-LAST:event_minimize_labelMouseExited

    private void close_labelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_close_labelMouseClicked
        // TODO add your handling code here:
        int i = Model.Object.messagePopUps.exit();
        if (i == JOptionPane.YES_OPTION) {
            System.exit(1);
        }
    }//GEN-LAST:event_close_labelMouseClicked

    private void close_labelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_close_labelMouseEntered
        // TODO add your handling code here:
        Model.Object.interface_format.close_label_focus(close_label);
    }//GEN-LAST:event_close_labelMouseEntered

    private void close_labelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_close_labelMouseExited
        // TODO add your handling code here:
        Model.Object.interface_format.close_label_focus_out(close_label);
    }//GEN-LAST:event_close_labelMouseExited

    private void jLabel5FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jLabel5FocusGained
        // TODO add your handling code here:
        jLabel5.setBackground(Color.GRAY);
    }//GEN-LAST:event_jLabel5FocusGained

    private void jLabel5FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jLabel5FocusLost
        // TODO add your handling code here:
        jLabel5.setBackground(new Color(240, 240, 240));
    }//GEN-LAST:event_jLabel5FocusLost

    private void jLabel5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jLabel5KeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            jLabel5.setBackground(new Color(148, 148, 148));
            logintosystem();
            jLabel5.setBackground(new Color(240, 240, 240));
        }
    }//GEN-LAST:event_jLabel5KeyPressed

    private void jLabel5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jLabel5KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel5KeyReleased

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        int x = (this.getWidth() / 2) - (jPanel1.getWidth() / 2);
        int y = (this.getHeight() / 2) - (jPanel1.getHeight() / 2);
        jPanel1.setLocation(x, y - 40);
        jPanel2.setSize(this.getWidth(), this.getHeight());
        jLabel6.setLocation(20, this.getHeight() - 70);
        jPanel3.setLocation(70, this.getHeight() - 40);

        minimize_label.setLocation(this.getWidth() - 64, 0);
        close_label.setLocation(this.getWidth() - 44, 0);


    }//GEN-LAST:event_formWindowActivated

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel close_label;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel minimize_label;
    private javax.swing.JPasswordField pswd_password;
    private javax.swing.JTextField txt_user;
    // End of variables declaration//GEN-END:variables
}
